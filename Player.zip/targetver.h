#pragma once
#define _WIN32_WINNT 0x0603
#define _CHICAGO_
#include "SDKDDKVer.h"
//#define _WIN32_WINNT 0x0603
//#define _CHICAGO_
