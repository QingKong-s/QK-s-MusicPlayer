#pragma once
#include "windows.h"
#include "bass.h"
#include "Shobjidl.h"
#include "ole2.h"
#include "shlwapi.h"

//#define _WIN32_WINNT 0x0603
//#define _CHICAGO_
////////////////////GDI+Flat����
enum GpStatus {
	Ok,
	GenericError,
	InvalidParameter,
	OutOfMemory,
	ObjectBusy,
	InsufficientBuffer,
	NotImplemented,
	Win32Error,
	WrongState,
	Aborted,
	FileNotFound,
	ValueOverflow,
	AccessDenied,
	UnknownImageFormat,
	FontFamilyNotFound,
	FontStyleNotFound,
	NotTrueTypeFont,
	UnsupportedGdiplusVersion,
	GdiplusNotInitialized,
	PropertyNotFound,
	PropertyNotSupported,
	ProfileNotFound
};
enum SmoothingMode {
	SmoothingModeDefault,
	SmoothingModeHighSpeed,
	SmoothingModeHighQuality,
	SmoothingModeNone,
};
enum TextRenderingHint {
	TextRenderingHintSystemDefault,
	TextRenderingHintSingleBitPerPixelGridFit,
	TextRenderingHintSingleBitPerPixel,
	TextRenderingHintAntiAliasGridFit,
	TextRenderingHintAntiAlias,
	TextRenderingHintClearTypeGridFit
};
struct GdiplusStartupInput {
	UINT32         GdiplusVersion;
	void*		   DebugEventCallback;
	BOOL           SuppressBackgroundThread;
	BOOL           SuppressExternalCodecs;
};
enum Unit {
	UnitWorld,
	UnitDisplay,
	UnitPixel,
	UnitPoint,
	UnitInch,
	UnitDocument,
	UnitMillimeter
};
typedef enum StringFormatFlags {
	StringFormatFlagsDirectionRightToLeft = 0x00000001,
	StringFormatFlagsDirectionVertical = 0x00000002,
	StringFormatFlagsNoFitBlackBox = 0x00000004,
	StringFormatFlagsDisplayFormatControl = 0x00000020,
	StringFormatFlagsNoFontFallback = 0x00000400,
	StringFormatFlagsMeasureTrailingSpaces = 0x00000800,
	StringFormatFlagsNoWrap = 0x00001000,
	StringFormatFlagsLineLimit = 0x00002000,
	StringFormatFlagsNoClip = 0x00004000,
	StringFormatFlagsBypassGDI = 0x80000000
};
struct RectF {
	float Left;
	float Top;
	float Width;
	float Height;
};
struct PointF {
	float x;
	float y;
};
struct BlurParams {
	float radius;
	BOOL  expandEdge;
};
enum FillMode {
	FillModeAlternate,
	FillModeWinding
};
enum WrapMode {
	WrapModeTile,
	WrapModeTileFlipX,
	WrapModeTileFlipY,
	WrapModeTileFlipXY,
	WrapModeClamp
};
enum FontStyle {
	FontStyleRegular,
	FontStyleBold,
	FontStyleItalic,
	FontStyleBoldItalic,
	FontStyleUnderline,
	FontStyleStrikeout
};
enum StringAlignment {
	StringAlignmentNear,
	StringAlignmentCenter,
	StringAlignmentFar
};
typedef void GpGraphics;
typedef void GpFontCollection;
typedef void GpFontFamily;
typedef void GpFont;
typedef void GpStringFormat;
typedef void GpPen;
typedef void GpPath;
typedef void GpSolidFill;
typedef void GpBrush;
typedef void GpLineGradient;
typedef void GpBrush;
typedef void GpBrush;
typedef void GpImage;
typedef void GpImageAttributes;
typedef void GpEffect;
typedef void GpBitmap;
typedef LPVOID DrawImageAbort;
typedef float REAL;
typedef DWORD ARGB;
typedef INT PixelFormat;//Gdipluspixelformats.h
#define WINGDIPAPI WINAPI
#define GDIPCONST const
#define PixelFormat32bppRGB 139273
#define PixelFormat32bppArgb 2498570
extern "C" {//extern "C"��ʹ��C�������ӷ�ʽ����ֹ���Ʒ��飬�����˴�gdiplus.lib
	GpStatus WINGDIPAPI	GdiplusStartup(ULONG_PTR* token, const GdiplusStartupInput* input, void* output);
	void	 WINGDIPAPI	GdiplusShutdown(ULONG_PTR token);
	GpStatus WINGDIPAPI	GdipCreateFromHDC(HDC hdc, GpGraphics** graphics);
	GpStatus WINGDIPAPI	GdipSetSmoothingMode(GpGraphics* graphics, SmoothingMode smoothingMode);
	GpStatus WINGDIPAPI GdipSetTextRenderingHint(GpGraphics* graphics, TextRenderingHint mode);
	GpStatus WINGDIPAPI	GdipCreateFontFamilyFromName(GDIPCONST WCHAR* name, GpFontCollection* fontCollection, GpFontFamily** FontFamily);
	//��������һ��FontStyleö��ֵ��λ�����:
	GpStatus WINGDIPAPI GdipCreateFont(GDIPCONST GpFontFamily* fontFamily, REAL emSize, INT style, Unit unit, GpFont** font);
	//����һ��һ��StringFormatFlagsö�٣�Ĭ��ֵΪ0��������������ID��Ĭ��ֵΪLANG_NEUTRAL:
	GpStatus WINGDIPAPI GdipCreateStringFormat(INT formatAttributes, LANGID language, GpStringFormat** format);
	GpStatus WINGDIPAPI GdipSetStringFormatAlign(GpStringFormat* format, StringAlignment align);
	GpStatus WINGDIPAPI GdipCreatePen1(ARGB color, REAL width, Unit unit, GpPen** pen);
	GpStatus WINGDIPAPI GdipMeasureString(GpGraphics* graphics, GDIPCONST WCHAR* string, INT length, GDIPCONST GpFont* font,
		GDIPCONST RectF* layoutRect, GDIPCONST GpStringFormat* stringFormat, RectF* boundingBox, INT* codepointsFitted, INT* linesFilled);
	GpStatus WINGDIPAPI GdipCreatePath(FillMode brushMode, GpPath** path);
	//��������һ��FontStyleö��ֵ��λ�����:
	GpStatus WINGDIPAPI GdipAddPathString(GpPath* path, GDIPCONST WCHAR* string, INT length, GDIPCONST GpFontFamily* family,
		INT style, REAL emSize, GDIPCONST RectF* layoutRect, GDIPCONST GpStringFormat* format);
	GpStatus WINGDIPAPI GdipCreateSolidFill(ARGB color, GpSolidFill** brush);
	GpStatus WINGDIPAPI GdipFillPath(GpGraphics* graphics, GpBrush* brush, GpPath* path);
	GpStatus WINGDIPAPI GdipDrawPath(GpGraphics* graphics, GpPen* pen, GpPath* path);
	GpStatus WINGDIPAPI GdipCreateLineBrush(GDIPCONST PointF* point1, GDIPCONST PointF* point2, ARGB color1, ARGB color2,
		WrapMode wrapMode, GpLineGradient** lineGradient);
	GpStatus WINGDIPAPI GdipFillRectangle(GpGraphics* graphics, GpBrush* brush, REAL x, REAL y, REAL width, REAL height);
	GpStatus WINGDIPAPI GdipGraphicsClear(GpGraphics* graphics, ARGB color);
	GpStatus WINGDIPAPI GdipDrawRectangle(GpGraphics* graphics, GpPen* pen, REAL x, REAL y, REAL width, REAL height);
	GpStatus WINGDIPAPI GdipResetPath(GpPath* path);
	GpStatus WINGDIPAPI GdipLoadImageFromStream(IStream* stream, GpImage** image);
	GpStatus WINGDIPAPI GdipGetImageHeight(GpImage* image, UINT* height);
	GpStatus WINGDIPAPI GdipGetImageWidth(GpImage* image, UINT* width);
	GpStatus WINGDIPAPI GdipDrawImageRectRect(GpGraphics* graphics, GpImage* image, REAL dstx, REAL dsty, REAL dstwidth, REAL dstheight,
		REAL srcx, REAL srcy, REAL srcwidth, REAL srcheight, Unit srcUnit, GDIPCONST GpImageAttributes* imageAttributes,
		DrawImageAbort callback, VOID* callbackData);
	GpStatus WINGDIPAPI GdipDisposeImage(GpImage* image);
	GpStatus WINGDIPAPI GdipDeletePath(GpPath* path);
	GpStatus WINGDIPAPI GdipDeletePen(GpPen* pen);
	GpStatus WINGDIPAPI GdipDeleteBrush(GpBrush* brush);
	GpStatus WINGDIPAPI GdipDeleteGraphics(GpGraphics* graphics);
	GpStatus WINGDIPAPI GdipDeleteFont(GpFont* font);
	GpStatus WINGDIPAPI GdipDeleteStringFormat(GpStringFormat* format);
	GpStatus WINGDIPAPI GdipDeleteFontFamily(GpFontFamily* fontFamily);
	GpStatus WINGDIPAPI GdipCreateEffect(const GUID guid, GpEffect** effect);
	GpStatus WINGDIPAPI GdipDeleteEffect(GpEffect* effect);
	GpStatus WINGDIPAPI GdipCreateBitmapFromHBITMAP(HBITMAP hbm, HPALETTE hpal, GpBitmap** bitmap);
	GpStatus WINGDIPAPI GdipSetEffectParameters(GpEffect* effect, const VOID* params, const UINT size);
	GpStatus WINGDIPAPI GdipCreateBitmapFromGraphics(INT width, INT height, GpGraphics* target, GpBitmap** bitmap);
	GpStatus WINGDIPAPI GdipBitmapApplyEffect(GpBitmap* bitmap, GpEffect* effect, RECT* roi, BOOL useAuxData, VOID** auxData, INT* auxDataSize);
	GpStatus WINGDIPAPI GdipCreateBitmapFromStream(IStream* stream, GpBitmap** bitmap);
	GpStatus WINGDIPAPI GdipCloneBitmapArea(REAL x, REAL y, REAL width, REAL height, PixelFormat format, GpBitmap* srcBitmap, GpBitmap** dstBitmap);
	GpStatus WINGDIPAPI GdipGetImageGraphicsContext(GpImage* image, GpGraphics** graphics);
	GpStatus WINGDIPAPI GdipCreateBitmapFromScan0(INT width, INT height, INT stride, PixelFormat format, BYTE* scan0, GpBitmap** bitmap);
	GpStatus WINGDIPAPI GdipDrawRectangle(GpGraphics* graphics, GpPen* pen, REAL x, REAL y, REAL width, REAL height);
	GpStatus WINGDIPAPI GdipLoadImageFromFile(GDIPCONST WCHAR* filename, GpImage** image);
	GpStatus WINGDIPAPI GdipCreateHBITMAPFromBitmap(GpBitmap* bitmap, HBITMAP* hbmReturn, ARGB background);
	GpStatus WINGDIPAPI GdipDrawImage(GpGraphics* graphics, GpImage* image, REAL x, REAL y);
	GpStatus WINGDIPAPI GdipCreateHICONFromBitmap(GpBitmap* bitmap, HICON* hbmReturn);
	GpStatus WINGDIPAPI GdipCreateBitmapFromHICON(HICON hicon, GpBitmap** bitmap);
	GpStatus WINGDIPAPI GdipStringFormatGetGenericDefault(GpStringFormat** format);
	GpStatus WINGDIPAPI GdipDrawString(GpGraphics* graphics, GDIPCONST WCHAR* string, INT length, GDIPCONST GpFont* font,
		GDIPCONST RectF* layoutRect, GDIPCONST GpStringFormat* stringFormat, GDIPCONST GpBrush* brush);
	GpStatus WINGDIPAPI GdipSetStringFormatLineAlign(GpStringFormat* format, StringAlignment align);
}
////////////////////�ṹ
struct PLAYERLISTUNIT// �ڴ沥���б���Ŀ
{
	DWORD dwFlags;				// ��־��QKLIF_���������£�
	PWSTR pszName;				// ����
	PWSTR pszFile;				// �ļ���
	PWSTR pszTime;				// ʱ��
	PWSTR pszBookMark;			// ��ǩ��
	PWSTR pszBookMarkComment;	// ��ǩ��ע
	COLORREF crBookMark;		// ��ǩ��ɫ
	int iMappingIndexSearch;	// ����ʱӳ�䵽������
	int iMappingIndexSort;		// ����ʱӳ�䵽������
};
#define QKLIF_INVALID			0x00000001// ��Ŀ��Ч
#define QKLIF_IGNORED			0x00000002// ����
#define QKLIF_BOOKMARK			0x00000004// ����ǩ
#define QKLIF_DRAGMARK_CURRFILE	0x00000008// �����Ϸ�ʱ��Ч�����в����ļ���־
#define QKLIF_TIME				0x00000010// ���ڴ浵���ȡ�ļ�ʱ��Ч������ʱ���ַ���

struct LISTFILEHEADER	// �����б��ļ�ͷ
{
	CHAR cHeader[4];	// �ļ���ʼ��ǣ�ASCII�ַ�"QKPL"
	int iCount;			// ��Ŀ��
	DWORD dwVer;		// �浵�ļ��汾��QKLFVER_���������£�
	DWORD dwReserve;	// ����������Ϊ0
};
#define QKLFVER_1				0// ����汾���б��ļ���û�м�¼ʱ��Ĺ��ܣ����������Ѿ����Լ����б�������ˣ���Ϊ�������ţ��������Լ�������汾���ƣ��������ֶι�Ȼ�����ǵ�ѡ��2333��
#define QKLFVER_2				1

struct LISTFILEITEM		// �����б��ļ���Ŀͷ
{
	UINT uFlags;		// ��Ŀ��־
	DWORD dwReserve1;	// ����������Ϊ0
	DWORD dwReserve2;	// ����������Ϊ0
};

struct CURRINFO			//��ǰ��Ϣ
{
	LPWSTR pszContent;
	LPWSTR pszTitle;
	LPWSTR pszArtist;
	LPWSTR pszAlbum;
};

struct DRAWING_TIME		//�ӳ�����
{
	int i;				// �߶�
	BOOL bbool;			// ʱ���Ƿ�������
	ULONG uTime;		// ʱ��
};

struct DLGRESULT_LIST
{
	WCHAR szFileName[MAX_PATH];
};

struct MUSICINFO
{
	PWSTR pszTitle;
	PWSTR pszArtist;
	PWSTR pszAlbum;
	PWSTR pszComment;
	GpImage* pGdipImage;
	PWSTR pszLrc;
};

struct SONG_INFO
{
	PWSTR pszFile;
	MUSICINFO mi;
};

//�ο����ϣ�https://blog.csdn.net/u010650845/article/details/53520426
struct ID3v2_Header		//ID3v2��ǩͷ
{
	CHAR Header[3];		// "ID3"
	BYTE Ver;			// �汾��
	BYTE Revision;		// ���汾��
	BYTE Flag;			// ��־,ֻ��������λ
	BYTE Size[4];		// ��ǩ��С��28λ���ݣ�ÿ���ֽ����λ��ʹ�ã�������ǩͷ��10���ֽں����еı�ǩ֡
};

struct ID3v2_UnitHeader	//ID3v2֡ͷ
{
	CHAR ID[4];			// ֡��ʶ
	BYTE Size[4];		// ֡���ݵĴ�С��32λ���ݣ�������֡ͷ
	BYTE Flags[2];		// ��ű�־��ֻ������6 λ
};

struct FLAC_Header
{
	BYTE by;
	BYTE bySize[3];
};

struct LRCDATA
{
	float fTime;		// ��Ӧʱ��
	float fDelay;		// ��ʱ����һ���ʵ���һ���ʵ�ʱ��
	PWSTR pszLrc;		// ���
	int iOrgLength;		// ԭ�ĵ��ַ���
	int cy;				// �������в��ԣ�����ܸ߶�
	int iLastTop;		// ���ڹ�����ʻ��ƣ��ϴλ���ʱ�Ķ���
	int iDrawID;
};

struct LRCHSCROLLINFO
{
	int iIndex;					// ��ǰ��
	int cx1;					// ����1
	int cx2;					// ����2
	int x1;						// ��������1
	int x2;						// ��������2
	float fNoScrollingTime1;	// ͣ��ʱ��1
	float fNoScrollingTime2;	// ͣ��ʱ��2
	BOOL bWndSizeChangedFlag;	// �����ѱ��ı��־
	BOOL bShowCurr;				// ָʾ������Ŀ�Ƿ�ɼ�
};

struct LRCVSCROLLINFO
{
	int iSrcTop;
	int iDestTop;
	int iDistance;
	BOOL bDirection;			// TRUE ����
	float fDelay;
	float fTime;
};

struct TPARAM_FILLTIMECLM
{
	BOOL bJudgeItem;
};

struct GLOBALEFFECT
{
	HFX hFXChorus;
	BASS_DX8_CHORUS Chorus;
	HFX hFXCompressor;
	BASS_DX8_COMPRESSOR Compressor;
	HFX hFXDistortion;
	BASS_DX8_DISTORTION Distortion;
	HFX hFXEcho;
	BASS_DX8_ECHO Echo;
	HFX hFXFlanger;
	BASS_DX8_FLANGER Flanger;
	HFX hFXGargle;
	BASS_DX8_GARGLE Gargle;
	HFX hFXI3DL2Reverb;
	BASS_DX8_I3DL2REVERB I3DL2Reverb;
	HFX hFXReverb;
	BASS_DX8_REVERB Reverb;
	HFX hFXEQ[10];
	BASS_DX8_PARAMEQ EQ[10];
};

#define EFFECT_CHORUS		0x00000001
#define EFFECT_COMPRESSOR	0x00000002
#define EFFECT_DISTORTION	0x00000004
#define EFFECT_ECHO			0x00000008
#define EFFECT_FLANGER		0x00000010
#define EFFECT_GARGLE		0x00000020
#define EFFECT_I3DL2REVERB	0x00000040
#define EFFECT_REVERB		0x00000080
#define EFFECT_EQ			0x00000100
#define EFFECT_ALL			0xFFFFFFFF
////////////////////����
#define LISTFLAG_MUSIC		0x00000001
#define LISTFLAG_GROUP		0x00000002
//#define LISTFLAG_			0x00000004
//#define LISTFLAG_			0x00000008
//#define LISTFLAG_			0x00000010

#define LISTFILE_GROUP_ITEM		0	
#define LISTFILE_GROUP_GROUP	1
#define LISTFILE_ITEM_NORMAL	0

#define PROP_PLAYBTFLAG			L"QKProp.PlayBT.Flag"
#define PROP_BTHOTFLAG			L"QKProp.BTHot.Flag"
#define PROP_BTHOTFLAG_TRACK	L"QKProp.BTHot.IsTrack"
#define PROP_WNDPROC			L"QKProp.WndProc"
#define PROP_LVDRAGING			L"QKProp.LV.IsDraging"
#define PROP_LVDRAGITEM			L"QKProp.LV.OrgItem"
#define PROP_BOOKMARKCLRDLGBUF	L"QKProp.BookMark.DlgBuffer"

#define PROP_DTLRCFONTSIZE		L"QKProp.Settings.DTLrcFontSize"
#define PROP_DTLRCFONTWEIGHT	L"QKProp.Settings.DTLrcFontWeight"
#define PROP_DTLRCCLR1			L"QKProp.Settings.DTLrcColor1"
#define PROP_DTLRCCLR2			L"QKProp.Settings.DTLrcColor2"

#define PROP_OLEDROPLASTINDEX	L"QKProp.OLEDrop.LastIndex"
#define PROP_OLEDROPTARGETINDEX L"QKProp.OLEDrop.TargetInex"
#define PROP_OLEDROPINVALID		L"QKProp.OLEDrop.Invalid"

#define CLIPBOARDFMT_MYDRAGDROP L"QKClipboardFormat.MyDragDrop"

#define REPEATMODE_TOTALLOOP	0// ����ѭ��
#define REPEATMODE_RADOM		1// �������
#define REPEATMODE_SINGLE		2// ��������
#define REPEATMODE_SINGLELOOP	3// ����ѭ��
#define REPEATMODE_TOTAL		4// ���岥��

#define BTMBT_NORMAL			0
#define BTMBT_HOT				1
#define BTMBT_PUSHED			2

#define BTMBKM_INIT				WM_USER + 1
#define BTMBKM_GETREPEATMODE	WM_USER + 2
#define BTMBKM_SETPLAYBTICON	WM_USER + 3
#define BTMBKM_DOBTOPE			WM_USER + 4
//#define BTMBKM_	WM_USER + 

#define MAINWND_REDRAWBOOKMARK	WM_USER + 1

#define LEFTBKM_SETMAX			WM_USER + 1// (Max, 0)
#define LEFTBKM_REDRAWSB		WM_USER + 2// (�Ƿ��������, 0)

#define GDIOBJOPE_REFRESH		0
#define GDIOBJOPE_DELETE		1

#define SPESTEP_BAR				7
#define SPESTEP_MAX				11

#define THREADFLAG_STOP			1
#define THREADFLAG_STOPED		2
#define THREADFLAG_WORKING		3
#define THREADFLAG_ERROR		4

#define SPECOUNT				33

#define DLGTYPE_LOADLIST		1
#define DLGTYPE_SAVELIST		2

#define LRCHITTEST_LAST			-1
#define LRCHITTEST_PLAY			-2
#define LRCHITTEST_NEXT			-3
#define LRCHITTEST_CLOSE		-4

#define LRCSTATE_STOP			1
#define LRCSTATE_LOADING		2
#define LRCSTATE_NOLRC			3
#define LRCSTATE_NORMAL			4

#define MYCLR_LISTGRAY			0xF3F3F3
#define MYCLR_LISTPLAYING		0xE6E8B1
#define MYCLR_LISTGROUP			0xBDFAFF
#define MYCLR_BTHOT				0xE6E8B1
#define MYCLR_BTPUSHED			0xE6E88C
#define MYCLR_TBTRACK			0xCECECE

#define MAINWNDCLASS			L"QKPlayer.WndClass.Main"
#define BKWNDCLASS				L"QKPlayer.WndClass.BK"
#define LRCWNDCLASS				L"QKPlayer.WndClass.Lrc"
#define TBGHOSTWNDCLASS			L"QKPlayer.WndClass.TaskbarGhost"
#define WNDCLASS_LIST			L"QKPlayer.WndClass.List"

#define SBV_INVALIDVALUE		-2

////////////////////�ؼ�ID
#define IDC_BK_LEFT					800
#define IDC_BK_PIC					801
#define IDC_BK_SPE					802
#define IDC_BK_BOTTOMBTBK			803
#define IDC_BK_RIGHT				804
#define IDC_BK_SEARCH				805
#define IDC_BK_RIGHTBTBK			806
#define IDC_BK_TLSB					807
#define IDC_BK_WAVES				808
#define IDC_BK_LIST					809

#define IDC_ST_WAVES				302

#define IDC_ST_TOP					305
#define IDC_ST_LRC					306
#define IDC_ST_BTBACK				307
#define IDC_ST_BOTTOM				308
#define IDC_ST_BOTTOMCTRLBK			309
#define IDC_ST_LISTNAME				315

#define IDC_LV_PLAY					401
#define IDC_TL_PLAY					402

#define IDC_TB_PGS					501
#define IDC_TB_LRCSCROLL			502

#define IDC_BT_LAST					602
#define IDC_BT_PLAY					603
#define IDC_BT_STOP					604
#define IDC_BT_NEXT					605
#define IDC_BT_LRC					606
#define IDC_BT_JUMP					607
#define IDC_BT_OPEN					608
#define IDC_BT_LOADLIST				609
#define IDC_BT_SAVE					610
#define IDC_BT_EMPTY				611
#define IDTBB_LAST					612
#define IDTBB_PLAY					613
#define IDTBB_NEXT					614
#define IDC_BT_MORE					615
#define IDC_BT_SEARCH				616
#define IDC_BT_MANAGING				617

#define IDC_CB_REPEATMODE			700

#define IDC_ED_SEARCH				800

#define IDC_SEB						900

#define IDT_PGS						101
#define IDT_DRAWING_WAVES			102
#define IDT_DRAWING_VU     			103
#define IDT_DRAWING_LRC				104
#define IDT_VU_SPE_TIME				105
#define IDT_LRC						106
#define IDT_DRAWING_SPE				107
#define IDT_LRCSCROLL				108
#define IDT_ANIMATION				109
#define IDT_ANIMATION2				110

#define TIMERELAPSE_PGS				500
#define TIMERELAPSE_WAVES			0
#define TIMERELAPSE_VU_SPE			50
#define TIMERELAPSE_LRC				200
#define TIMERELAPSE_VU_SPE_TIME		500
#define TIMERELAPSE_LRCWND			600
#define TIMERELAPSE_TIME			500
#define TIMERELAPSE_LRCSCROLL		1000
#define TIMERELAPSE_ANIMATION		60
#define TIMERELAPSE_ANIMATION2		30

#define IDMI_NULL					99

#define IDMI_OPEN_FILE				101
#define IDMI_OPEN_FOLDER			102

#define IDMI_TL_PLAY				110
#define IDMI_TL_DELETE_FROM_LIST	111
#define IDMI_TL_DELETE				112
#define IDMI_TL_OPEN_IN_EXPLORER	113
#define IDMI_TL_RENAME				114
#define IDMI_TL_INFO				115
#define IDMI_TL_ADDBOOKMARK			116
#define IDMI_TL_REMOVEBOOKMARK		117
#define IDMI_TL_NEXTBOOKMARK		118
#define IDMI_TL_LASTBOOKMARK		119
#define IDMI_TL_IGNORE				120
#define IDMI_TL_PLAYLATER			121

#define IDMI_LRC_SHOW				120
#define IDMI_LRC_LRCSHOW			121
#define IDMI_LRC_FORCETWOLINES		122

#define IDMI_MORE_ABOUT				130
#define IDMI_MORE_SETTING			131

#define IDMI_LS_PLAY				140
#define IDMI_LS_COPY				141

#define IDMI_LM_SORT_DEF			150
#define IDMI_LM_SORT_FILENAME		151
#define IDMI_LM_SORT_NAME			152
#define IDMI_LM_SORT_CTIME			153
#define IDMI_LM_SORT_MTIME			154
#define IDMI_LM_SORT_ASCENDING		155
#define IDMI_LM_SORT_DESCENDING		156
#define IDMI_LM_FIXSORT				157
#define IDMI_LM_DETAIL				158
#define IDMI_LM_BOOKMARK			159
#define IDMI_LM_SORT_REVERSE		160
#define IDMI_LM_SETLVDEFWIDTH		161
#define IDMI_LM_UPDATETIME			162
#define IDMI_LM_NOBOOKMARK			163

#define IDMI_PL_SEPARATE			170
#define IDMI_PL_SHOW				171

#define MAXPROFILEBUFFER			48
#define PROFILENAME					L"\\Data\\QKPlayerConfig.ini"
#define DEFPICFILENAME				L"\\Data\\DefPic.png"
#define DATADIR						L"\\Data\\"
#define LISTDIR						L"\\List\\"

#define PPF_SECTIONLRC				L"Lyric"

#define PPF_KEY_DEFTEXTCODE			L"DefTextCode"
#define PPF_KEY_LRCDIR				L"LyricsDir"
#define PPF_KEY_DISABLEVANIMATION	L"DisableVAnimation"
#define PPF_KEY_DISABLEWORDBREAK	L"DisableWordBreak"
#define PPF_KEY_DISABLEDTLRCSHANDOW L"DisableDTLrcShandow"
#define PPF_KEY_FONTNAME			L"DTLrcFontName"
#define PPF_KEY_FONTSIZE			L"DTLrcFontSize"
#define PPF_KEY_FONTWEIGHT			L"DTLrcFontWeight"
#define PPF_KEY_DTLRCCLR1			L"DTLrcClr1"
#define PPF_KEY_DTLRCCLR2			L"DTLrcClr2"
#define PPF_KEY_DTLRCTRANSPARENT	L"DTLrcTransparent"
#define PPF_KEY_DTLRCSPACELINE		L"DTLrcSpaceLine"
//#define PPF_KEY_

#define DEVLIST_DISABLED			0x00000001
#define DEVLIST_CURRDEV				0x00000002
#define DEVLIST_DEFAULT				0x00000004
#define DEVLIST_INIT				0x00000008
const PCWSTR c_szBtmTip[15] =
{
	L"��һ��",
	L"����/��ͣ",
	L"ֹͣ",
	L"��һ��",
	L"���",
	L"ѭ����ʽ",
	L"��������",
	L"��ʾ/���ز����б�",
	L"���ڷ����ڲ���",
	L"����",
	L"ѭ����ʽ������ѭ��",
	L"ѭ����ʽ���������",
	L"ѭ����ʽ����������",
	L"ѭ����ʽ������ѭ��",
	L"ѭ����ʽ�����岥��"
};

struct
{
	PCWSTR pszText;
	int Setting[10];
}
const c_EQSetting[23] =
{
	{L"��",			{0,0,0,0,0,0,0,0,0,0}},
	{L"ACG",		{4,6,3,0,0,2,5,1,1,4}},
	{L"��ҥ",		{0,3,0,0,1,4,5,3,0,2}},
	{L"����",		{6,4,6,2,0,0,0,0,0,0}},
	{L"����&����",	{6,5,6,1,0,0,1,3,4,0}},
	{L"����",		{2,6,4,0,-2,-1,2,2,1,3}},
	{L"�ŷ�",		{4,2,2,0,-1,3,4,1,1,3}},
	{L"�ŵ�",		{4,4,3,2,-1,-1,0,1,3,4}},
	{L"���",		{0,2,3,0,0,2,3,1,0,0}},
	{L"����",		{4,5,7,0,1,3,4,4,3,0}},
	{L"����",		{2,0,0,0,0,0,0,0,-1,-1}},
	{L"����",		{5,6,5,0,-1,1,0,1,4,3}},
	{L"�ؽ���",		{-2,5,4,-2,-2,-1,2,3,1,4}},
	{L"˵��",		{5,5,4,0,-2,1,3,0,3,4}},
	{L"��ʿ",		{3,3,1,2,-1,-1,0,1,2,4}},
	{L"�ֳ�",		{5,5,6,0,-1,0,3,4,6,5}},
	{L"����",		{-2,-3,-3,0,1,4,3,2,-1,-2}},
	{L"����",		{-1,-1,0,1,4,3,1,0,-1,1}},
	{L"ҡ��",		{4,3,3,1,0,-1,0,1,2,4}},
	{L"���",		{0,0,0,0,0,0,0,-2,-2,0}},
	{L"��͵���",	{3,2,1,0,0,0,0,-2,-2,-2}},
	{L"��͸���",	{-3,-1,0,0,0,0,0,-1,3,2}},
	{L"���ص���",	{6,5,8,2,0,0,0,0,0,0}},
};

#define EFFECTWNDTABCOUNT 10
const float c_EQCenter[10] = { 31,62,125,250,500,1000,2000,4000,8000,16000 };

struct GLOBALRES
{
	HBITMAP hbmpNewItem;
	HICON hiLocate;			// ��λ
	HICON hiAdd;			// ����
	HICON hiLoadList;		// ��ȡ�б�
	HICON hiSaveList;		// �����б�
	HICON hiEmpty;			// ���
	HICON hiSearch;			// ����
	HICON hiBTPlaySetting;	// ��������
	HICON hiBTPlayList;		// ��ʾ/���ز����б�
	HICON hiRMRadom;		// �������
	HICON hiRMSingle;		// ��������
	HICON hiRMTotal;		// ���岥��
	HICON hiRMSingleLoop;	// ����ѭ��
	HICON hiRMTotalLoop;	// ����ѭ��
	HICON hiBTLast;			// ��һ��
	HICON hiBTPlay;			// ����
	HICON hiBTPause;		// ��ͣ
	HICON hiBTStop;			// ֹͣ
	HICON hiBTNext;			// ��һ��
	HICON hiBTLrc;			// ���
	HICON hiBTMore;			// ����
	HICON hiListManaging;	// �����б�����
	HICON hiDTLLast;
	HICON hiDTLPlay;
	HICON hiDTLPause;
	HICON hiDTLNext;
	HICON hiDTLClose;
	HICON hiTick;
};

struct GLOBALCONTEXT
{
	HBRUSH hbrCyanDeeper;	// ������ˢ
	HBRUSH hbrMyBule;
	UINT uLrcDTFlags;		// ǿ��˫�б�־
	int DS_CYPROGBAR;
	int DS_CYBTBK;
	int DS_CYSPE;
	int DS_CYSPEHALF;
	int DS_CXSPEBAR;
	int DS_CXSPEBARDIV;
	int DS_CXSPE;
	int DS_CXSPEHALF;
	int DS_CXBTMBTBK;
	int DS_CXPIC;
	int DS_EDGE;
	int DS_CYTOPBK;
	int DS_BT;
	int DS_CXRITBT;
	int DS_GAP;
	int DS_LARGEIMAGE;
	int DS_CYRITBK;
	int DS_CYSTLISTNAME;
	int DS_CXTIME;
	int DS_CXWAVESLINE;
	int DS_CYTOPTITLE;
	int DS_CXTOPTIP;
	int DS_CYTOPTIP;
	int DS_GAPTOPTIP;
	int DS_CXABOUTPIC;
	int DS_CYABOUTPIC;
	int DS_LVTEXTSPACE;
	int DS_CXLRCTB;
	int DS_DEFCXLV;
	int DS_DTLRCEDGE;
	int DS_STDICON;
	int DS_DTLRCFRAME;
	int DS_CXDTLRCBTNRGN;
	int DS_CYLVITEM;
	int DS_LRCSHOWGAP;
	int DS_CXDRAGDROPICON;
	int DS_CYDRAGDROPICON;
};
#define SIZE_CYPROGBAR			35
#define SIZE_CYBTBK				40
#define SIZE_CYSPE				80
#define SIZE_CYSPEHALF			SIZE_CYSPE / 2
#define SIZE_CXSPEBAR			5
#define SIZE_CXSPEBARDIV		1
#define SIZE_CXSPE			    200
#define SIZE_CXSPEHALF			SIZE_CXSPE / 2
#define SIZE_CXBTMBTBK			430
#define SIZE_CXPIC				200//��ʾ�����ʱ
#define SIZE_EDGE				20
#define SIZE_CYTOPBK			90
#define SIZE_BT					35
#define SIZE_CXRITBT			58
#define SIZE_GAP				4
#define SIZE_LARGEIMAGE			2000
#define SIZE_CYRITBK			110
#define SIZE_CYSTLISTNAME		22
#define SIZE_CXTIME				100
#define SIZE_CXWAVESLINE		2
#define SIZE_CYTOPTITLE			26
#define SIZE_CXTOPTIP			50
#define SIZE_CYTOPTIP			18
#define SIZE_GAPTOPTIP			8
#define SIZE_CXABOUTPIC			300
#define SIZE_CYABOUTPIC			148
#define SIZE_LVTEXTSPACE		5
#define SIZE_CXLRCTB			20
#define SIZE_DEFCXLV			372
#define SIZE_DTLRCEDGE			2
#define SIZE_STDICON			29
#define SIZE_DTLRCFRAME			8
#define SIZE_CYLVITEM			22
#define SIZE_LRCSHOWGAP			10
#define SIZE_CXDRAGDROPICON		200
#define SIZE_CYDRAGDROPICON		150

#define DPIS_CYPROGBAR GC.DS_CYPROGBAR
#define DPIS_CYBTBK GC.DS_CYBTBK
#define DPIS_CYSPE GC.DS_CYSPE
#define DPIS_CYSPEHALF GC.DS_CYSPEHALF
#define DPIS_CXSPEBAR GC.DS_CXSPEBAR
#define DPIS_CXSPEBARDIV GC.DS_CXSPEBARDIV
#define DPIS_CXSPE GC.DS_CXSPE
#define DPIS_CXSPEHALF GC.DS_CXSPEHALF
#define DPIS_CXBTMBTBK GC.DS_CXBTMBTBK
#define DPIS_CXPIC GC.DS_CXPIC
#define DPIS_EDGE GC.DS_EDGE
#define DPIS_CYTOPBK GC.DS_CYTOPBK
#define DPIS_BT GC.DS_BT
#define DPIS_CXRITBT GC.DS_CXRITBT
#define DPIS_GAP GC.DS_GAP
#define DPIS_LARGEIMAGE GC.DS_LARGEIMAGE
#define DPIS_CYRITBK GC.DS_CYRITBK
#define DPIS_CYSTLISTNAME GC.DS_CYSTLISTNAME
#define DPIS_CXTIME GC.DS_CXTIME
#define DPIS_CXWAVESLINE GC.DS_CXWAVESLINE
#define DPIS_CYTOPTITLE GC.DS_CYTOPTITLE
#define DPIS_CXTOPTIP GC.DS_CXTOPTIP
#define DPIS_CYTOPTIP GC.DS_CYTOPTIP
#define DPIS_GAPTOPTIP GC.DS_GAPTOPTIP
#define DPIS_CXABOUTPIC GC.DS_CXABOUTPIC
#define DPIS_CYABOUTPIC GC.DS_CYABOUTPIC
#define DPIS_LVTEXTSPACE GC.DS_LVTEXTSPACE
#define DPIS_CXLRCTB GC.DS_CXLRCTB
#define DPIS_DEFCXLV GC.DS_DEFCXLV
#define DPIS_DTLRCEDGE GC.DS_DTLRCEDGE
#define DPIS_STDICON GC.DS_STDICON
#define DPIS_DTLRCFRAME GC.DS_DTLRCFRAME
#define DPIS_CXDTLRCBTNRGN GC.DS_CXDTLRCBTNRGN
#define DPIS_CYLVITEM GC.DS_CYLVITEM
#define DPIS_LRCSHOWGAP GC.DS_LRCSHOWGAP
#define DPIS_CXDRAGDROPICON GC.DS_CXDRAGDROPICON
#define DPIS_CYDRAGDROPICON GC.DS_CYDRAGDROPICON
struct SETTINGS
{
	BOOL bForceTwoLines;
	BOOL bAscending;
	BOOL bNoBookMarkWhenSort;
	BOOL bLrcAnimation;
	BOOL bDTLrcShandow;
	UINT uDefTextCode;
	PWSTR pszLrcDir;
	PWSTR pszDTLrcFontName;
	UINT uDTLrcFontSize;
	UINT uDTLrcFontWeight;
	UINT uDTLrcTransparent;
	UINT crDTLrc1;
	UINT crDTLrc2;
	PWSTR pszDTLrcSpaceLine;
};

#define DPI(i) i * g_iDPI / USER_DEFAULT_SCREEN_DPI