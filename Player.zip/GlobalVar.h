#pragma once
#include "Windows.h"
#include "bass.h"
#include "Shobjidl.h"
#include "MyProject.h"
#include "Function.h"
extern HWND				g_hMainWnd;
extern HWND				g_hLV;
extern HWND				g_hTBProgess;
extern HWND				g_hLrcWnd;
extern HWND				g_hBKTop;
extern HWND				g_hBKBottom1;
extern HWND				g_hBKBottom2;
extern HWND				g_hComboBox;

extern HWND				g_hTL;
extern HWND				g_hBKLeft;
extern HWND				g_hBKBtm;
extern HWND				g_hBKRight;
extern HWND				g_hTBLrc;
extern HWND				g_hBKWaves;
extern HWND				g_hSEB;

extern HINSTANCE		g_hInst;
extern HFONT			g_hFont;//Ĭ�Ͼź�΢���ź�
extern HSTREAM			g_hStream;
extern QKARRAY			g_pList;

extern int				g_iCurrFileIndex;//���в����ļ��б���������0��ʼ
extern int				g_iCurrLrcIndex;//-1����һ�䵫������
extern int				WM_TASKBARBUTTONCREATED;//��������ť�������
extern ITaskbarList4*	g_pITaskbarList;

extern QKARRAY          g_LrcData;         //QKArray�������Ϣ
extern QKARRAY          g_LrcDataTime;         //QKArray�����ʱ��
extern QKARRAY			g_Lrc;

extern int				g_iLrcState;                //�����ʱ�־

extern GLOBALRES		GR;
extern GLOBALCONTEXT	GC;
extern QKARRAY			g_ItemData;
extern BOOL				g_bPlayIcon;
extern SETTINGS			GS;
extern int				g_iDPI;
extern float			g_fTime;
extern PWSTR			g_pszDefPic;
extern PWSTR			g_pszDataDir;
extern PWSTR			g_pszListDir;
extern PWSTR			g_pszCurrDir;
extern PWSTR			g_pszProfie;
extern int				g_iLaterPlay;
extern BOOL				g_bHMUSIC;
extern UINT				g_uMyClipBoardFmt;
extern HWND				g_hBKList;
extern BOOL				g_bListSeped;
extern BOOL				g_bListHidden;