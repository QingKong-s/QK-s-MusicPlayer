#include "Windows.h"
#include "bass.h"
#include "Shobjidl.h"
#include "MyProject.h"
#include "resource.h"
#include "Function.h"	

HWND			g_hMainWnd				= NULL;//������
HWND			g_hLV					= NULL;
HWND			g_hTBProgess			= NULL;
HWND			g_hLrcWnd				= NULL;
HWND			g_hBKTop				= NULL;
HWND			g_hBKBottom1			= NULL;
HWND			g_hBKBottom2			= NULL;
HWND			g_hComboBox				= NULL;

HWND			g_hTL					= NULL;
HWND			g_hBKLeft				= NULL;
HWND			g_hBKBtm				= NULL;
HWND			g_hBKRight				= NULL;
HWND			g_hTBLrc				= NULL;
HWND			g_hBKWaves				= NULL;
HWND			g_hSEB					= NULL;

HINSTANCE		g_hInst					= NULL;
HFONT			g_hFont					= NULL;
HSTREAM			g_hStream				= NULL;
QKARRAY			g_pList					= NULL;

int				g_iCurrFileIndex		= -1;
int				g_iCurrLrcIndex			= 0;
int				WM_TASKBARBUTTONCREATED = 0;
ITaskbarList4*	g_pITaskbarList			= NULL;

QKARRAY         g_LrcData				= NULL;
QKARRAY         g_LrcDataTime			= NULL;
QKARRAY			g_Lrc=NULL;

int             g_iLrcState				= LRCSTATE_STOP;

GLOBALRES		GR						= { 0 };
GLOBALCONTEXT	GC;
QKARRAY			g_ItemData;
BOOL			g_bPlayIcon				= FALSE;
SETTINGS		GS;
int				g_iDPI;
float			g_fTime					= 0;
PWSTR			g_pszDefPic				= NULL;
PWSTR			g_pszDataDir;
PWSTR			g_pszListDir;
PWSTR			g_pszCurrDir;
PWSTR			g_pszProfie;
int				g_iLaterPlay			= -1;
BOOL			g_bHMUSIC;
UINT			g_uMyClipBoardFmt;
HWND			g_hBKList;
BOOL			g_bListSeped			= FALSE;
BOOL			g_bListHidden			= FALSE;