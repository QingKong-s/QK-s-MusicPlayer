﻿/**************************************
 *      QingKong's Music Player
 *   (C) 2021-2022 晴空 保留所有权利
 *   谨以此作，纪念我五年的Win32生涯
 ***************************************/
#pragma comment(linker,"\"/manifestdependency:type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")// 使用6.0版通用组件库，老版的太难看√都不用

#define _CRT_SECURE_NO_WARNINGS

#include "GlobalVar.h"
#include "Function.h"
#include "Resource.h"
#include "MyProject.h"
#include <Windows.h>
#include <commdlg.h>
#include <shlwapi.h>
#include "bass.h"
#include <UxTheme.h>
#include "math.h"
#include "stdio.h"
#include "CommCtrl.h"
#include "vsstyle.h"
#include "Shobjidl.h"
#include "windowsx.h"
#include "QKCtrl.h"
#include "LrcWnd.h"
#include "shlobj_core.h"
#include "dwmapi.h"
#include "OLEDragDrop.h"

//#include "GlobalVar.h"
//#include "Function.h"
//#include "Resource.h"
//#include "MyProject.h"
//#include <Windows.h>
//#include <commdlg.h>
//#include <shlwapi.h>
//#include "bass.h"
//#include <UxTheme.h>
//#include "math.h"
//#include "stdio.h"
//#include "CommCtrl.h"
//#include "vsstyle.h"
//#include "Shobjidl.h"
//#include "windowsx.h"
//#include "QKCtrl.h"
//#include "LrcWnd.h"
//#include "shlobj_core.h"
//#include "dwmapi.h"
//#include "OLEDragDrop.h"
float           m_fDefSpeed                 = 0;            //默认速度，调速用
SONG_INFO       m_CurrSongInfo              = { 0 };        //当前信息（在顶部显示）
ULONGLONG       m_llLength                  = 0;            //总长度，单位毫秒，进度条单位为百毫秒
float           m_fSpeedChanged             = SBV_INVALIDVALUE,                         //-1~5
                m_fBlanceChanged            = SBV_INVALIDVALUE,                         //-1~1
                m_fVolChanged               = SBV_INVALIDVALUE;                         //0~1
BOOL            m_bSlient                   = FALSE;
GLOBALEFFECT    m_GlobalEffect              = { 0 };


HBITMAP         m_hbmpLeftBK                = NULL;
HBITMAP         m_hbmpLeftBK2               = NULL;
HBITMAP         m_hbmpBookMark              = NULL;

HDC             m_hcdcLeftBK                = NULL;         // 原始（除了封面和顶部提示信息外没有其他视觉元素）
HDC             m_hcdcLeftBK2               = NULL;         // 所有绘制工作均已完成
HDC             m_hcdcBookMark              = NULL;
 
HFONT           m_hFontDrawing              = QKCreateFont(L"微软雅黑", 13);            //绘制用字体

DWORD           m_dwThreadFlags[2]          = { THREADFLAG_STOP,THREADFLAG_STOP };  //线程工作状态标志
HANDLE          m_hThread[2]                = { 0 };        //线程句柄
DWORD*          m_dwWavesData               = NULL;         //指向波形信息数组，左声道：低WORD，右声道：高WORD
DWORD           m_dwWavesDataCount          = 0;            //波形计数

WCHAR           m_szCurrFile[MAX_PATH]      = { 0 };        //当前文件

BOOL            m_IsDraw[3]                 = { 0 };        //绘制标志
DRAWING_TIME    m_TimeStru_VU[2]            = { 0 };        //延迟下落
DRAWING_TIME    m_TimeStru_Spe[128]    = { 0 };             //延迟下落

RECT            m_LeftStaticRect            = { 0 };        //右侧静态客户区

ULONG_PTR       m_uGPToken                  = NULL;         //GDI+令牌

BOOL            m_bLrcShow                  = TRUE;
RECT            m_rcLrcShow                 = { 0 };
BOOL            m_iSearchResult             = -1;

int             m_xSpe                      = 0,
                m_ySpe                      = 0,
                m_xBtmBK                    = 0,
                m_yBtmBK                    = 0,
                m_xWaves                    = 0,
                m_yWaves                    = 0,
                m_cxLeftBK                  = 0,
                m_cyLeftBK                  = 0,
                m_cxLrcShow                 = 0,
                m_cyLrcShow                 = 0;

int             m_iLrcSBPos                 = -1;
BOOL            m_bLockLrcScroll            = FALSE;

int             m_iLrcCenter                = -1;
int             m_iLrcMouseHover            = -1;
int             m_iLrcFixedIndex            = -1;

int             m_cxLV                      = 0;

int             m_bSort                     = FALSE;
LRCHSCROLLINFO  m_LrcHScrollInfo            = { -1 };// 歌词水平滚动信息；仅适用于当前播放行
LRCVSCROLLINFO  m_LrcVScrollInfo            = { 0 };

HWND            m_hTBGhost                  = NULL;

int             m_iDrawingID                = 0;// 歌词项目是否可见，此ID一去不回头，绘制21亿次后才有可能重复
CDropTarget*    m_pDropTarget               = NULL;

///////////////////////前向声明
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_RitBK(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_BtmBTBK(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_BtmBT(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_BtmBK(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_LeftBK(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_TBGhost(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK WndProc_PlayList(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK DlgProc_List(HWND, UINT, WPARAM, LPARAM);
void    CALLBACK TimerProc(HWND, UINT, UINT_PTR, DWORD);
void ShowError(LPCWSTR, LPCWSTR, BOOL IsShowErrCode = TRUE);
void StopThread_MusicTime();
void List_FillMusicTimeColumn(BOOL bJudgeItem);
void Stop(BOOL bNoGap = FALSE);
void AutoNext();
DWORD WINAPI Thread_GetWavesData(void*);
void Lrc_ParseLrcData(void*, int, BOOL, QKARRAY*, QKARRAY*, int);
void StopThread_Waves();

void GDIObj_LeftBK(DWORD dwOpe = GDIOBJOPE_REFRESH);
void ReleaseCurrInfo();
//void PlayNext();
void UpdateLeftBK();
void ClearLrcData();
int LrcShowHitTest(POINT pt);
void Settings_Read();
void GlobalEffect_ResetToDefault(int);

#define UI_RedrawBookMarkPos() SendMessageW(g_hBKList, MAINWND_REDRAWBOOKMARK, 0, 0)

/*
 * 目标：
 *
 * 参数：
 *
 * 返回值：
 * 操作简述：
 * 备注：
 */
///////////////////////
/*
 * 目标：入口点
 *
 * 参数：
 * hInstance 实例句柄
 * hPrevInstance 先前实例句柄（恒为NULL）
 * lpCmdLine 命令行
 * nCmdShow 显示方式
 *
 * 返回值：
 * 操作简述：
 * 备注：
 * 
 */
int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
    CoInitialize(NULL);
    OleInitialize(NULL);
    //////////////保存实例句柄
    g_hInst = hInstance;
    GR =
    {
        NULL,
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_JUMP), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_OPEN), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_LOAD), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_SAVE), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_EMPTY), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_SEARCH), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_SETTING), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_PLAYLIST), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_RMRADOM), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_RMSINGLE), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_RMTOTAL), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_RMSINGLELOOP), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_RMTOTALLOOP), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_LAST), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_PLAY), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_PAUSE), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_STOP), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_NEXT), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_LRC), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_MORE), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_LISTMANAGING), IMAGE_ICON, 0, 0, 0),
		(HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_BTLAST_LRC), IMAGE_ICON, 0, 0, 0),
	    (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_BTPLAY_LRC), IMAGE_ICON, 0, 0, 0),
	    (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_BTPAUSE_LRC), IMAGE_ICON, 0, 0, 0),
	    (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_BTNEXT_LRC), IMAGE_ICON, 0, 0, 0),
	    (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_BTCLOSE_LRC), IMAGE_ICON, 0, 0, 0),
        (HICON)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDI_TICK), IMAGE_ICON, 0, 0, 0)
	};
    GC =
    {
        CreateSolidBrush(QKCOLOR_CYANDEEPER),
        CreateSolidBrush(0xDA9E46),
        0
    };
    
    GlobalEffect_ResetToDefault(EFFECT_ALL);
    //////////////初始化自绘控件
    QKCtrlInit();
    LrcWnd_Init();
    //////////////创建字体
    g_hFont = QKCreateFont(L"微软雅黑", 9);
    //////////////初始化数组
    g_Lrc = QKArray_Create(0);
    g_ItemData = QKArray_Create(0);
    //////////////保存运行目录
    PWSTR p = new WCHAR[MAX_PATH];
    GetModuleFileNameW(NULL, p, MAX_PATH);
    PathRemoveFileSpecW(p);

    g_pszDefPic = new WCHAR[lstrlenW(p) + lstrlenW(DEFPICFILENAME) + 1];
    lstrcpyW(g_pszDefPic, p);
    lstrcatW(g_pszDefPic, DEFPICFILENAME);

    g_pszDataDir = new WCHAR[lstrlenW(p) + lstrlenW(DATADIR) + 1];
    lstrcpyW(g_pszDataDir, p);
    lstrcatW(g_pszDataDir, DATADIR);

    g_pszListDir= new WCHAR[lstrlenW(p) + lstrlenW(LISTDIR) + 1];
    lstrcpyW(g_pszListDir, p);
    lstrcatW(g_pszListDir, LISTDIR);

    g_pszCurrDir= new WCHAR[lstrlenW(p) + 2];
    lstrcpyW(g_pszCurrDir, p);
    lstrcatW(g_pszCurrDir, L"\\");

    g_pszProfie = new WCHAR[lstrlenW(p) + lstrlenW(PROFILENAME) + 1];
    lstrcpyW(g_pszProfie, p);
    lstrcatW(g_pszProfie, PROFILENAME);

    delete[] p;

    Settings_Read();
    //////////////注册任务栏按钮创建消息
    WM_TASKBARBUTTONCREATED = RegisterWindowMessageW(L"TaskbarButtonCreated");
    g_uMyClipBoardFmt = RegisterClipboardFormatW(CLIPBOARDFMT_MYDRAGDROP);
    //////////////启动GDI+
    GdiplusStartupInput gpsi = { 0 };
    gpsi.GdiplusVersion = 1;
    if (GdiplusStartup(&m_uGPToken, &gpsi, NULL) != Ok)
    {
        MessageBoxW(NULL, L"GDI+启动失败！", L"错误", MB_ICONERROR);
        return 0;
    }
    //////////////准备内存场景
    m_hcdcLeftBK = CreateCompatibleDC(NULL);
    m_hcdcLeftBK2 = CreateCompatibleDC(NULL);
    SelectObject(m_hcdcLeftBK2, m_hFontDrawing);
    SetBkMode(m_hcdcLeftBK, TRANSPARENT);
    SetBkMode(m_hcdcLeftBK2, TRANSPARENT);
    //////////////注册主窗口
    WNDCLASSEXW wcex = { 0 };
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.hInstance = hInstance;
    wcex.hIcon = (HICON)LoadImageW(hInstance, MAKEINTRESOURCEW(IDI_MAIN), IMAGE_ICON, 0, 0, LR_SHARED);
    wcex.lpszClassName = MAINWNDCLASS;
    wcex.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    if (!RegisterClassExW(&wcex))
    {
		MessageBoxW(NULL, L"窗口类注册失败！", L"错误", MB_ICONERROR);
		return 0;
	}
	//////////////注册任务栏幽灵（注意要与主窗口图标保持一致）
	wcex.hbrBackground = NULL;
	wcex.lpszClassName = TBGHOSTWNDCLASS;
	wcex.lpfnWndProc = WndProc_TBGhost;
	if (!RegisterClassExW(&wcex))
	{
		MessageBoxW(NULL, L"窗口类注册失败！", L"错误", MB_ICONERROR);
		return 0;
	}
	//////////////注册列表容器
	wcex.lpszClassName = WNDCLASS_LIST;
	wcex.lpfnWndProc = WndProc_PlayList;
	if (!RegisterClassExW(&wcex))
	{
		MessageBoxW(NULL, L"窗口类注册失败！", L"错误", MB_ICONERROR);
		return 0;
	}
	//////////////注册通用背景
	HMODULE hLib = LoadLibraryW(L"User32.dll");
    wcex.lpfnWndProc = (WNDPROC)GetProcAddress(hLib, "DefWindowProcW");
    FreeLibrary(hLib);
    wcex.lpszClassName = BKWNDCLASS;
    if (!RegisterClassExW(&wcex))
    {
        MessageBoxW(NULL, L"窗口类注册失败！", L"错误", MB_ICONERROR);
        return 0;
    }
    //////////////创建窗口
#if _WIN32_WINNT >= _WIN32_WINNT_WIN10
    g_hMainWnd = CreateWindowExW(0, MAINWNDCLASS, L"未播放 - 晴空的音乐播放器", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
		CW_USEDEFAULT, 0, GetDpiForSystem() * 1000 / 96, GetDpiForSystem() * 640 / 96, NULL, NULL, hInstance, NULL);
#else
    g_hMainWnd = CreateWindowExW(0, MAINWNDCLASS, L"未播放 - 晴空的音乐播放器", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, 0, 1000, 640, NULL, NULL, hInstance, NULL);
#endif

    if (!g_hMainWnd)
    {
        MessageBoxW(NULL, L"窗口创建失败！", L"错误", MB_ICONERROR);
        return 0;
    }
    //DragAcceptFiles(g_hMainWnd, TRUE);
    ShowWindow(g_hMainWnd, nCmdShow);
    UpdateWindow(g_hMainWnd);
    BASS_Init(-1, 44100, 0, g_hMainWnd, NULL);//初始化Bass
    GdipLoadImageFromFile(g_pszDefPic, &m_CurrSongInfo.mi.pGdipImage);
    UpdateLeftBK();

    QKOutputDebugInt(GetCurrentThreadId());
    //////////////消息循环
    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessageW(&msg);
	}
	BASS_Free();
    DeleteObject(g_hFont);
    DeleteObject(m_hFontDrawing);
    GDIObj_LeftBK(GDIOBJOPE_DELETE);

    ReleaseCurrInfo();
    for (int i = 0; i <= sizeof(GR); i += sizeof(HANDLE))
    {
        DeleteObject((HGDIOBJ)((BYTE*)&GR + i));
    }
    ClearLrcData();
    delete[] m_dwWavesData;
    GdiplusShutdown(m_uGPToken);
    return (int)msg.wParam;
}
void List_SetRedraw(BOOL b)
{
    SendMessageW(g_hLV, WM_SETREDRAW, b, 0);
}
void List_ResetLV()
{
    if (m_iSearchResult == -1)
        SendMessageW(g_hLV, LVM_SETITEMCOUNT, g_ItemData->iCount, 0);
    else
        SendMessageW(g_hLV, LVM_SETITEMCOUNT, m_iSearchResult, 0);

}
/*
 * 目标：由LV索引得到内存项目的指针，自动处理索引映射
 *
 * 参数：
 * iLVIndex LV项目索引
 *
 * 返回值：内存项目指针
 * 操作简述：
 * 备注：传入的索引必须合法
 */
PLAYERLISTUNIT* List_GetArrayItem(int iLVIndex)
{
	int i = iLVIndex;
	if (m_iSearchResult != -1)// 应执行搜索时索引映射
		i = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSearch;

	if (m_bSort)// 应执行排序索引映射
		i = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort;

	if (i == -1)
		return (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, iLVIndex);
	else
		return (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
}
/*
 * 目标：由LV索引得到内存项目的索引，自动处理索引映射
 *
 * 参数：
 * iLVIndex LV项目索引
 *
 * 返回值：内存项目索引
 * 操作简述：
 * 备注：传入的索引必须合法
 */
int List_GetArrayItemIndex(int iLVIndex)
{
    if (m_iSearchResult != -1)// 应执行搜索时索引映射
        iLVIndex = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, iLVIndex))->iMappingIndexSearch;

    if (m_bSort)// 应执行排序索引映射
        iLVIndex = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, iLVIndex))->iMappingIndexSort;

    return iLVIndex;
}
void List_Redraw()
{
    InvalidateRect(g_hLV, NULL, FALSE);
    UpdateWindow(g_hLV);
}
/*
 * 目标：将歌曲加入到列表
 *
 * 参数：
 * pszFile 文件名
 * pszName 名称，空则使用文件名
 * iPos 插入位置
 *
 * 返回值：内存项目索引
 * 操作简述：
 * 备注：
 */
int List_Add(
    PWSTR pszFile,
    PWSTR pszName,
    int iPos,
    BOOL bRedraw,
    DWORD dwFlags = 0,
    COLORREF crBookMark = 0,
    PWSTR pszBookMark = NULL,
    PWSTR pszBookMarkComment = NULL,
    PWSTR pszTime = NULL
)
{
    PLAYERLISTUNIT* pListUnit = new PLAYERLISTUNIT;
    ZeroMemory(pListUnit, sizeof(PLAYERLISTUNIT));// ZEROINIT
    pListUnit->dwFlags = dwFlags;
    pListUnit->iMappingIndexSearch = -1;
    pListUnit->iMappingIndexSort = -1;
    pListUnit->pszFile = new WCHAR[lstrlenW(pszFile) + 1];
    lstrcpyW(pListUnit->pszFile, pszFile);

    if (pszName)
    {
        pListUnit->pszName = new WCHAR[lstrlenW(pszName) + 1];
        lstrcpyW(pListUnit->pszName, pszName);
    }
    else
    {
        PWSTR pszNameTemp = new WCHAR[lstrlenW(pszFile) + 1];
        lstrcpyW(pszNameTemp, pszFile);
        PathStripPathW(pszNameTemp);//去掉路径
        PathRemoveExtensionW(pszNameTemp);//去掉扩展名

        pListUnit->pszName = new WCHAR[lstrlenW(pszNameTemp) + 1];
        lstrcpyW(pListUnit->pszName, pszNameTemp);

        delete[] pszNameTemp;
    }

    if (dwFlags & QKLIF_BOOKMARK)// 有书签
    {
        pListUnit->crBookMark = crBookMark;
        if (pszBookMark)
        {
            pListUnit->pszBookMark = new WCHAR[lstrlenW(pszBookMark) + 1];
            lstrcpyW(pListUnit->pszBookMark, pszBookMark);
        }
        if (pszBookMarkComment)
        {
            pListUnit->pszBookMarkComment = new WCHAR[lstrlenW(pszBookMarkComment) + 1];
            lstrcpyW(pListUnit->pszBookMarkComment, pszBookMarkComment);
        }
    }

    if (pszTime)
    {
        pListUnit->pszTime = new WCHAR[lstrlenW(pszTime) + 1];
        lstrcpyW(pListUnit->pszTime, pszTime);
    }


    int iIndex;
    if (iPos == -1)
        iIndex = QKArray_Add(&g_ItemData, pListUnit);
    else
        iIndex = QKArray_Insert(&g_ItemData, pListUnit, iPos);

    if (bRedraw)
        List_ResetLV();

    return iIndex;
}
/*
 * 目标：从列表中删除歌曲
 *
 * 参数：
 * iItem 欲删除的项目，内存项目索引；设置为-1以删除所有项目
 * bRedraw 是否重画
 *
 * 返回值：
 * 操作简述：
 * 备注：必须保证位置合法
 */  
void List_Delete(int iItem, BOOL bRedraw)
{
	DWORD dwExitCode;
	if (GetExitCodeThread(m_hThread[1], &dwExitCode))
		StopThread_MusicTime();
	else
		dwExitCode = 0;

    PLAYERLISTUNIT* p;
    if (iItem == -1)
    {
        for (int i = 0; i < g_ItemData->iCount; ++i)
        {
            p = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
            // 对空指针delete是安全的
            delete[] p->pszFile;
            delete[] p->pszName;
            //delete[] p->pszTime;
            delete[] p->pszBookMark;
            delete[] p->pszBookMarkComment;
        }
        QKArray_Delete(g_ItemData, QKADF_DELETE);
        g_ItemData = QKArray_Create(0);
    }
    else
    {
        p = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, iItem);
        delete[] p->pszFile;
        delete[] p->pszName;
        //delete[] p->pszTime;
        delete[] p->pszBookMark;
        delete[] p->pszBookMarkComment;
        QKArray_DeleteMember(&g_ItemData, iItem, QKADF_DELETE);
    }
    if (bRedraw)
        List_ResetLV();
    if (dwExitCode == STILL_ACTIVE)
        List_FillMusicTimeColumn(TRUE);
}
void ShowError(LPCWSTR pszTitle, LPCWSTR pszContent, BOOL IsShowErrCode)
{
    WCHAR szContent[100];
    lstrcpyW(szContent, pszContent);
    if (IsShowErrCode)
    {
        WCHAR szErrCode[3];
        int iErrCode = BASS_ErrorGetCode();
        wsprintfW(szErrCode, L"%d", iErrCode);
        lstrcatW(szContent, L"\n错误代码:");
        lstrcatW(szContent, szErrCode);
    }
    QKMessageBox(pszTitle, szContent, (HICON)TD_ERROR_ICON, (LPWSTR)L"错误");
}
/*
 * 目标：读ID3v2辅助函数：按指定编码处理文本
 *
 * 参数：
 * pStream 字节流指针；未指定iTextEncoding时指向整个文本帧，指定iTextEncoding时指向字符串
 * iLength 长度；未指定iTextEncoding时表示整个文本帧长度（包括1B的编码标记，不含结尾NULL），指定iTextEncoding时表示字符串长度（不含结尾NULL）
 * iTextEncoding 自定义文本编码；-1（缺省）指示处理的是文本帧
 *
 * 返回值：返回UTF-16LE文本指针，使用完毕后必须使用delete[]删除
 * 操作简述：
 * 备注：
 */
PWSTR GetMP3ID3v2_ProcString(BYTE* pStream, int iLength, int iTextEncoding = -1)
{
    int iType = 0, iBufferSize;
    PWSTR pBuffer = NULL;
    if (iTextEncoding == -1)
    {
        memcpy(&iType, pStream, 1);
        ++pStream;// 跳过文本编码标志
        --iLength;
    }
    else
        iType = iTextEncoding;

    switch (iType)
    {
    case 0://ISO-8859-1，即Latin-1（拉丁语-1）
        iBufferSize = MultiByteToWideChar(CP_ACP, 0, (PCCH)pStream, iLength, NULL, 0);
        if (iBufferSize == 0)
            return NULL;
        pBuffer = new WCHAR[iBufferSize + 1];//包含结尾NULL
        ZeroMemory(pBuffer, (iBufferSize + 1) * sizeof(WCHAR));
        MultiByteToWideChar(CP_ACP, 0, (PCCH)pStream, iLength, pBuffer, iBufferSize);//iLength不包含结尾NULL，因此转换后的字符串也不会包含
        break;
    case 1://UTF-16LE
        iBufferSize = iLength / sizeof(WCHAR) + 1;
        pBuffer = new WCHAR[iBufferSize];
        lstrcpynW(pBuffer, (PWSTR)pStream, iBufferSize);//包括结尾NULL
        break;
    case 2://UTF-16BE
        iBufferSize = iLength / sizeof(WCHAR);
        pBuffer = new WCHAR[iBufferSize + 1];
        LCMapStringEx(LOCALE_NAME_USER_DEFAULT, LCMAP_BYTEREV, (PCWSTR)pStream, iBufferSize, pBuffer, iBufferSize, NULL, NULL, 0);// 反转字节序
        ZeroMemory(pBuffer + iBufferSize, sizeof(WCHAR));// 添加结尾NULL
        break;
    case 3://UTF-8
        iBufferSize = MultiByteToWideChar(CP_UTF8, 0, (PCCH)pStream, iLength, NULL, 0);
        if (iBufferSize == 0)
            return NULL;
        pBuffer = new WCHAR[iBufferSize + 1];
        ZeroMemory(pBuffer, (iBufferSize + 1) * sizeof(WCHAR));
        MultiByteToWideChar(CP_UTF8, 0, (PCCH)pStream, iLength, pBuffer, iBufferSize);//iLength不包含结尾NULL，因此转换后的字符串也不会包含
        break;
    }

    return pBuffer;
}
void GetMusicFileInfo(PCWSTR pszFile, MUSICINFO* pmi)
{
    ZeroMemory(pmi, sizeof(MUSICINFO));
    HANDLE hFile = CreateFileW(
        pszFile,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );
    if (hFile == INVALID_HANDLE_VALUE)
        return;
    DWORD dwLengthRead;
    BYTE by[4];
    ReadFile(hFile, by, 4, &dwLengthRead, NULL);// 读文件头
	if (memcmp(by, "ID3", 3) == 0)
    {
        ID3v2_Header Header = { 0 };
        SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        ReadFile(hFile, &Header, sizeof(Header), &dwLengthRead, NULL);//读出标签头
        if (dwLengthRead < sizeof(ID3v2_Header))
            return;
        if (Header.Ver == 3)// ID3v2.3标签(https://id3.org)
        {
            DWORD dwTotalSize =
                ((Header.Size[0] & 0x7F) << 21) |
                ((Header.Size[1] & 0x7F) << 14) |
                ((Header.Size[2] & 0x7F) << 7) |
                (Header.Size[3] & 0x7F);// 28位数据，包括标签头
            HANDLE hMapping = CreateFileMappingW(hFile, NULL, PAGE_READONLY, 0, dwTotalSize, NULL);//映射ID3v2到内存
            BYTE* pFile = (BYTE*)MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, dwTotalSize);
            //参考资料：https://blog.csdn.net/u010650845/article/details/53520426
            if (pFile)
            {
                BYTE* pFrame;
                DWORD dwOffest = sizeof(ID3v2_Header);
                DWORD dwUnitSize;
                CHAR FrameID[4];
                while (true)
                {
                    pFrame = pFile + dwOffest;
                    dwUnitSize =
                        (((ID3v2_UnitHeader*)pFrame)->Size[0] << 24) |
                        (((ID3v2_UnitHeader*)pFrame)->Size[1] << 16) |
                        (((ID3v2_UnitHeader*)pFrame)->Size[2] << 8) |
                        ((ID3v2_UnitHeader*)pFrame)->Size[3];// 32位数据，不包括帧头
                    memcpy(FrameID, ((ID3v2_UnitHeader*)pFrame)->ID, 4);// 读帧标识
                    pFrame += sizeof(ID3v2_UnitHeader);// 跳过帧头
                    if (memcmp(FrameID, "TIT2", 4) == 0)// 标题
                        pmi->pszTitle = GetMP3ID3v2_ProcString(pFrame, dwUnitSize);
                    else if (memcmp(FrameID, "TPE1", 4) == 0)// 作者
                        pmi->pszArtist = GetMP3ID3v2_ProcString(pFrame, dwUnitSize);
                    else if (memcmp(FrameID, "TALB", 4) == 0)// 专辑
                        pmi->pszAlbum = GetMP3ID3v2_ProcString(pFrame, dwUnitSize);
                    else if (memcmp(FrameID, "USLT", 4) == 0)// 不同步歌词
                    {
                        /*
                        <帧头>（帧标识为USLT）
                        文本编码						$xx
                        自然语言代码					$xx xx xx
                        内容描述						<字符串> $00 (00)
                        歌词							<字符串>
                        */
                        DWORD cb = dwUnitSize;
                        BYTE byEncodeingType = *pFrame;// 读文本编码
                        ++pFrame;// 跳过文本编码
                        CHAR byLangCode[3];
                        memcpy(byLangCode, pFrame, 3);// 读自然语言代码
                        pFrame += 3;// 跳过自然语言代码
                        int t;
                        if (byEncodeingType == 0 || byEncodeingType == 3)// ISO-8859-1或UTF-8
                            t = lstrlenA((PCSTR)pFrame) + 1;
                        else// UTF-16LE或UTF-16BE
                            t = (lstrlenW((PCWSTR)pFrame) + 1) * sizeof(WCHAR);
                        pFrame += t;// 跳过内容描述
                        cb -= (t + 4);
                        // 此时pFrame指向歌词文本
                        pmi->pszLrc = GetMP3ID3v2_ProcString(pFrame, cb, byEncodeingType);
                    }
                    else if (memcmp(FrameID, "COMM", 4) == 0)// 备注
                    {
                        /*
                        <帧头>（帧标识为COMM）
                        文本编码						$xx
                        自然语言代码					$xx xx xx
                        备注摘要						<字符串> $00 (00)
                        备注							<字符串>
                        */
                        DWORD cbComment = dwUnitSize;
                        BYTE byEncodeingType = *pFrame;// 读文本编码
                        ++pFrame;// 跳过文本编码
                        CHAR byLangCode[3];
                        memcpy(byLangCode, pFrame, 3);// 读自然语言代码
                        pFrame += 3;// 跳过自然语言代码
                        int t;
                        if (byEncodeingType == 0 || byEncodeingType == 3)// ISO-8859-1或UTF-8
                            t = lstrlenA((PCSTR)pFrame) + 1;
                        else// UTF-16LE或UTF-16BE
                            t = (lstrlenW((PCWSTR)pFrame) + 1) * sizeof(WCHAR);
                        pFrame += t;// 跳过备注摘要
                        cbComment -= (t + 4);
                        // 此时pFrame指向备注字符串
                        pmi->pszComment = GetMP3ID3v2_ProcString(pFrame, cbComment, byEncodeingType);
                    }
                    else if (memcmp(FrameID, "APIC", 4) == 0)// 图片
                    {
                        /*
                        <帧头>（帧标识为APIC）
                        文本编码                        $xx
                        MIME 类型                       <ASCII字符串>$00（如'image/bmp'）
                        图片类型                        $xx
                        描述                            <字符串>$00(00)
                        <图片数据>
                        */
                        BYTE* pImageData = pFrame;
                        BYTE byEncodeingType = *pImageData;// 读文本编码
                        int t, cbImageSize = dwUnitSize;
                        ++pImageData;// 跳过文本编码
                        t = lstrlenA((PCSTR)pImageData);
                        pImageData += t;// 跳过MIME类型字符串
                        pImageData += 2;// 跳过MIME结尾NULL和图片类型
                        cbImageSize -= (t + 3);
                        if (byEncodeingType == 0 || byEncodeingType == 3)// ISO-8859-1或UTF-8
                            t = lstrlenA((PCSTR)pImageData) + 1;
                        else// UTF-16LE或UTF-16BE
                            t = lstrlenW((PCWSTR)pImageData) * sizeof(WCHAR) + 2;
                        pImageData += t; cbImageSize -= t;// 跳过描述字符串和结尾NULL

                        IStream* pPicStream = SHCreateMemStream(pImageData, cbImageSize);// 创建流对象
                        if (pPicStream)
                        {
                            if (GdipCreateBitmapFromStream(pPicStream, &pmi->pGdipImage) != Ok)// 创建自字节流
                                pmi->pGdipImage = NULL;
                            pPicStream->Release();
                        }
                    }
                    dwOffest += (dwUnitSize + sizeof(ID3v2_UnitHeader));
                    if (dwOffest >= dwTotalSize)// 是否超界
                        break;
                }
                UnmapViewOfFile(pFile);
            }
            CloseHandle(hMapping);
        }
    }
    else if (memcmp(by, "fLaC", 4) == 0)
	{
        FLAC_Header Header;
        DWORD dwSize;
        UINT t;
        void* pBuffer;
        do
        {
            ReadFile(hFile, &Header, sizeof(FLAC_Header), &dwLengthRead, NULL);
            dwSize = Header.bySize[2] | Header.bySize[1] << 8 | Header.bySize[0] << 16;
            switch (Header.by & 0x7F)
            {
            case 4:// 标签信息，注意：这一部分是小端序
            {
                ReadFile(hFile, &t, 4, &dwLengthRead, NULL);// 编码器信息大小
                SetFilePointer(hFile, t, NULL, FILE_CURRENT);// 跳过编码器信息
                UINT uCount;
                ReadFile(hFile, &uCount, 4, &dwLengthRead, NULL);// 标签数

                for (int i = 0; i < uCount; ++i)
                {
                    ReadFile(hFile, &t, 4, &dwLengthRead, NULL);// 标签大小
                    pBuffer = HeapAlloc(GetProcessHeap(), 0, t + 1);
                    ReadFile(hFile, pBuffer, t, &dwLengthRead, NULL);// 读标签
                    *(CHAR*)((BYTE*)pBuffer + t) = '\0';

                    t = MultiByteToWideChar(CP_UTF8, 0, (CHAR*)pBuffer, -1, NULL, 0);
                    PWSTR pBuf = (PWSTR)HeapAlloc(GetProcessHeap(), 0, t * sizeof(WCHAR));
                    MultiByteToWideChar(CP_UTF8, 0, (CHAR*)pBuffer, -1, pBuf, t);// 转换编码
                    HeapFree(GetProcessHeap(), 0, pBuffer);

                    UINT uPos = QKStrInStr(pBuf, L"=");

                    if (QKStrInStr(pBuf, L"TITLE"))
                    {
                        pmi->pszTitle = new WCHAR[t - uPos];
                        lstrcpyW(pmi->pszTitle, pBuf + uPos);
                    }
                    else if (QKStrInStr(pBuf, L"ALBUM"))
                    {
                        pmi->pszAlbum = new WCHAR[t - uPos];
                        lstrcpyW(pmi->pszAlbum, pBuf + uPos);
                    }
                    else if (QKStrInStr(pBuf, L"ARTIST"))
                    {
                        pmi->pszArtist = new WCHAR[t - uPos];
                        lstrcpyW(pmi->pszArtist, pBuf + uPos);
                    }
                    else if (QKStrInStr(pBuf, L"DESCRIPTION"))
                    {
                        pmi->pszComment = new WCHAR[t - uPos];
                        lstrcpyW(pmi->pszComment, pBuf + uPos);
                    }
					else if (QKStrInStr(pBuf, L"LYRICS"))
                    {
                        pmi->pszLrc = new WCHAR[t - uPos];
                        lstrcpyW(pmi->pszLrc, pBuf + uPos);
                    }

                    HeapFree(GetProcessHeap(), 0, pBuf);
                }
            }
            break;
            case 6:// 图片
            {
                SetFilePointer(hFile, 4, NULL, FILE_CURRENT);// 跳过图片类型

                ReadFile(hFile, &t, 4, &dwLengthRead, NULL);
                t = QKByteStreamToBEUINT32((BYTE*)&t);
                SetFilePointer(hFile, t, NULL, FILE_CURRENT);// 跳过MIME类型字符串

                ReadFile(hFile, &t, 4, &dwLengthRead, NULL);
                t = QKByteStreamToBEUINT32((BYTE*)&t);
                SetFilePointer(hFile, t, NULL, FILE_CURRENT);// 跳过描述字符串

                SetFilePointer(hFile, 16, NULL, FILE_CURRENT);// 跳过宽度、高度、色深、索引图颜色数

                ReadFile(hFile, &t, 4, &dwLengthRead, NULL);
                t = QKByteStreamToBEUINT32((BYTE*)&t);// 图片数据长度

                pBuffer = HeapAlloc(GetProcessHeap(), 0, t);
                ReadFile(hFile, pBuffer, t, &dwLengthRead, NULL);// 读图片
                IStream* pPicStream = SHCreateMemStream((BYTE*)pBuffer, t);// 创建流对象
                if (pPicStream)
                {
                    if (GdipCreateBitmapFromStream(pPicStream, &pmi->pGdipImage) != Ok)// 创建自字节流
                        pmi->pGdipImage = NULL;
                    pPicStream->Release();
                }
                HeapFree(GetProcessHeap(), 0, pBuffer);
            }
            break;
            default:
                SetFilePointer(hFile, dwSize, NULL, FILE_CURRENT);// 跳过块
            }

		} while (!(Header.by & 0x80));
	}
    CloseHandle(hFile);
}
void MusicInfo_Release(MUSICINFO* mi)
{
	delete[] mi->pszTitle;
	delete[] mi->pszArtist;
	delete[] mi->pszAlbum;
	delete[] mi->pszComment;
    delete[] mi->pszLrc;
	if (mi->pGdipImage)
		GdipDisposeImage(mi->pGdipImage);
	ZeroMemory(mi, sizeof(MUSICINFO));
}
void ReleaseCurrInfo()
{
	delete[] m_CurrSongInfo.pszFile;
	MusicInfo_Release(&m_CurrSongInfo.mi);
    ZeroMemory(&m_CurrSongInfo, sizeof(SONG_INFO));
}
void CALLBACK SyncProc_End(HSYNC handle, DWORD channel, DWORD data, void* user)
{
    SendMessageW(g_hTBProgess, QKCTBM_SETPOS, TRUE, (LPARAM)SendMessageW(g_hTBProgess, QKCTBM_GETRANGE, 0, 0));
    AutoNext();
}
/*
 * 目标：画一行歌词
 *
 * 参数：
 * iIndex 歌词索引
 * y 起始y坐标（顶边或底边），设为-1以使用上次绘画时的顶边，此时bTop参数无效
 * bTop 是否为顶边
 * bClearBK 是否擦除背景
 * bImmdShow 立即显示，若为FALSE，则需另外将后台位图拷贝到前台，设为TRUE，则自动剪辑歌词区域
 *
 * 返回值：返回已绘制的歌词高度
 * 操作简述：
 * 备注：必须保证索引合法；自动处理强制双行设置；自动处理热点和选中项目；擦除背景时仅擦除歌词矩形
 */
int Lrc_DrawItem(int iIndex, int y, BOOL bTop, BOOL bClearBK, BOOL bImmdShow)
{
    BOOL bCurr = (iIndex == g_iCurrLrcIndex);
	if (bCurr)
		SetTextColor(m_hcdcLeftBK2, QKCOLOR_RED);
	else
		SetTextColor(m_hcdcLeftBK2, QKCOLOR_CYANDEEPER);

    LRCDATA* p = (LRCDATA*)QKArray_Get(g_Lrc, iIndex);
    if (y == -1)
    {
        if (p->iDrawID != m_iDrawingID)
            return -1;
        y = p->iLastTop;
        bTop = TRUE;
    }

	RECT rc;
	RECT rc2;
	UINT uFlags;
	int iHeight, iHeight2;
    int cx1, cx2;
	if (GS.bForceTwoLines)
	{
		uFlags = DT_NOPREFIX | DT_CALCRECT;
        rc = m_rcLrcShow;
        if (p->iOrgLength == -1)
        {
            iHeight = DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc, uFlags);
            cx1 = rc.right - rc.left;
            if (bCurr)
            {
                if (iIndex != m_LrcHScrollInfo.iIndex)
                {
                    m_LrcHScrollInfo.iIndex = iIndex;
                    if (!m_LrcHScrollInfo.bWndSizeChangedFlag)
                        m_LrcHScrollInfo.x1 = m_LrcHScrollInfo.x2 = 0;
                    else
                        m_LrcHScrollInfo.bWndSizeChangedFlag = FALSE;

                    KillTimer(g_hMainWnd, IDT_ANIMATION);
                    if (cx1 > m_cxLrcShow)
                    {
                        m_LrcHScrollInfo.cx1 = cx1;// 超长了，需要后续滚动
                        m_LrcHScrollInfo.fNoScrollingTime1 = m_cxLrcShow * p->fDelay / m_LrcHScrollInfo.cx1 / 2;
                        SetTimer(g_hMainWnd, IDT_ANIMATION, TIMERELAPSE_ANIMATION, TimerProc);
                    }
                    else
                    {
                        m_LrcHScrollInfo.cx1 = -1;
                        m_LrcHScrollInfo.x1 = m_LrcHScrollInfo.x2 = 0;
                    }
                }
            }

            if (cx1 > m_cxLrcShow)
                uFlags = DT_NOPREFIX;
            else
                uFlags = DT_NOPREFIX | DT_CENTER;

            p->cy = iHeight;

            if (bTop)
            {
                rc2 = { m_rcLrcShow.left,y,m_rcLrcShow.right,y + p->cy };
                
                if (bClearBK)
                    BitBlt(m_hcdcLeftBK2, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK, rc2.left, rc2.top, SRCCOPY);

                if (bImmdShow)
                {
                    HRGN hRgn1 = CreateRectRgnIndirect(&rc2);
                    HRGN hRgn2 = CreateRectRgnIndirect(&m_rcLrcShow);
                    CombineRgn(hRgn1, hRgn1, hRgn2, RGN_AND);
                    SelectClipRgn(m_hcdcLeftBK2, hRgn1);// 设置剪辑区
                    DeleteObject(hRgn1);
                    DeleteObject(hRgn2);
                }

				rc = rc2;
				if (bCurr)
					rc.left += m_LrcHScrollInfo.x1;
				p->iLastTop = rc.top;
				DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc, uFlags);// 绘制
            }
            else
            {
                rc2 = { m_rcLrcShow.left,y - p->cy,m_rcLrcShow.right,y };
                if (bClearBK)
                    BitBlt(m_hcdcLeftBK2, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK, rc2.left, rc2.top, SRCCOPY);

                if (bImmdShow)
                {
                    HRGN hRgn1 = CreateRectRgnIndirect(&rc2);
                    HRGN hRgn2 = CreateRectRgnIndirect(&m_rcLrcShow);
                    CombineRgn(hRgn1, hRgn1, hRgn2, RGN_AND);
                    SelectClipRgn(m_hcdcLeftBK2, hRgn1);// 设置剪辑区
                    DeleteObject(hRgn1);
                    DeleteObject(hRgn2);
				}

				rc = rc2;
				if (bCurr)
					rc.left += m_LrcHScrollInfo.x1;
				p->iLastTop = rc.top;
				DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc, uFlags);// 绘制
            }
        }
        else// 有两行
        {
            iHeight = DrawTextW(m_hcdcLeftBK2, p->pszLrc, p->iOrgLength, &rc, uFlags);// 测量第一行
            iHeight2 = DrawTextW(m_hcdcLeftBK2, p->pszLrc + p->iOrgLength + 1, -1, &rc2, uFlags);// 测量第二行
            cx1 = rc.right - rc.left;
            cx2 = rc2.right - rc2.left;
            if (bCurr)
            {
                if (iIndex != m_LrcHScrollInfo.iIndex)
                {
                    m_LrcHScrollInfo.iIndex = iIndex;
                    if (!m_LrcHScrollInfo.bWndSizeChangedFlag)
                        m_LrcHScrollInfo.x1 = m_LrcHScrollInfo.x2 = 0;
                    else
                        m_LrcHScrollInfo.bWndSizeChangedFlag = FALSE;

					KillTimer(g_hMainWnd, IDT_ANIMATION);
					if (cx1 > m_cxLrcShow)
					{
						m_LrcHScrollInfo.cx1 = cx1;// 超长了，需要后续滚动
						m_LrcHScrollInfo.fNoScrollingTime1 = m_cxLrcShow * p->fDelay / m_LrcHScrollInfo.cx1 / 2;
						SetTimer(g_hMainWnd, IDT_ANIMATION, TIMERELAPSE_ANIMATION, TimerProc);
					}
					else
					{
                        m_LrcHScrollInfo.cx1 = -1;
                        m_LrcHScrollInfo.x1 = 0;
                    }

                    if (cx2 > m_cxLrcShow)
                    {
                        m_LrcHScrollInfo.cx2 = cx2;// 超长了，需要后续滚动
                        m_LrcHScrollInfo.fNoScrollingTime2 = m_cxLrcShow * p->fDelay / m_LrcHScrollInfo.cx2 / 2;
                        SetTimer(g_hMainWnd, IDT_ANIMATION, TIMERELAPSE_ANIMATION, TimerProc);
                    }
                    else
                    {
                        m_LrcHScrollInfo.cx2 = -1;
                        m_LrcHScrollInfo.x2 = 0;
                    }
                }
            }

            p->cy = iHeight + iHeight2;

            
            if (bTop)
            {
                rc2 = { m_rcLrcShow.left,y,m_rcLrcShow.right,y + p->cy };
                if (bClearBK)
                {
                    BitBlt(m_hcdcLeftBK2, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK, rc2.left, rc2.top, SRCCOPY);
                }

                if (bImmdShow)
                {
                    HRGN hRgn1 = CreateRectRgnIndirect(&rc2);
                    HRGN hRgn2 = CreateRectRgnIndirect(&m_rcLrcShow);
                    CombineRgn(hRgn1, hRgn1, hRgn2, RGN_AND);
                    SelectClipRgn(m_hcdcLeftBK2, hRgn1);// 设置剪辑区
                    DeleteObject(hRgn1);
                    DeleteObject(hRgn2);
                }

                rc.top = y;
                p->iLastTop = rc.top;
                rc.bottom = rc.top + iHeight;
                if (bCurr)
                    rc.left = m_rcLrcShow.left + m_LrcHScrollInfo.x1;
                else
                    rc.left = m_rcLrcShow.left;
                rc.right = m_rcLrcShow.right;
                if (cx1 > m_cxLrcShow)
                    uFlags = DT_NOPREFIX;
                else
                    uFlags = DT_NOPREFIX | DT_CENTER;
                DrawTextW(m_hcdcLeftBK2, p->pszLrc, p->iOrgLength, &rc, uFlags);// 绘制第一行

                rc.top = rc.bottom;
                rc.bottom += iHeight2;
                if (bCurr)
                    rc.left = m_rcLrcShow.left + m_LrcHScrollInfo.x2;

                rc.right = m_rcLrcShow.right;
                if (cx2 > m_cxLrcShow)
                    uFlags = DT_NOPREFIX;
                else
                    uFlags = DT_NOPREFIX | DT_CENTER;
                DrawTextW(m_hcdcLeftBK2, p->pszLrc + p->iOrgLength + 1, -1, &rc, uFlags);// 绘制第二行
            }
            else
            {
                rc2 = { m_rcLrcShow.left,y - p->cy,m_rcLrcShow.right,y };
                if (bClearBK)
                    BitBlt(m_hcdcLeftBK2, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK, rc2.left, rc2.top, SRCCOPY);

                if (bImmdShow)
                {
                    HRGN hRgn1 = CreateRectRgnIndirect(&rc2);
                    HRGN hRgn2 = CreateRectRgnIndirect(&m_rcLrcShow);
                    CombineRgn(hRgn1, hRgn1, hRgn2, RGN_AND);
                    SelectClipRgn(m_hcdcLeftBK2, hRgn1);// 设置剪辑区
                    DeleteObject(hRgn1);
                    DeleteObject(hRgn2);
                }

                rc.bottom = y;
                rc.top = rc.bottom - iHeight2;
                if (bCurr)
                    rc.left = m_rcLrcShow.left + m_LrcHScrollInfo.x2;
                else
                    rc.left = m_rcLrcShow.left;
                rc.right = m_rcLrcShow.right;
                if (cx2 > m_cxLrcShow)
                    uFlags = DT_NOPREFIX;
                else
                    uFlags = DT_NOPREFIX | DT_CENTER;
                DrawTextW(m_hcdcLeftBK2, p->pszLrc + p->iOrgLength + 1, -1, &rc, uFlags);// 绘制第二行

				rc.bottom = rc.top;
				rc.top -= iHeight;
				p->iLastTop = rc.top;
				if (bCurr)
					rc.left = m_rcLrcShow.left + m_LrcHScrollInfo.x1;
				rc.right = m_rcLrcShow.right;
				if (cx1 > m_cxLrcShow)
					uFlags = DT_NOPREFIX;
				else
                    uFlags = DT_NOPREFIX | DT_CENTER;
                DrawTextW(m_hcdcLeftBK2, p->pszLrc, p->iOrgLength, &rc, uFlags);// 绘制第一行
            }
        }
        if (m_iLrcMouseHover == iIndex)
            FrameRect(m_hcdcLeftBK2, &rc2, GC.hbrCyanDeeper);
	}
	else
	{
        rc2 = m_rcLrcShow;
        uFlags = DT_NOPREFIX | DT_WORDBREAK | DT_CENTER | DT_CALCRECT;
        iHeight = DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc2, uFlags);
        p->cy = iHeight;

        uFlags = DT_NOPREFIX | DT_WORDBREAK | DT_CENTER;

        if (bTop)
        {
            rc2.top = y;
            rc2.bottom = rc2.top + iHeight;
        }
        else
        {
            rc2.bottom = y;
            rc2.top = rc2.bottom - iHeight;
		}
		p->iLastTop = rc2.top;
		rc2.left = m_rcLrcShow.left;
		rc2.right = m_rcLrcShow.right;
        if (bClearBK)
            BitBlt(m_hcdcLeftBK2, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK, rc2.left, rc2.top, SRCCOPY);

		if (bImmdShow)
		{
			HRGN hRgn1 = CreateRectRgnIndirect(&rc2);
			HRGN hRgn2 = CreateRectRgnIndirect(&m_rcLrcShow);
			CombineRgn(hRgn1, hRgn1, hRgn2, RGN_AND);
			SelectClipRgn(m_hcdcLeftBK2, hRgn1);// 设置剪辑区
			DeleteObject(hRgn1);
			DeleteObject(hRgn2);
		}

		DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc2, uFlags);
		if (m_iLrcMouseHover == iIndex)
			FrameRect(m_hcdcLeftBK2, &rc2, GC.hbrCyanDeeper);
	}

	if (bImmdShow)
	{
		SelectClipRgn(m_hcdcLeftBK2, NULL);
		HDC hDC = GetDC(g_hBKLeft);
		BitBlt(hDC, rc2.left, rc2.top, rc2.right - rc2.left, rc2.bottom - rc2.top, m_hcdcLeftBK2, rc2.left, rc2.top, SRCCOPY);
		ReleaseDC(g_hBKLeft, hDC);
	}

    p->iDrawID = m_iDrawingID;// 已经绘制标记
	return p->cy;
}
ULONG_PTR BASS_OpenMusic(PWSTR pszFile, DWORD dwFlagsHS = 0, DWORD dwFlagsHM = 0)
{
    ULONG_PTR h;
	h = BASS_StreamCreateFile(FALSE, pszFile, 0, 0, BASS_UNICODE | dwFlagsHS);
    g_bHMUSIC = FALSE;
    if (!h && BASS_ErrorGetCode() == BASS_ERROR_FILEFORM)
    {
        h = BASS_MusicLoad(FALSE, pszFile, 0, 0, BASS_UNICODE | dwFlagsHM, 0);
        g_bHMUSIC = TRUE;
    }

    return h;
}
BOOL BASS_FreeMusic(ULONG_PTR h)
{
    if (g_bHMUSIC)
        return BASS_MusicFree(h);
    else
        return BASS_StreamFree(h);
}
/*
 * 目标：按索引播放列表中的文件
 *
 * 参数：
 * iIndex LV索引
 *
 * 返回值：
 * 操作简述：
 * 备注：
 */
void PlayFile(int iIndex)// 播放前将停止先前的播放
{
    //////////////清理遗留   
    m_dwThreadFlags[0] = m_dwThreadFlags[1] = THREADFLAG_WORKING;
    m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = TRUE;

    Stop(TRUE);

    ClearLrcData();
    g_Lrc = QKArray_Create(0);

    delete[] m_dwWavesData;
    m_dwWavesData = NULL;
    //////////////取现行信息
    PLAYERLISTUNIT* p = List_GetArrayItem(iIndex);
    PWSTR pszName = new WCHAR[lstrlenW(p->pszName) + 1];
    lstrcpyW(pszName, p->pszName);
    SetWindowTextW(g_hMainWnd, pszName);
    m_CurrSongInfo.pszFile = pszName;

    g_iCurrFileIndex = iIndex;
    lstrcpyW(m_szCurrFile, p->pszFile);
    g_iLrcState = LRCSTATE_NOLRC;
    //////////////取MP3信息

    GetMusicFileInfo(m_szCurrFile, &m_CurrSongInfo.mi);

    if (!m_CurrSongInfo.mi.pGdipImage)
    {
        GdipLoadImageFromFile(g_pszDefPic, &m_CurrSongInfo.mi.pGdipImage);
    }
    else
    {
        UINT cx0, cy0, cx, cy;
        GdipGetImageWidth(m_CurrSongInfo.mi.pGdipImage, &cx0);
        GdipGetImageHeight(m_CurrSongInfo.mi.pGdipImage, &cy0);
        if (max(cx0, cy0) > DPIS_LARGEIMAGE)// 限制图片大小
        {
            GpBitmap* pGdipImage;
            GpGraphics* pGdipGraphics;
            if (cx0 >= cy0)// 宽度较大
            {
                cy = (UINT)((float)cy0 / (float)cx0 * DPIS_LARGEIMAGE);
                cx = DPIS_LARGEIMAGE;
            }
            else
            {
                cx = (UINT)((float)cx0 / (float)cy0 * DPIS_LARGEIMAGE);
                cy = DPIS_LARGEIMAGE;
            }
            GdipCreateBitmapFromScan0(cx, cy, 0, PixelFormat32bppRGB, NULL, &pGdipImage);
            GdipGetImageGraphicsContext(pGdipImage, &pGdipGraphics);
            GdipDrawImageRectRect(pGdipGraphics, m_CurrSongInfo.mi.pGdipImage,
                0, 0, (float)cx, (float)cy,
                0, 0, (float)cx0, (float)cy0,
                UnitPixel, NULL, NULL, NULL);
            GdipDeleteGraphics(pGdipGraphics);
            GdipDisposeImage(m_CurrSongInfo.mi.pGdipImage);
            m_CurrSongInfo.mi.pGdipImage = pGdipImage;
        }
    }
    UpdateLeftBK();
    //////////////开始播放
	g_hStream = BASS_OpenMusic(m_szCurrFile, BASS_SAMPLE_FX | BASS_SAMPLE_LOOP, BASS_SAMPLE_FX | BASS_MUSIC_PRESCAN | BASS_SAMPLE_LOOP);
    BASS_ChannelSetSync(g_hStream, BASS_SYNC_END | BASS_SYNC_ONETIME, 0, SyncProc_End, NULL);// 设置同步过程用来跟踪歌曲播放完毕的事件
    if (!g_hStream)
    {
        g_iCurrFileIndex = -1;
        ShowError(L"播放错误", L"打开文件失败！");
        return;
    }
    BASS_ChannelPlay(g_hStream, FALSE);
    //////////////保存信息
    BASS_ChannelGetAttribute(g_hStream, BASS_ATTRIB_FREQ, &m_fDefSpeed);// 保存默认速度    
    m_llLength = (ULONGLONG)(BASS_ChannelBytes2Seconds(
        g_hStream,
        BASS_ChannelGetLength(g_hStream, BASS_POS_BYTE)
    ) * 1000);
    SendMessageW(g_hTBProgess, QKCTBM_SETRANGE, FALSE, (LPARAM)m_llLength / 10);// 设定最大位置

    if (m_fSpeedChanged != SBV_INVALIDVALUE)
        BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_FREQ, m_fSpeedChanged * m_fDefSpeed);
    if (m_fBlanceChanged != SBV_INVALIDVALUE)
        BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_PAN, m_fBlanceChanged);

    if (m_bSlient)
        BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_VOL, 0);
    else if (m_fVolChanged != SBV_INVALIDVALUE)
        BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_VOL, m_fVolChanged);

    if (m_GlobalEffect.hFXChorus)
    {
        m_GlobalEffect.hFXChorus = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_CHORUS, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXChorus, &m_GlobalEffect.Chorus);
    }
    if (m_GlobalEffect.hFXCompressor)
    {
        m_GlobalEffect.hFXCompressor = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_COMPRESSOR, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXCompressor, &m_GlobalEffect.Compressor);
    }
    if (m_GlobalEffect.hFXDistortion)
    {
        m_GlobalEffect.hFXDistortion = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_DISTORTION, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXDistortion, &m_GlobalEffect.Distortion);
    }
    if (m_GlobalEffect.hFXEcho)
    {
        m_GlobalEffect.hFXEcho = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_ECHO, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXEcho, &m_GlobalEffect.Echo);
    }
    if (m_GlobalEffect.hFXFlanger)
    {
        m_GlobalEffect.hFXFlanger = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_FLANGER, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXFlanger, &m_GlobalEffect.Flanger);
    }
    if (m_GlobalEffect.hFXGargle)
    {
        m_GlobalEffect.hFXGargle = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_GARGLE, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXGargle, &m_GlobalEffect.Gargle);
    }
    if (m_GlobalEffect.hFXI3DL2Reverb)
    {
        m_GlobalEffect.hFXI3DL2Reverb = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_I3DL2REVERB, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXI3DL2Reverb, &m_GlobalEffect.I3DL2Reverb);
    }
    if (m_GlobalEffect.hFXReverb)
    {
        m_GlobalEffect.hFXReverb = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_REVERB, 1);
        BASS_FXSetParameters(m_GlobalEffect.hFXReverb, &m_GlobalEffect.Reverb);
    }
    if (m_GlobalEffect.hFXEQ[0])
    {
        for (int i = 0; i < 10; ++i)
        {
            m_GlobalEffect.hFXEQ[i] = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_PARAMEQ, 1);
            BASS_FXSetParameters(m_GlobalEffect.hFXEQ[i], &m_GlobalEffect.EQ[i]);
        }
    }
    // 注意：进度条单位为百毫秒
    LrcWnd_DrawLrc();
    if (g_pITaskbarList)
        g_pITaskbarList->SetProgressState(m_hTBGhost, TBPF_NORMAL);

    SendMessageW(g_hBKBtm, BTMBKM_SETPLAYBTICON, FALSE, 0);

    m_hThread[0] = CreateThread(NULL, 0, Thread_GetWavesData, NULL, 0, NULL);
	Lrc_ParseLrcData(NULL, 0, TRUE, NULL, &g_Lrc, GS.uDefTextCode);
	if (!g_Lrc->iCount && m_CurrSongInfo.mi.pszLrc)
	{
		Lrc_ParseLrcData(
			m_CurrSongInfo.mi.pszLrc,
			(lstrlenW(m_CurrSongInfo.mi.pszLrc) + 1) * sizeof(WCHAR),
			FALSE, NULL, &g_Lrc, GS.uDefTextCode);
	}

    m_iLrcSBPos = -1;
    m_iLrcFixedIndex = -1;
	m_iLrcMouseHover = -1;
	m_iLrcCenter = -1;
	SendMessageW(g_hBKLeft, LEFTBKM_SETMAX, g_Lrc->iCount - 1, 0);
	List_Redraw();
	m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = TRUE;
	DwmInvalidateIconicBitmaps(m_hTBGhost);
}
//停止线程，重置变量，该函数会阻塞直至线程退出
//不能用TerminateThread，TerminateThread不能确定线程在何处终止，可能导致内存泄漏
void StopThread_Waves()
{
    DWORD dwExitCode;
    BOOL bResult = GetExitCodeThread(m_hThread[0], &dwExitCode);
    if (bResult && dwExitCode == STILL_ACTIVE)
    {
        m_dwThreadFlags[0] = THREADFLAG_STOP;
        WaitForSingleObject(m_hThread[0], INFINITE);//等待线程退出
        m_dwThreadFlags[0] = THREADFLAG_STOPED;
    }
    CloseHandle(m_hThread[0]);
    m_hThread[0] = NULL;//清空句柄
}
//停止线程，重置变量，该函数会阻塞直至线程退出
//不能用TerminateThread，TerminateThread不能确定线程在何处终止，可能导致内存泄漏
void StopThread_MusicTime()
{
    if (!m_hThread[1])
        return;

    DWORD dwExitCode;
    BOOL bResult = GetExitCodeThread(m_hThread[1], &dwExitCode);
    if (bResult && dwExitCode == STILL_ACTIVE)
    {
        m_dwThreadFlags[1] = THREADFLAG_STOP;
        WaitForSingleObject(m_hThread[1], INFINITE);//等待线程退出
        m_dwThreadFlags[1] = THREADFLAG_STOPED;
    }

    CloseHandle(m_hThread[1]);
    g_iLrcState = LRCSTATE_NOLRC;
    m_hThread[1] = NULL;//清空句柄
}
/*
 * 目标：填充列表时间列
 *
 * 参数：
 * p 工作参数
 *
 * 返回值：
 * 操作简述：
 * 备注：线程
 */
DWORD WINAPI Thread_FillTimeColumn(void* p)
{
    PLAYERLISTUNIT* pI;
    TPARAM_FILLTIMECLM* pp = (TPARAM_FILLTIMECLM*)p;
    for (int i = 0; i < g_ItemData->iCount; ++i)
    {
        if (m_dwThreadFlags[1] == THREADFLAG_STOP)
            break;

        pI = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
		if (!pI->pszTime || !pp->bJudgeItem)
        {
			HSTREAM hStream = BASS_OpenMusic(pI->pszFile, BASS_STREAM_DECODE, BASS_MUSIC_DECODE | BASS_MUSIC_PRESCAN);
            int iTime = (int)BASS_ChannelBytes2Seconds(hStream, BASS_ChannelGetLength(hStream, BASS_POS_BYTE));
            BASS_FreeMusic(hStream);
            int iMin = iTime / 60,
                iSec = iTime - iMin * 60;

            delete[] pI->pszTime;
            pI->pszTime = new WCHAR[_snwprintf(NULL, 0, L"%02d:%02d", iMin, iSec) + 1];
            wsprintfW(pI->pszTime, L"%02d:%02d", iMin, iSec);
        }
    }
    List_Redraw();
    delete pp;
    return 0;
}
/*
 * 目标：启动一个线程，后台填充列表的时间列
 *
 * 参数：
 * bJudgeItem 是否根据项目的标志工作，即是否强制更新
 *
 * 返回值：
 * 操作简述：
 * 备注：
 */
void List_FillMusicTimeColumn(BOOL bJudgeItem)
{
    StopThread_MusicTime();
    TPARAM_FILLTIMECLM* p = new TPARAM_FILLTIMECLM;
    p->bJudgeItem = bJudgeItem;
    m_dwThreadFlags[1] = THREADFLAG_WORKING;
    m_hThread[1] = CreateThread(NULL, 0, Thread_FillTimeColumn, p, 0, NULL);
}
void Stop(BOOL bNoGap)
{
    KillTimer(g_hMainWnd, IDT_DRAWING_LRC);
    KillTimer(g_hMainWnd, IDT_DRAWING_SPE);
    KillTimer(g_hMainWnd, IDT_DRAWING_WAVES);
    KillTimer(g_hMainWnd, IDT_ANIMATION);
    KillTimer(g_hMainWnd, IDT_ANIMATION2);

    StopThread_Waves();
    ReleaseCurrInfo();

    BASS_ChannelStop(g_hStream);
    BASS_FreeMusic(g_hStream);
    g_hStream = NULL;

    g_iCurrFileIndex = -1;
    g_iCurrLrcIndex = -2;
    g_iLrcState = LRCSTATE_STOP;
    m_LrcHScrollInfo = { -1 };
    m_LrcVScrollInfo = { 0 };

    if (g_pITaskbarList)
        g_pITaskbarList->SetProgressState(m_hTBGhost, TBPF_NOPROGRESS);

    if (!bNoGap)
    {
        m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = TRUE;
        GdipLoadImageFromFile(g_pszDefPic, &m_CurrSongInfo.mi.pGdipImage);
        LrcWnd_DrawLrc();
        SetWindowTextW(g_hMainWnd, L"未播放 - 晴空的音乐播放器");
        UpdateLeftBK();
        SendMessageW(g_hBKBtm, BTMBKM_SETPLAYBTICON, TRUE, 0);
        m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = FALSE;
    }
}
INT_PTR CALLBACK DlgProc_List(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static DWORD dwDlgType;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        // 设置提示文本
        if (lParam == DLGTYPE_SAVELIST)
        {
            SetDlgItemTextW(hDlg, IDC_ST_TIP, L"选择一个文件覆盖，或新建一个新文件");
            SetWindowTextW(hDlg, L"保存歌曲列表");
        }
        else if (lParam == DLGTYPE_LOADLIST)
        {
            SetDlgItemTextW(hDlg, IDC_ST_TIP, L"选择一个文件载入");
            SetWindowTextW(hDlg, L"载入歌曲列表");
        }
        else
            EndDialog(hDlg, NULL);
		dwDlgType = lParam;
		HWND hLV = GetDlgItem(hDlg, IDC_LV_LISTFILE);
		// 插入列
		LVCOLUMNW lc = { 0 };
		WCHAR szTitle[5];
		lc.mask = LVCF_TEXT | LVCF_WIDTH;

		lstrcpyW(szTitle, L"列表文件");
		lc.pszText = szTitle;
		lc.cx = DPI(300);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 0, (LPARAM)&lc);

		lstrcpyW(szTitle, L"修改时间");
		lc.pszText = szTitle;
		lc.cx = DPI(150);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 1, (LPARAM)&lc);
		// 设置风格
		SetWindowLongPtrW(hLV, GWL_STYLE, GetWindowLongW(hLV, GWL_STYLE) | LVS_SINGLESEL);// 单一选择
		DWORD dwStyle = LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER;
		SendMessageW(hLV, LVM_SETEXTENDEDLISTVIEWSTYLE, dwStyle, dwStyle);// 整行选择，双缓冲
		SetWindowTheme(hLV, L"Explorer", NULL);// 可视风格
		// 枚举文件
		WIN32_FIND_DATAW wfd;
        WCHAR szListFile[MAX_PATH];
        lstrcpyW(szListFile, g_pszListDir);
        lstrcatW(szListFile, L"*.QKList");// 转换QKList扩展名
        HANDLE hFind = FindFirstFileW(szListFile, &wfd);// 开始枚举
        if (hFind == INVALID_HANDLE_VALUE)
            return FALSE;
        int iIndex;
        FILETIME ft;
        SYSTEMTIME st;
        WCHAR szTime[20];
        WCHAR szBuffer[3];
        LVITEMW li;
        do
        {
            li.mask = LVIF_TEXT;
            li.iItem = SendMessageW(hLV, LVM_GETITEMCOUNT, 0, 0);
            li.iSubItem = 0;
            PathRemoveExtensionW(wfd.cFileName);
            li.pszText = wfd.cFileName;
            iIndex = SendMessageW(hLV, LVM_INSERTITEMW, 0, (LPARAM)&li);// 插入表项

            FileTimeToLocalFileTime(&wfd.ftLastWriteTime, &ft);
            FileTimeToSystemTime(&ft, &st);

            wsprintfW(szTime, L"%d-%02d-%02d %02d:%02d:%02d",
                st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

            li.iSubItem = 1;
            li.pszText = szTime;
            SendMessageW(hLV, LVM_SETITEMTEXTW, iIndex, (LPARAM)&li);// 置标题
        } while (FindNextFileW(hFind, &wfd));// 继续枚举
        FindClose(hFind);// 释放
    }
    return FALSE;// 返回TRUE将设定具有WS_TABSTOP风格的第一个控件（wParam为窗口句柄），返回FALSE则不设定焦点
    case WM_CLOSE:
        EndDialog(hDlg, NULL);
        return TRUE;
    case WM_COMMAND:
    {
        switch (LOWORD(wParam))
        {
        case IDC_BT_OK:
        {
            DLGRESULT_LIST* pResult = new DLGRESULT_LIST;
            lstrcpyW(pResult->szFileName, g_pszListDir);
            WCHAR szFile[MAX_PATH];
            if (!GetWindowTextW(GetDlgItem(hDlg, IDC_ED_FILE), szFile, MAX_PATH))
            {
                ZeroMemory(pResult, 1);
            }
            lstrcatW(pResult->szFileName, szFile);
            lstrcatW(pResult->szFileName, L".QKList");
            if (dwDlgType == DLGTYPE_LOADLIST)
            {
                if (PathFileExistsW(pResult->szFileName))
                    EndDialog(hDlg, (INT_PTR)pResult);
                else
                    QKMessageBox(L"列表文件无效", L"选定的列表文件不存在", (HICON)TD_ERROR_ICON, L"错误");
            }
            else
                EndDialog(hDlg, (INT_PTR)pResult);
        }
        return TRUE;
        case IDC_BT_CANCEL:
            EndDialog(hDlg, NULL);
            return TRUE;
        }
    }
    return FALSE;
    case WM_NOTIFY:
    {
        if (wParam == IDC_LV_LISTFILE)// 不用这个老是报lParam无效指针
        {
            if (((NMHDR*)lParam)->code == LVN_ITEMCHANGED)
            {
                int iIndex = ((NMLISTVIEW*)lParam)->iItem;
                if (iIndex >= 0)
                {
                    LVITEMW li = { 0 };
                    li.mask = LVIF_TEXT;
                    li.iItem = iIndex;
                    li.iSubItem = 0;
                    li.cchTextMax = MAX_PATH;
                    li.pszText = new WCHAR[MAX_PATH];
                    SendMessageW(((NMHDR*)lParam)->hwndFrom, LVM_GETITEMW, 0, (LPARAM)&li);
                    SetDlgItemTextW(hDlg, IDC_ED_FILE, li.pszText);
                    delete[] li.pszText;
                    return TRUE;
                }
            }
        }
    }
    return FALSE;
    }
    return FALSE;// 处理一条消息时会返回TRUE，不处理一条消息时返回FALSE
}
void PlayNext(BOOL bReverse = FALSE)
{
    int iCount;
    if (m_iSearchResult != -1)
        iCount = m_iSearchResult;
    else
        iCount = QKArray_GetCount(g_ItemData);

    if (!iCount)
        return;

    int iIndex = g_iCurrFileIndex;
    if (g_iLaterPlay != -1)
    {
        iIndex = g_iLaterPlay;
        g_iLaterPlay = -1;
        SendMessageW(g_hLV, LVM_REDRAWITEMS, iIndex, iIndex);
        goto PlayFile;
    }
    if (bReverse)//倒序
    {
        for (int i = 0; i < g_ItemData->iCount; ++i)
        {
            --iIndex;
            if (iIndex < 0)
                iIndex = iCount - 1;

            if (!(List_GetArrayItem(iIndex)->dwFlags & QKLIF_IGNORED))
                goto PlayFile;
        }
    }
    else
    {
        for (int i = 0; i < g_ItemData->iCount; ++i)
        {
            ++iIndex;
            if (iIndex > iCount - 1)
                iIndex = 0;

            if (!(List_GetArrayItem(iIndex)->dwFlags & QKLIF_IGNORED))
                goto PlayFile;
        }
    }
    QKMessageBox(L"没有有效的项目", L"啥鼻，都忽略了你还听腻马啊", (HICON)TD_ERROR_ICON, L"错误");
    return;
PlayFile:
    PlayFile(iIndex);
}
void AutoNext()
{
    int i = SendMessageW(g_hBKBtm, BTMBKM_GETREPEATMODE, 0, 0);
    switch (i)
    {
    case REPEATMODE_TOTALLOOP://整体循环
        PlayNext();
        break;
    case REPEATMODE_SINGLELOOP://单曲循环
        PlayFile(g_iCurrFileIndex);
        break;
    case REPEATMODE_RADOM://随机播放

        break;
    case REPEATMODE_SINGLE://单曲播放
        Stop();
        break;
    case REPEATMODE_TOTAL:

        break;
    }
}
DWORD WINAPI Thread_GetWavesData(void* p)//调用前必须释放先前的内存
{
    HSTREAM hStream = BASS_OpenMusic(m_szCurrFile, BASS_STREAM_DECODE, BASS_MUSIC_DECODE | BASS_MUSIC_PRESCAN);
    int iCount = m_llLength / 20;
    if (iCount <= 0)
    {
        m_dwThreadFlags[0] = THREADFLAG_ERROR;
        BASS_FreeMusic(hStream);
        return 0;
    }
    m_dwWavesData = new DWORD[iCount];
    for (int i = 0; i < iCount; i++)
    {
        m_dwWavesData[i] = BASS_ChannelGetLevel(hStream);
        if (m_dwThreadFlags[0] == THREADFLAG_STOP)
            break;
    }
    BASS_FreeMusic(hStream);
    m_dwWavesDataCount = iCount;//计数
    m_dwThreadFlags[0] = THREADFLAG_STOPED;//已停止
    m_IsDraw[0] = TRUE;//立即重画
    return 0;
}
/*
 * 目标：处理歌词时间标签
 *
 * 参数：
 * TimeLabel 时间标签数组
 * pszLrc 与时间标签数组里所有成员都对应的歌词
 *
 * 返回值：
 * 操作简述：将文本标签转换成浮点数，并将其按次序装载到歌词数组中
 * 备注：读取歌词数据辅助函数，处理完成后不销毁原数组
 */
void GetLrcData_ProcLabel(QKARRAY* Result, QKARRAY TimeLabel, LPWSTR pszLrc)
{
    if (!TimeLabel)
        return;
    if (TimeLabel->iCount <= 0)
        return;

    for (int i = 0; i < TimeLabel->iCount; i++)
    {
        LPWSTR pszTimeLabel = (LPWSTR)QKArray_Get(TimeLabel, i);
        int iStrPos1, iStrPos2;
        iStrPos1 = QKStrInStr(pszTimeLabel, L":");
        if (iStrPos1 <= 0)
            continue;// 没冒号，到循环尾
        iStrPos2 = QKStrInStr(pszTimeLabel, L":", iStrPos1 + 1);
        PWSTR pszTempTime;
        DWORD dwLength;
        int M, S, MS;
        BOOL IsMS = TRUE;
        float fTime;
        if (iStrPos2 <= 0)// 是否[分:秒:毫秒]
        {
            iStrPos2 = QKStrInStr(pszTimeLabel, L".", iStrPos1 + 1);
            if (iStrPos2 <= 0)// 是否[分:秒.毫秒]
            {
                IsMS = FALSE;// [分:秒]
                iStrPos2 = lstrlenW(pszTimeLabel) + 1;
            }
        }
        ///////////////////取分钟
        dwLength = iStrPos1 - 1;
        pszTempTime = new WCHAR[dwLength + 1];
        lstrcpynW(pszTempTime, pszTimeLabel, dwLength + 1);
        if (!StrToIntExW(pszTempTime, STIF_DEFAULT, &M))
            continue;// 转换失败，到循环尾
        fTime = (float)M * 60.0f;
        delete[] pszTempTime;
        ///////////////////取秒
        dwLength = iStrPos2 - iStrPos1 - 1;
        pszTempTime = new WCHAR[dwLength + 1];
        lstrcpynW(pszTempTime, pszTimeLabel + iStrPos1, dwLength + 1);
        if (!StrToIntExW(pszTempTime, STIF_DEFAULT, &S))
            continue;
        fTime += S;
        delete[] pszTempTime;
        ///////////////////取毫秒
        if (IsMS)
        {
            dwLength = lstrlenW(pszTimeLabel) - iStrPos2;

            if (dwLength == 2)// 只有两位xx时表示xx0（精度降低了，单位是十毫秒）
            {
                ++dwLength;
                pszTempTime = new WCHAR[dwLength + 1];
                lstrcpynW(pszTempTime, pszTimeLabel + iStrPos2, dwLength + 1);
                lstrcatW(pszTempTime, L"0");// 补0
            }
            else
            {
                pszTempTime = new WCHAR[dwLength + 1];
                lstrcpynW(pszTempTime, pszTimeLabel + iStrPos2, dwLength + 1);
            }
            
            if (!StrToIntExW(pszTempTime, STIF_DEFAULT, &MS))
                continue;
            fTime += ((float)MS / 1000.0f);
            delete[] pszTempTime;
        }
        ///////////////////
        if (fTime < 0)
            continue;
        LRCDATA* p = new LRCDATA;
        p->fTime = fTime;
        p->cy = -1;// 负数无效
        p->iOrgLength = -1;// 缺省-1，说明没有第二行
		p->pszLrc = new WCHAR[lstrlenW(pszLrc) + 1];// 得拷贝一份，不同成员当然是互相独立的
        lstrcpyW(p->pszLrc, pszLrc);

        QKArray_Add(Result, p);
    }
}
/*
 * 目标：清除歌词数据
 *
 * 参数：
 *
 * 返回值：
 * 操作简述：
 * 备注：
 */
void ClearLrcData()
{
    for (int i = 0; i < g_Lrc->iCount; ++i)
    {
        delete[]((LRCDATA*)QKArray_Get(g_Lrc, i))->pszLrc;
    }
    QKArray_Delete(g_Lrc, QKADF_DELETE);
}
int IsTextUTF8(char* str, ULONGLONG length)
{
    int i;
    DWORD nBytes = 0;//UFT8可用1-6个字节编码,ASCII用一个字节
    UCHAR chr;
    BOOL bAllAscii = TRUE; //如果全部都是ASCII, 说明不是UTF-8
    for (i = 0; i < length; i++)
    {
        chr = *(str + i);
        if ((chr & 0x80) != 0) // 判断是否ASCII编码,如果不是,说明有可能是UTF-8,ASCII用7位编码,但用一个字节存,最高位标记为0,o0xxxxxxx
            bAllAscii = FALSE;
        if (nBytes == 0) //如果不是ASCII码,应该是多字节符,计算字节数
        {
            if (chr >= 0x80)
            {
                if (chr >= 0xFC && chr <= 0xFD)
                    nBytes = 6;
                else if (chr >= 0xF8)
                    nBytes = 5;
                else if (chr >= 0xF0)
                    nBytes = 4;
                else if (chr >= 0xE0)
                    nBytes = 3;
                else if (chr >= 0xC0)
                    nBytes = 2;
                else
                {
                    return FALSE;
                }
                nBytes--;
            }
        }
        else //多字节符的非首字节,应为 10xxxxxx
        {
            if ((chr & 0xC0) != 0x80)
            {
                return FALSE;
            }
            nBytes--;
        }
    }
    if (nBytes > 0) //违返规则
    {
        return FALSE;
    }
    if (bAllAscii) //如果全部都是ASCII, 说明不是UTF-8
    {
        return FALSE;
    }
    return TRUE;
}
/*
 * 目标：读取歌词数据
 *
 * 参数：
 * pStream 输入流，文件名或LRC文件数据字节流。当作为字节流输入时，函数复制缓冲区并使用副本
 * iSize 若输入LRC字节流，则该参数指示字节流长度
 * bFileName 指示pStream是否为文件名
 * Result 结果数组，调用函数前数组应初始化完毕
 * iDefTextCode 默认文本编码，0 自动；1 GB2312；2 UTF-8；3 UTF-16LE；4 UTF-16BE
 *
 * 返回值：
 * 操作简述：
 * 备注：我写的这算法有点哈人
 */
void Lrc_ParseLrcData(void* pStream, int iSize, BOOL bFileName, QKARRAY* IDResult, QKARRAY* Result, int iDefTextCode)
{
    //                                                                          ↓这里是要释放的对象↓
    ////////////////////////////读入并按换行符分割文件
    PWSTR pBuffer=NULL;
    int iBufPtrOffest = 0;
    DWORD dwBytes;
    if (bFileName)
    {
        /////////////准备文件名
        WCHAR szLrcFile[MAX_PATH];
        lstrcpyW(szLrcFile, m_szCurrFile);
        PathRemoveExtensionW(szLrcFile);
        lstrcatW(szLrcFile, L".lrc");// 转换lrc扩展名
        /////////////打开
        HANDLE hFile = CreateFileW(
            szLrcFile,
            GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL
        );// 打开文件                                                                文件句柄
        if (hFile == INVALID_HANDLE_VALUE)// 打开失败
            return;
         dwBytes = GetFileSize(hFile, NULL);// 取字节数
        if (dwBytes < 5)// [a:b]  最短情况，处理这个主要为了对比BOM的时候不越界
        {
            CloseHandle(hFile);
            return;// 打开失败
            //                                                                      ***若出错退出，则释放
        }

        DWORD dwBytesRead;
        pBuffer = (PWSTR)HeapAlloc(GetProcessHeap(), 0, dwBytes + 2);// 分一块内存用来放文件信息（其实文件映射也可以的啦）
        *(WCHAR*)((BYTE*)pBuffer + dwBytes) = L'\0';// 把结尾NULL安上
        //                                                                          文件句柄，缓冲区
        ReadFile(hFile, pBuffer, dwBytes, &dwBytesRead, NULL);// 读入
        CloseHandle(hFile);
    }
    else
    {
        dwBytes = iSize;

        pBuffer = (PWSTR)HeapAlloc(GetProcessHeap(), 0, iSize + 2);
        memcpy(pBuffer, pStream, iSize);
        *(WCHAR*)((BYTE*)pBuffer + iSize) = L'\0';// 把结尾NULL安上
    }
    /////////////判断、转换编码
    DWORD dwLength;
    UINT uCode;

    CHAR cHeader[3] = { (CHAR)0xFF,(CHAR)0xFE,0 };// UTF-16LE BOM:FF FE
    if (memcmp(pBuffer, cHeader, 2) == 0)// 检查BOM
    {
        iBufPtrOffest = 2;// 跳过BOM

        pBuffer = (PWSTR)((BYTE*)pBuffer + iBufPtrOffest);
        dwBytes -= iBufPtrOffest;
        goto GetLrc_UTF16LE;
    }
    else
    {
        cHeader[0] = (CHAR)0xFE;
        cHeader[1] = (CHAR)0xFF;
        if (memcmp(pBuffer, cHeader, 2) == 0)// UTF-16BE
        {
            iBufPtrOffest = 2;// 跳过BOM

            pBuffer = (PWSTR)((BYTE*)pBuffer + iBufPtrOffest);
            dwBytes -= iBufPtrOffest;
            goto GetLrc_UTF16BE;
        }
        else
        {
            // UTF-8 BOM:EF BB BF 
            cHeader[0] = (CHAR)0xEF;
            cHeader[1] = (CHAR)0xBB;
            cHeader[2] = (CHAR)0xBF;
            if (memcmp(pBuffer, cHeader, 3) == 0)// 检查BOM
            {
                iBufPtrOffest = 3;// 跳过BOM

                pBuffer = (PWSTR)((BYTE*)pBuffer + iBufPtrOffest);
                dwBytes -= iBufPtrOffest;

                *((CHAR*)pBuffer + dwBytes) = '\0';
                dwLength = MultiByteToWideChar(CP_UTF8, 0, (CHAR*)pBuffer, -1, NULL, 0);// 用了-1，返回值表示的字节数包含结尾NULL

                PWSTR pBuf = (PWSTR)HeapAlloc(GetProcessHeap(), 0, dwLength * sizeof(WCHAR));
                MultiByteToWideChar(CP_UTF8, 0, (CHAR*)pBuffer, -1, pBuf, dwLength);// 转换编码
				HeapFree(GetProcessHeap(), 0, (BYTE*)pBuffer - iBufPtrOffest);

                iBufPtrOffest = 0;
                pBuffer = pBuf;
                dwLength--;// 减掉结尾NULL
            }
            else// 无BOM
            {
                switch (iDefTextCode)
                {
				case 0:// 自动
				{
					int i = IS_TEXT_UNICODE_REVERSE_MASK | IS_TEXT_UNICODE_NULL_BYTES;
					if (IsTextUnicode(pBuffer, dwBytes, &i))//  先测UTF-16BE，不然会出问题
						goto GetLrc_UTF16LE;
					else
					{
						i = IS_TEXT_UNICODE_UNICODE_MASK | IS_TEXT_UNICODE_NULL_BYTES;
						if (IsTextUnicode(pBuffer, dwBytes, &i))
							goto GetLrc_UTF16BE;
						else if (IsTextUTF8((char*)pBuffer, dwBytes))
							goto GetLrc_UTF8;
						else
							goto GetLrc_GB2312;
					}
				}
				return;
				case 1:// GB2312
				{
				GetLrc_GB2312:
					uCode = 936;
					*((CHAR*)pBuffer + dwBytes) = '\0';// 截断
				}
				break;// 跳出switch转编码
				case 2:// UTF-8
				{
				GetLrc_UTF8:
					uCode = CP_UTF8;
					*((CHAR*)pBuffer + dwBytes) = '\0';// 截断
				}
				break;// 跳出switch转编码
                case 3:// UTF-16LE
                {
                GetLrc_UTF16LE:// 有BOM和自动判断的跳过来
                    dwLength = dwBytes / sizeof(WCHAR);
                    goto UTF16_SkipOthers;// 跳出去
                }
                break;
                case 4:// UTF-16BE
                {
                GetLrc_UTF16BE:// 有BOM和自动判断的跳过来
                    dwLength = dwBytes / sizeof(WCHAR);
                    PWSTR pBuf = (PWSTR)HeapAlloc(GetProcessHeap(), 0, dwBytes + sizeof(WCHAR));
                    LCMapStringEx(LOCALE_NAME_USER_DEFAULT, LCMAP_BYTEREV, (PCWSTR)pBuffer, dwLength, pBuf, dwLength, NULL, NULL, 0);// 反转字节序
                    *((WCHAR*)pBuf + dwLength) = L'\0';
                    HeapFree(GetProcessHeap(), 0, (BYTE*)pBuffer - iBufPtrOffest);
                    pBuffer = pBuf;
                    iBufPtrOffest = 0;
                    goto UTF16_SkipOthers;// 跳出去
                }
                break;
                }

                dwLength = MultiByteToWideChar(uCode, 0, (CHAR*)pBuffer, -1, NULL, 0);
                PWSTR pBuf = (PWSTR)HeapAlloc(GetProcessHeap(), 0, dwLength * sizeof(WCHAR));
                MultiByteToWideChar(uCode, 0, (CHAR*)pBuffer, -1, pBuf, dwLength);// 转换编码
                HeapFree(GetProcessHeap(), 0, (BYTE*)pBuffer - iBufPtrOffest);
                pBuffer = pBuf;
                dwLength--;// 减掉结尾NULL
                iBufPtrOffest = 0;
            }
        }
	}
UTF16_SkipOthers:// UTF-16的两种编码处理方式不同，它俩处理完后直接跳到这里
	//                                                                          缓冲区
	/////////////准备分割
	QKARRAY LrcLines = QKArray_Create(0);// 储存每行歌词
    //                                                                          缓冲区，文本行数组
    /////////////三种换行符
    WCHAR szDiv1[3] = L"\r\n";// CRLF
    WCHAR szDiv2[2] = L"\n";// LF
    WCHAR szDiv3[2] = L"\r";// CR

    BOOL b1 = FALSE, b2 = FALSE, b3 = FALSE;

    int i1 = QKStrInStr(pBuffer, szDiv1),
        i2 = QKStrInStr(pBuffer, szDiv2),
        i3 = QKStrInStr(pBuffer, szDiv3);

    if (i1)
        b1 = TRUE;
    if (i2)
        b2 = TRUE;
    if (i3)
        b3 = TRUE;

    PWSTR pszLine;// 每行内容
    int iLineLength;// 每行内容长度

    int iStrPos1;
    int iStrPos2 = 1;
    int iDivLength;

    if (!b1 && !b2 && !b3)// 无换行符
    {
        pszLine = new WCHAR[dwLength + 1];
        lstrcpynW(pszLine, pBuffer, dwLength + 1);//直接读到底
        QKArray_Add(&LrcLines, pszLine);
    }
    else
    {
        // 为什么要这么写？没错，有的歌词文件就是变态到几种换行符一起用.......
        // 其实这部分逻辑是之后加上的，之前的解决方案是让用户快爬（bushi）
        if (b1)// CRLF
        {
            // 思路：iStrPos1 = min(i1, i2, i3)
            iStrPos1 = i1;
            iDivLength = 2;
            if (b2 && i1 >= i2)// LF
            {
                iStrPos1 = i2;
                iDivLength = 1;
            }
            if (b3 && i3 < iStrPos1)// CR
            {
                iStrPos1 = i3;
                iDivLength = 1;
            }
        }
        else
        {
            // 思路：iStrPos1 = min(i2, i3)
            iDivLength = 1;
            if (b2 && b3)// 没有CRLF，但CR和LF同时存在
            {
                if (i2 < i3)
                    iStrPos1 = i2;
                else
                    iStrPos1 = i3;
            }
            else if (b2)// LF
                iStrPos1 = i2;
            else// CR
                iStrPos1 = i3;
        }


        while (iStrPos1)
        {
            iLineLength = iStrPos1 - iStrPos2;
            if (iLineLength > 0)
            {
                pszLine = new WCHAR[iLineLength + 1];
                lstrcpynW(pszLine, pBuffer + iStrPos2 - 1, iLineLength + 1);// 拷贝一行
                QKArray_Add(&LrcLines, pszLine);
            }
            iStrPos2 = iStrPos1 + iDivLength;// 跳过换行符
            /////////////取下一换行符位置
            if (b1)
                i1 = QKStrInStr(pBuffer, szDiv1, iStrPos2);
            if (b2)
                i2 = QKStrInStr(pBuffer, szDiv2, iStrPos2);
            if (b3)
                i3 = QKStrInStr(pBuffer, szDiv3, iStrPos2);

            iStrPos1 = 0;
            if (i1)// CRLF
            {
                iStrPos1 = i1;
                iDivLength = 2;
                if (i2 && i1 >= i2)// LF
                {
                    iStrPos1 = i2;
                    iDivLength = 1;
                }
                if (i3 && i3 < iStrPos1)// CR
                {
                    iStrPos1 = i3;
                    iDivLength = 1;
                }
            }
            else
            {
                if (i2 && i3)// CR  LF
                {
                    iDivLength = 1;
                    if (i2 < i3)
                        iStrPos1 = i2;
                    else
                        iStrPos1 = i3;
                }
                else if (i2)// LF
                {
                    iDivLength = 1;
                    iStrPos1 = i2;
                }
                else if (i3)// CR，这里跟上面是不一样的，必须用else if
                {
                    iDivLength = 1;
                    iStrPos1 = i3;
                }
            }
        }
        iLineLength = dwLength - iStrPos2 + 1;//处理末尾一行文本
        if (iLineLength > 0)
        {
            pszLine = new WCHAR[iLineLength + 1];
            lstrcpynW(pszLine, pBuffer + iStrPos2 - 1, iLineLength + 1);
            QKArray_Add(&LrcLines, pszLine);
        }
    }
	HeapFree(GetProcessHeap(), 0, (BYTE*)pBuffer - iBufPtrOffest);//释放文件内容缓冲区
    //                                                                          文本行数组
    //至此文件分割完毕
    ////////////////////////////处理每行标签
    int iStrPos3;
    QKARRAY SameUnitTimeLabel = NULL;
    PWSTR pszLrc;
    PWSTR pszTimeLabel;
    DWORD dwLrcLength;
    DWORD dwLength2;

    for (int i = 0; i < LrcLines->iCount; i++)// 读每一行
    {
        pszLine = (LPWSTR)QKArray_Get(LrcLines, i);// 读入一行
        iStrPos1 = QKStrInStr(pszLine, L"[");// 先找左中括号
        iStrPos2 = 1;
        if (iStrPos1 <= 0)// 找不到左中括号
            continue;// 到循环尾（处理下一行）   
        SameUnitTimeLabel = QKArray_Create(0);// 相同的时间标签
        //                                                                      文本行数组，同时间数组
        while (true)// 行中循环取标签（一行中可能有多个标签）
        {
            iStrPos2 = QKStrInStr(pszLine, L"]", iStrPos2);
            if (iStrPos2 <= 0 || iStrPos2 <= iStrPos1)
                iStrPos1 = iStrPos2 = 0;// 中括号错误，直接进行下一次循环，md歌词文件不规范的爬爬爬，劳资可不给你写容错（暴躁）
            dwLength = iStrPos2 - iStrPos1 - 1;
            iStrPos3 = QKStrInStr(pszLine, L"[", iStrPos1 + dwLength + 1);

            if (iStrPos3 - iStrPos2 - 1 == 0)// 紧贴着，类似于这种：[xx:xx][yy:yy]zzzzzzzzzzzzz
            {
                pszTimeLabel = new WCHAR[dwLength + 1];
                lstrcpynW(pszTimeLabel, pszLine + iStrPos1, dwLength + 1);
                QKArray_Add(&SameUnitTimeLabel, pszTimeLabel);
                iStrPos1 = iStrPos3;
                iStrPos2 = iStrPos1 + 1;
            }
            else if (iStrPos3 == 0 || iStrPos2 == 0)// 没有下一个标签了，这一行到头了
            {
                dwLrcLength = lstrlenW(pszLine) - iStrPos2;
                pszLrc = new WCHAR[dwLrcLength + 1];
                lstrcpynW(pszLrc, pszLine + iStrPos2, dwLrcLength + 1);// 取歌词

                pszTimeLabel = new WCHAR[dwLength + 1];
                lstrcpynW(pszTimeLabel, pszLine + iStrPos1, dwLength + 1);// 取标签
                QKArray_Add(&SameUnitTimeLabel, pszTimeLabel);

				GetLrcData_ProcLabel(Result, SameUnitTimeLabel, pszLrc);
                QKArray_Delete(SameUnitTimeLabel, QKADF_DELETEARRAY);
                delete[] pszLrc;
                break;
            }
            else// 处理完一行中的一句，类似于[xx:xx]aaaaaaaaa[yy:yy]bbbbbbbbbbbb，现在处理完a或b了
            {
                dwLrcLength = iStrPos3 - iStrPos2 - 1;
                pszLrc = new WCHAR[dwLrcLength + 1];
                lstrcpynW(pszLrc, pszLine + iStrPos2, dwLrcLength + 1);

                pszTimeLabel = new WCHAR[dwLength + 1];
                lstrcpynW(pszTimeLabel, pszLine + iStrPos1, dwLength + 1);
                QKArray_Add(&SameUnitTimeLabel, pszTimeLabel);
                dwLength2 = iStrPos3 - iStrPos2 - 1;

                GetLrcData_ProcLabel(Result, SameUnitTimeLabel, pszLrc);
                QKArray_Delete(SameUnitTimeLabel, QKADF_DELETEARRAY);
                delete[] pszLrc;
                SameUnitTimeLabel = QKArray_Create(0);
                iStrPos1 = iStrPos3;
                iStrPos2 = iStrPos1 + 1;
            }
            iStrPos1 = iStrPos2;
        }
    }
    QKArray_Delete(LrcLines, QKADF_DELETEARRAY);
    //                                                                          ***无临时对象
    ////////////////////////////排序数组，便于合并歌词
    int iCount = (*Result)->iCount;
    LRCDATA* pi, * pj;
    for (int i = 0; i != iCount; ++i)
    {
        for (int j = 0; j != iCount; ++j)
        {
            pi = (LRCDATA*)QKArray_Get((*Result), i);
            pj = (LRCDATA*)QKArray_Get((*Result), j);
            if (pi->fTime < pj->fTime)
            {
                QKArray_Set((*Result), j, pi);
                QKArray_Set((*Result), i, pj);
            }
        }
    }
    ////////////////////////////合并时间相同的歌词
    QKARRAY ArrLastTime = QKArray_Create(0);// 成员是float型
    QKARRAY ArrDelIndex = QKArray_Create(0);// 成员是int型
	//                                                                          上一时间数组，需删除索引数组
	PWSTR p1, p2, pszNewLrc;
	LRCDATA* p, * pItem;
	for (int i = 0; i < iCount; i++)
	{
        p = (LRCDATA*)QKArray_Get(*Result, i);
        int iLastTimeCount = ArrLastTime->iCount;
        if (iLastTimeCount != 0 && i != 0)
        {
			if (*(float*)QKArray_GetValue(ArrLastTime, 0) == p->fTime)
			{
				pItem = (LRCDATA*)QKArray_Get(*Result, i - iLastTimeCount);
				p1 = pItem->pszLrc;
				p2 = p->pszLrc;
				QKStrTrim(p1);
				QKStrTrim(p2);
				int iLen1 = lstrlenW(p1), iLen2 = lstrlenW(p2);

				if (iLen1 && !iLen2)// 只有第一个
				{
				}// 什么都不做
				else if (!iLen1 && iLen2)// 只有第二个
				{
					pszNewLrc = new WCHAR[iLen2 + 1];
					lstrcpyW(pszNewLrc, p2);
					delete[] pItem->pszLrc;
					pItem->pszLrc = pszNewLrc;
					pItem->iOrgLength = -1;
				}
				else if (!iLen1 && !iLen2)// 两个都没有
                {
                    pszNewLrc = new WCHAR;
                    *pszNewLrc = '\0';
                    delete[] pItem->pszLrc;
                    pItem->pszLrc = pszNewLrc;
                    pItem->iOrgLength = -1;
				}
				else// 两个都有
				{
					pItem->iOrgLength = iLen1;
					pszNewLrc = new WCHAR[iLen1 + iLen2 + 2];
					lstrcpyW(pszNewLrc, p1);
					lstrcatW(pszNewLrc, L"\n");// 换行符连接
                    lstrcatW(pszNewLrc, p2);

                    delete[] pItem->pszLrc;
                    pItem->pszLrc = pszNewLrc;
                }
                QKArray_AddValue(&ArrDelIndex, &i);
            }
            else
            {
                QKArray_Delete(ArrLastTime);
                ArrLastTime = QKArray_Create(0);
            }
        }
        QKArray_AddValue(&ArrLastTime, &p->fTime);
    }
    QKArray_Delete(ArrLastTime);
    //                                                                          需删除索引数组
    ////////////////////////////删除多余成员
    for (int i = 0; i < ArrDelIndex->iCount; i++)
    {
        int iIndex = *((int*)QKArray_GetValue(ArrDelIndex, ArrDelIndex->iCount - i - 1));// 倒着删
        LRCDATA* p = (LRCDATA*)QKArray_Get(*Result, iIndex);
        delete[] p->pszLrc;

        QKArray_DeleteMember(Result, iIndex, QKADF_DELETE);
    }
    QKArray_Delete(ArrDelIndex);
    for (int i = 0; i < (*Result)->iCount; i++)
    {
        p = (LRCDATA*)QKArray_Get(*Result, i);
        if (i != (*Result)->iCount - 1)
            p->fDelay = ((LRCDATA*)QKArray_Get(*Result, i + 1))->fTime - p->fTime;
        else
            p->fDelay = m_llLength / 1000 - p->fTime;
    }
    //                                                                          ***无临时对象
    ////////////////////////////结束！！
}
void CALLBACK TimerProc(HWND hWnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
    switch (idEvent)
    {
    case IDT_DRAWING_WAVES:
    {
        g_fTime = BASS_ChannelBytes2Seconds(
            g_hStream,
            BASS_ChannelGetPosition(g_hStream, BASS_POS_BYTE)
        );

        if (!m_IsDraw[0])
            return;

        RECT rc = { m_xWaves,m_yWaves,m_xWaves + DPIS_CXSPE,m_yWaves + DPIS_CYSPE };

        HDC hDC = GetDC(g_hBKLeft);
        BitBlt(m_hcdcLeftBK2, m_xWaves, m_yWaves, DPIS_CXSPE, DPIS_CYSPE, m_hcdcLeftBK, m_xWaves, m_yWaves, SRCCOPY);
        LPCWSTR pszText = NULL;
        if (m_dwThreadFlags[0] == THREADFLAG_WORKING)// 正在加载
            pszText = L"正在加载...";
        else if (!g_hStream)// 已停止
            pszText = L"未播放";
        else if (m_dwThreadFlags[0] == THREADFLAG_ERROR)// 出错
            pszText = L"错误！";

        if (pszText)
        {
            m_IsDraw[0] = FALSE;
            SetTextColor(m_hcdcLeftBK2, QKCOLOR_CYANDEEPER);// 蓝色

            DrawTextW(m_hcdcLeftBK2, pszText, -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);// 画错误提示
            BitBlt(hDC, m_xWaves, m_yWaves, DPIS_CXSPE, DPIS_CYSPE, m_hcdcLeftBK2, m_xWaves, m_yWaves, SRCCOPY);// 显示
            ReleaseDC(g_hBKLeft, hDC);
            return;
        }

        if (m_dwThreadFlags[0] == THREADFLAG_STOPED)
        {
            int iCurrIndex = (int)(g_fTime * 1000.0 / 20.0);// 算数组索引    20ms一单位
            if (iCurrIndex < 0 || iCurrIndex > m_dwWavesDataCount - 1)
            {
                ReleaseDC(g_hBKLeft, hDC);
                return;
            }

            int i = iCurrIndex;
            int x = m_xWaves + DPIS_CXSPEHALF,
                y = m_yWaves + DPIS_CYSPEHALF;
            HGDIOBJ hOldPen = SelectObject(m_hcdcLeftBK2, CreatePen(PS_SOLID, DPIS_CXWAVESLINE, 0xDA9E46));

            HRGN hRgn = CreateRectRgnIndirect(&rc);
            SelectClipRgn(m_hcdcLeftBK2, hRgn);// 不剪辑的话画笔会越界...应该是设置了画笔宽度的原因
            DeleteObject(hRgn);

            // 上面是右声道，下面是左声道
            while (true)// 向右画
            {
                MoveToEx(m_hcdcLeftBK2, x, y, NULL);
                LineTo(m_hcdcLeftBK2, x, y - HIWORD(m_dwWavesData[i]) * DPIS_CYSPEHALF / 32768);
                MoveToEx(m_hcdcLeftBK2, x, y, NULL);
                LineTo(m_hcdcLeftBK2, x, y + LOWORD(m_dwWavesData[i]) * DPIS_CYSPEHALF / 32768);
                x += DPIS_CXWAVESLINE;
                i++;
                if (i > m_dwWavesDataCount - 1 || x >= m_xWaves + DPIS_CXSPE)
                    break;
            }
            i = iCurrIndex;
            x = m_xWaves + DPIS_CXSPEHALF;
            while (true)// 向左画
            {
                MoveToEx(m_hcdcLeftBK2, x, y, NULL);
                LineTo(m_hcdcLeftBK2, x, y - (int)((float)HIWORD(m_dwWavesData[i]) / 32768.0f * (float)DPIS_CYSPEHALF));
                MoveToEx(m_hcdcLeftBK2, x, y, NULL);
                LineTo(m_hcdcLeftBK2, x, y + (int)((float)LOWORD(m_dwWavesData[i]) / 32768.0f * (float)DPIS_CYSPEHALF));
                x -= DPIS_CXWAVESLINE;
                i--;
                if (i < 0 || x < m_xWaves)
                    break;
            }
            x = m_xWaves + DPIS_CXSPEHALF;

            DeleteObject(SelectObject(m_hcdcLeftBK2, CreatePen(PS_SOLID, DPIS_CXWAVESLINE, QKCOLOR_RED)));
            MoveToEx(m_hcdcLeftBK2, x, m_yWaves, NULL);
            LineTo(m_hcdcLeftBK2, x, m_yWaves + DPIS_CYSPE);
            DeleteObject(SelectObject(m_hcdcLeftBK2, hOldPen));
            SelectClipRgn(m_hcdcLeftBK2, NULL);
        }
        BitBlt(hDC, m_xWaves, m_yWaves, DPIS_CXSPE, DPIS_CYSPE, m_hcdcLeftBK2, m_xWaves, m_yWaves, SRCCOPY);//显示
        ReleaseDC(g_hBKLeft, hDC);

        
    }
    return;
    case IDT_DRAWING_LRC:
    {
        RECT rc;
        HDC hDC;
        BOOL bSwitchLrc;
        if (m_IsDraw[2])
        {
            PCWSTR pszText = NULL;
            if (!g_hStream)
            {
                pszText = L"☆★晴空的音乐播放器★☆";
                g_iLrcState = LRCSTATE_STOP;
                g_iCurrLrcIndex = -2;
            }
            else if (!g_Lrc->iCount)//无歌词
            {
                pszText = L"无歌词(─.─|||";
                g_iLrcState = LRCSTATE_NOLRC;
                g_iCurrLrcIndex = -2;
            }

            if (pszText)
            {
                hDC = GetDC(g_hBKLeft);
                BitBlt(m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
                    m_hcdcLeftBK, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);//清除
                m_IsDraw[2] = FALSE;
                SetTextColor(m_hcdcLeftBK2, QKCOLOR_CYANDEEPER);
                DrawTextW(m_hcdcLeftBK2, pszText, -1, &m_rcLrcShow, DT_CENTER);
                LrcWnd_DrawLrc();
                BitBlt(hDC, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
                    m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);// 显示
                ReleaseDC(g_hBKLeft, hDC);
                return;
            }
        }

        m_iLrcCenter = -1;
        g_iCurrLrcIndex = -2;
        static int iLastIndex[2];//0：上次中心；1：上次高亮
        if (g_Lrc->iCount)
        {
            int iArrayCount = g_Lrc->iCount;
            for (int i = 0; i < iArrayCount; i++)//遍历歌词数组
            {
                float fTempTime = ((LRCDATA*)QKArray_Get(g_Lrc, i))->fTime;
                if (g_fTime < ((LRCDATA*)QKArray_Get(g_Lrc, 0))->fTime)//还没播到第一句
                {
                    m_iLrcCenter = 0;
                    g_iCurrLrcIndex = -1;
                    break;
                }
                else if (i == iArrayCount - 1)//最后一句
                {
                    if (g_fTime >= fTempTime)
                    {
                        m_iLrcCenter = g_iCurrLrcIndex = i;
                        break;
                    }
                }
                else if (g_fTime >= fTempTime && g_fTime < ((LRCDATA*)QKArray_Get(g_Lrc, i + 1))->fTime)//左闭右开，判断歌词区间
                {
                    m_iLrcCenter = g_iCurrLrcIndex = i;
                    break;
				}
			}
			if (m_iLrcSBPos != -1)
				m_iLrcCenter = m_iLrcSBPos;
			if (m_iLrcFixedIndex != -1)
                m_iLrcCenter = m_iLrcFixedIndex;
            // 索引查找完毕
            if (m_iLrcCenter != iLastIndex[0] || g_iCurrLrcIndex != iLastIndex[1])
            {
                m_IsDraw[2] = TRUE;
                bSwitchLrc = TRUE;
            }
            else
                bSwitchLrc = FALSE;
        }

		if (m_IsDraw[2])
		{
            ++m_iDrawingID;
            if (!m_iDrawingID)
                ++m_iDrawingID;
			g_iLrcState = LRCSTATE_NORMAL;
			if (bSwitchLrc && GS.bLrcAnimation && m_iLrcCenter != iLastIndex[0] && m_iLrcSBPos == -1 && iLastIndex[0] != -1)
			{
				UINT uFlags = DT_NOPREFIX | DT_CALCRECT | (GS.bForceTwoLines ? 0 : DT_CENTER | DT_WORDBREAK);
				if (iLastIndex[0] > g_Lrc->iCount - 1)
					iLastIndex[0] = g_Lrc->iCount - 1;;
				LRCDATA* p1 = (LRCDATA*)QKArray_Get(g_Lrc, m_iLrcCenter), * p2 = (LRCDATA*)QKArray_Get(g_Lrc, iLastIndex[0]);
				int iHeight = DrawTextW(m_hcdcLeftBK2, p1->pszLrc, -1, &rc, uFlags);
				int iHeight2 = DrawTextW(m_hcdcLeftBK2, p2->pszLrc, -1, &rc, uFlags);
				int iTop = m_rcLrcShow.top + (m_cyLrcShow - iHeight2) / 2;
				m_LrcVScrollInfo.iDestTop = m_rcLrcShow.top + (m_cyLrcShow - iHeight) / 2;;
				m_LrcVScrollInfo.fDelay = 0.1f;
				m_LrcVScrollInfo.fTime = g_fTime;
				float ff;
				if (m_iLrcCenter > iLastIndex[0])
				{
					m_LrcVScrollInfo.bDirection = TRUE;
					m_LrcVScrollInfo.iSrcTop = iTop + iHeight2 + DPIS_LRCSHOWGAP;
					m_LrcVScrollInfo.iDistance = m_LrcVScrollInfo.iSrcTop - m_LrcVScrollInfo.iDestTop;
					ff = p1->fTime - p2->fTime;
					if (m_LrcVScrollInfo.fDelay > ff)
						m_LrcVScrollInfo.fDelay = ff / 2;
				}
				else
				{
					m_LrcVScrollInfo.bDirection = FALSE;
					m_LrcVScrollInfo.iSrcTop = iTop - DPIS_LRCSHOWGAP - iHeight;
					m_LrcVScrollInfo.iDistance = m_LrcVScrollInfo.iDestTop - m_LrcVScrollInfo.iSrcTop;
					ff = p2->fTime - p1->fTime;
					if (m_LrcVScrollInfo.fDelay > ff)
						m_LrcVScrollInfo.fDelay = ff / 2;
				}
				KillTimer(g_hMainWnd, IDT_ANIMATION2);
				SetTimer(g_hMainWnd, IDT_ANIMATION2, TIMERELAPSE_ANIMATION2, TimerProc);
				LrcWnd_DrawLrc();
				iLastIndex[0] = m_iLrcCenter;
				iLastIndex[1] = g_iCurrLrcIndex;
				m_IsDraw[2] = FALSE;
				return;
			}

            BitBlt(m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
                m_hcdcLeftBK, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);//清除
            HRGN hLrcShowRgn = CreateRectRgnIndirect(&m_rcLrcShow);
            SelectClipRgn(m_hcdcLeftBK2, hLrcShowRgn);//设置剪辑区
            DeleteObject(hLrcShowRgn);
            iLastIndex[0] = m_iLrcCenter;
            iLastIndex[1] = g_iCurrLrcIndex;
            m_IsDraw[2] = FALSE;//如果歌词没有变化，下一次周期事件就不要再画了
            ////////////////////////////////////////////////画中间文本
			LRCDATA* p = (LRCDATA*)QKArray_Get(g_Lrc, m_iLrcCenter);
			rc = m_rcLrcShow;
			int iHeight = DrawTextW(m_hcdcLeftBK2, p->pszLrc, -1, &rc,
				DT_NOPREFIX | DT_CALCRECT | (GS.bForceTwoLines ? 0 : DT_CENTER | DT_WORDBREAK));

			int iTop = m_rcLrcShow.top + (m_cyLrcShow - iHeight) / 2;
			iHeight = Lrc_DrawItem(m_iLrcCenter, iTop, TRUE, FALSE, FALSE);
			int iBottom = iTop - DPIS_LRCSHOWGAP;
			iTop += (DPIS_LRCSHOWGAP + iHeight);
            LrcWnd_DrawLrc();
            
			int i = m_iLrcCenter;
			////////////////////////////////////////////////向上画
			while (iBottom > m_rcLrcShow.top)
			{
				if (i - 1 < 0)
					break;
				--i;
				iHeight = Lrc_DrawItem(i, iBottom, FALSE, FALSE, FALSE);
				iBottom -= (DPIS_LRCSHOWGAP + iHeight);
			}
			i = m_iLrcCenter;
			////////////////////////////////////////////////向下画
			while (iTop < m_rcLrcShow.bottom)
			{
				if (i + 1 >= g_Lrc->iCount)
					break;
				++i;
				iHeight = Lrc_DrawItem(i, iTop, TRUE, FALSE, FALSE);
				iTop += (DPIS_LRCSHOWGAP + iHeight);
			}
			SelectClipRgn(m_hcdcLeftBK2, NULL);//清除剪辑区
			hDC = GetDC(g_hBKLeft);
            BitBlt(hDC, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
                m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);// 显示
			ReleaseDC(g_hBKLeft, hDC);
		}
    }
    return;
    case IDT_DRAWING_SPE:
    {
		int iCount = SPECOUNT;
		int m = DPIS_CXSPE - (DPIS_CXSPEBAR + DPIS_CXSPEBARDIV) * SPECOUNT;
		if (m >= DPIS_CXSPEBAR)
		{
			iCount += m / (DPIS_CXSPEBAR + DPIS_CXSPEBARDIV);
			if (iCount > 128)
				iCount = 128;
		}

		static int cySpeOld[128] = { 0 }, cySpe[128] = { 0 }, yMaxMark[128] = { 0 };
		static int iTime[128] = { 0 };
		static float fData[128] = { 0 };
		BitBlt(m_hcdcLeftBK2, m_xSpe, m_ySpe, DPIS_CXSPE, DPIS_CYSPE, m_hcdcLeftBK, m_xSpe, m_ySpe, SRCCOPY);
		if (BASS_ChannelGetData(g_hStream, fData, BASS_DATA_FFT256) == -1)
		{
			ZeroMemory(cySpeOld, sizeof(cySpeOld));
			ZeroMemory(cySpe, sizeof(cySpe));
		}

		for (int i = 0; i < iCount; i++)
		{
			++iTime[i];
			cySpe[i] = abs((int)(fData[i] * 300.0f));
			//////////////////频谱条
			if (cySpe[i] > DPIS_CYSPE)// 超高
				cySpe[i] = DPIS_CYSPE;// 回来

			if (cySpe[i] > cySpeOld[i])// 当前的大于先前的
				cySpeOld[i] = cySpe[i];// 顶上去
			else
				cySpeOld[i] -= SPESTEP_BAR;// 如果不大于就继续落

			if (cySpeOld[i] < 3)// 太低了
				cySpeOld[i] = 3;// 回来
			//////////////////峰值
			if (iTime[i] > 10)// 时间已到
				yMaxMark[i] -= SPESTEP_MAX;// 下落

			if (cySpeOld[i] > yMaxMark[i])// 频谱条大于峰值
			{
				yMaxMark[i] = cySpeOld[i];// 峰值顶上去，重置时间
				iTime[i] = 0;
			}

			if (yMaxMark[i] < 3)// 太低了
				yMaxMark[i] = 3;// 回来
			//////////////////绘制
			//////////制频谱条矩形
			RECT rc;
			rc.left = m_xSpe + (DPIS_CXSPEBAR + 1) * i;
			rc.top = m_ySpe + DPIS_CYSPE - cySpeOld[i];
			rc.right = rc.left + DPIS_CXSPEBAR;
			rc.bottom = m_ySpe + DPIS_CYSPE;
			FillRect(m_hcdcLeftBK2, &rc, GC.hbrMyBule);
			//////////制峰值指示矩形
			rc.top = m_ySpe + DPIS_CYSPE - yMaxMark[i];
			rc.bottom = rc.top + 3;
			FillRect(m_hcdcLeftBK2, &rc, GC.hbrMyBule);
		}
		HDC hDC = GetDC(g_hBKLeft);
		BitBlt(hDC, m_xSpe, m_ySpe, DPIS_CXSPE, DPIS_CYSPE, m_hcdcLeftBK2, m_xSpe, m_ySpe, SRCCOPY);// 显示
		ReleaseDC(g_hBKLeft, hDC);
	}
	return;
	case IDT_ANIMATION:
	{
		if (m_LrcHScrollInfo.iIndex == -1)
			return;
		LRCDATA* p = (LRCDATA*)QKArray_Get(g_Lrc, g_iCurrLrcIndex);
		float fLastTime = g_fTime - p->fTime;
		static int iLastx1 = 0, iLastx2 = 0;// 上次左边，如果跟上次一样就不要再画了
		int ii;
		BOOL bRedraw = FALSE;
		if (m_LrcHScrollInfo.cx1 != -1)
		{
			if (fLastTime > m_LrcHScrollInfo.fNoScrollingTime1)
			{
				if (fLastTime < p->fDelay - m_LrcHScrollInfo.fNoScrollingTime1)
                {
                    ii = m_cxLrcShow / 2 - fLastTime * m_LrcHScrollInfo.cx1 / p->fDelay;
                    if (ii != iLastx1)
                    {
                        iLastx1 = m_LrcHScrollInfo.x1 = ii;
                        bRedraw = TRUE;
                    }
                }
                else
                {
                    ii = m_cxLrcShow - m_LrcHScrollInfo.cx1;
                    if (ii != iLastx1)
                    {
                        iLastx1 = m_LrcHScrollInfo.x1 = ii;
                        bRedraw = TRUE;
                    }
                }
            }
            else
            {
                if (iLastx1 != 0)
                {
                    iLastx1 = m_LrcHScrollInfo.x1 = 0;
                    bRedraw = TRUE;
                }
            }
        }

        if (m_LrcHScrollInfo.cx2 != -1)
        {
            if (fLastTime > m_LrcHScrollInfo.fNoScrollingTime2)
            {
                if (fLastTime < p->fDelay - m_LrcHScrollInfo.fNoScrollingTime2)
                {
                    ii = m_cxLrcShow / 2 - fLastTime * m_LrcHScrollInfo.cx2 / p->fDelay;
                    if (ii != iLastx2)
                    {
                        iLastx2 = m_LrcHScrollInfo.x2 = ii;
                        bRedraw = TRUE;
                    }
                }
                else
                {
                    ii = m_cxLrcShow - m_LrcHScrollInfo.cx2;
                    if (ii != iLastx2)
                    {
                        iLastx2 = m_LrcHScrollInfo.x2 = ii;
                        bRedraw = TRUE;
                    }
                }
            }
            else
            {
                if (iLastx2 != 0)
                {
                    iLastx2 = m_LrcHScrollInfo.x2 = 0;
                    bRedraw = TRUE;
                }
            }
        }

        if(bRedraw)
            Lrc_DrawItem(g_iCurrLrcIndex, -1, 0, TRUE, TRUE);
    }
    return;
    case IDT_ANIMATION2:
    {
		if (m_iLrcSBPos != -1 || m_iLrcCenter == -1)
		{
			m_IsDraw[2] = TRUE;
			TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
			KillTimer(g_hMainWnd, IDT_ANIMATION2);
			return;
		}
		////////////////////////////////////////////////画中间文本
		int iTop;
		static int iLastTop = 0x80000000;
		float fLastTime = g_fTime - m_LrcVScrollInfo.fTime;
        if (m_LrcVScrollInfo.bDirection)
        {
            iTop = m_LrcVScrollInfo.iSrcTop - fLastTime * m_LrcVScrollInfo.iDistance / m_LrcVScrollInfo.fDelay;
            if (iTop <= m_LrcVScrollInfo.iDestTop)
            {
                m_IsDraw[2] = TRUE;
                TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
                KillTimer(g_hMainWnd, IDT_ANIMATION2);
                return;
            }
            else if (iTop != iLastTop)
            {
                iLastTop = iTop;
            }
            else
                return;
		}
		else
        {
            iTop = m_LrcVScrollInfo.iSrcTop + fLastTime * m_LrcVScrollInfo.iDistance / m_LrcVScrollInfo.fDelay;
            if (iTop >= m_LrcVScrollInfo.iDestTop)
            {
                m_IsDraw[2] = TRUE;
                TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
                KillTimer(g_hMainWnd, IDT_ANIMATION2);
                return;
            }
            else if (iTop != iLastTop)
            {
                iLastTop = iTop;
            }
            else
                return;
        }

        BitBlt(m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
            m_hcdcLeftBK, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);// 清除
        HRGN hLrcShowRgn = CreateRectRgnIndirect(&m_rcLrcShow);
        SelectClipRgn(m_hcdcLeftBK2, hLrcShowRgn);//设置剪辑区
        DeleteObject(hLrcShowRgn);
        int iHeight = Lrc_DrawItem(m_iLrcCenter, iTop, TRUE, FALSE, FALSE);
        int iBottom = iTop - DPIS_LRCSHOWGAP;
        iTop += (DPIS_LRCSHOWGAP + iHeight);
        int i = m_iLrcCenter;
        ////////////////////////////////////////////////向上画
        while (iBottom > m_rcLrcShow.top)
        {
            if (i - 1 < 0)
                break;
            --i;
            iHeight = Lrc_DrawItem(i, iBottom, FALSE, FALSE, FALSE);
            iBottom -= (DPIS_LRCSHOWGAP + iHeight);
        }
        i = m_iLrcCenter;
        ////////////////////////////////////////////////向下画
        while (iTop < m_rcLrcShow.bottom)
        {
            if (i + 1 >= g_Lrc->iCount)
                break;
            ++i;
            iHeight = Lrc_DrawItem(i, iTop, TRUE, FALSE, FALSE);
            iTop += (DPIS_LRCSHOWGAP + iHeight);
        }
        SelectClipRgn(m_hcdcLeftBK2, NULL);//清除剪辑区
        HDC hDC = GetDC(g_hBKLeft);
        hLrcShowRgn = CreateRectRgnIndirect(&m_rcLrcShow);
        SelectClipRgn(hDC, hLrcShowRgn);//设置剪辑区
        DeleteObject(hLrcShowRgn);
        BitBlt(hDC, m_rcLrcShow.left, m_rcLrcShow.top, m_rcLrcShow.right - m_rcLrcShow.left, m_rcLrcShow.bottom - m_rcLrcShow.top,
            m_hcdcLeftBK2, m_rcLrcShow.left, m_rcLrcShow.top, SRCCOPY);// 显示
        ReleaseDC(g_hBKLeft, hDC);
    }
    return;
    }
}
INT_PTR CALLBACK DlgProc_About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HBITMAP hBitmap;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        hBitmap = (HBITMAP)LoadImageW(g_hInst, MAKEINTRESOURCEW(IDB_ABOUT), IMAGE_BITMAP, 0, 0, 0);
        BITMAP bmp;
        GetObjectW(hBitmap, sizeof(bmp), &bmp);

        RECT rcClient, rcWnd;
        GetWindowRect(hDlg, &rcWnd);
        GetClientRect(hDlg, &rcClient);
        int cx = bmp.bmWidth + rcWnd.right - rcWnd.left - rcClient.right,
            cy = bmp.bmHeight + rcWnd.bottom - rcWnd.top - rcClient.bottom + 50;

        SetWindowPos(hDlg, NULL,
            (GetSystemMetrics(SM_CXSCREEN) - cx) / 2,
            (GetSystemMetrics(SM_CYSCREEN) - cy) / 2,
            cx,
            cy,
            SWP_NOZORDER);
        HWND hStatic = GetDlgItem(hDlg, IDC_ST_ABOUT);
        SetWindowPos(hStatic, NULL, 0, 0, bmp.bmWidth, bmp.bmHeight, SWP_NOZORDER);

        SetWindowLongPtrW(hStatic, GWL_STYLE, GetWindowLongPtrW(hStatic, GWL_STYLE) | SS_BITMAP);
        SendMessageW(hStatic, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hBitmap);

        GetClientRect(GetDlgItem(hDlg, IDC_BT_OK), &rcClient);
        SetWindowPos(GetDlgItem(hDlg, IDC_BT_OK), NULL,
            (bmp.bmWidth - rcClient.right) / 2,
            bmp.bmHeight,
            rcClient.right, 50, SWP_NOZORDER | SWP_NOSIZE);
    }
    return FALSE;
    case WM_CLOSE:
    {
        DeleteObject(hBitmap);
        EndDialog(hDlg, NULL);
    }
    return TRUE;
    case WM_COMMAND:
    {
        if (LOWORD(wParam) == IDC_BT_OK)
        {
            EndDialog(hDlg, NULL);
            return TRUE;
        }
    }
    return FALSE;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hDC = BeginPaint(hDlg, &ps);
        FillRect(hDC, &(ps.rcPaint), (HBRUSH)GetStockObject(WHITE_BRUSH));
        EndPaint(hDlg, &ps);
    }
    return TRUE;
    }
    return FALSE;
}
/*
 * 目标：更新左侧内存位图并显示
 *
 * 参数：
 *
 * 返回值：
 * 操作简述：
 * 备注：ＧＤＩＰＬＵＳ
 */
void UpdateLeftBK()
{
    GpGraphics* pGdipGraphic;
    GpGraphics* pGdipGraphic2;
    GpBitmap* pGdipBitmap = m_CurrSongInfo.mi.pGdipImage;
    GpBitmap* pGdipBitmapBlur = NULL;
    GpEffect* pGdipEffect;

    if (m_cxLeftBK <= 0 || m_cyLeftBK <= 0)
        return;
    UINT cx, cy;
    float cxRgn, cyRgn;
    RectF rcF;
    SelectClipRgn(m_hcdcLeftBK, NULL);
    GdipCreateFromHDC(m_hcdcLeftBK, &pGdipGraphic);
    if (pGdipBitmap)
    {
        /*
        情况一，内存位图宽为最大边
        cxClient   cyClient
        -------- = --------
         cxPic      cyRgn
        情况二，内存位图高为最大边
        cyClient   cxClient
        -------- = --------
         cyPic      cxRgn
        */
        ////////////////////处理截取（无论怎么改变窗口大小，用来模糊的封面图都要居中充满整个窗口）
        GdipGetImageWidth(pGdipBitmap, &cx);
        GdipGetImageHeight(pGdipBitmap, &cy);
        cyRgn = (float)m_cyLeftBK / (float)m_cxLeftBK * (float)cx;
        if (cyRgn <= cy)// 情况一
        {
            rcF.Left = 0;
            rcF.Top = ((float)cy - cyRgn) / 2;
            rcF.Width = (float)cx;
            rcF.Height = cyRgn;
        }
        else// 情况二
        {
            cxRgn = (float)m_cxLeftBK / (float)m_cyLeftBK * (float)cy;
            rcF.Left = ((float)cx - cxRgn) / 2;
            rcF.Top = 0;
            rcF.Width = cxRgn;
            rcF.Height = (float)cy;
        }
        ////////////////////创建       
        GdipCreateBitmapFromScan0(m_cxLeftBK, m_cyLeftBK, 0, PixelFormat32bppRGB, NULL, &pGdipBitmapBlur);//创建模糊背景图
        GdipGetImageGraphicsContext(pGdipBitmapBlur, &pGdipGraphic2);
        ////////////////////准备原图
        GdipDrawImageRectRect(
            pGdipGraphic2, pGdipBitmap,
            0, 0, (float)m_cxLeftBK, (float)m_cyLeftBK,
            rcF.Left, rcF.Top, rcF.Width, rcF.Height,
            UnitPixel, NULL, NULL, NULL);
        GdipDeleteGraphics(pGdipGraphic2);
        ////////////////////置模糊效果
        // {633C80A4-1843-482b-9EF2-BE2834C5FDD4}
        const static GUID BlurEffectGuid = { 0x633c80a4, 0x1843, 0x482b, { 0x9e, 0xf2, 0xbe, 0x28, 0x34, 0xc5, 0xfd, 0xd4 } };
        GdipCreateEffect(BlurEffectGuid, &pGdipEffect);
        BlurParams bp;
        bp.radius = 100;// 模糊半径
        bp.expandEdge = FALSE;
        GdipSetEffectParameters(pGdipEffect, &bp, sizeof(BlurParams));
        GdipBitmapApplyEffect(pGdipBitmapBlur, pGdipEffect, NULL, FALSE, NULL, NULL);
        GdipDeleteEffect(pGdipEffect);
        ////////////////////画模糊图作为背景
        GdipDrawImageRectRect(
            pGdipGraphic, pGdipBitmapBlur,
            0, 0, (float)m_cxLeftBK, (float)m_cyLeftBK,
            0, 0, (float)m_cxLeftBK, (float)m_cyLeftBK,
            UnitPixel, NULL, NULL, NULL);
        GdipDisposeImage(pGdipBitmapBlur);
        ////////////////////画白色半透明遮罩
        GpBrush* pGdipBrush;
        GdipCreateSolidFill(0xB2FFFFFF, &pGdipBrush);// 0xB2==178   70%透明度
        GdipFillRectangle(pGdipGraphic, pGdipBrush, 0, 0, (float)m_cxLeftBK, (float)m_cyLeftBK);
        GdipDeleteBrush(pGdipBrush);
        ////////////////////处理封面图位置
        ////////////制封面框矩形
        if (m_bLrcShow)// 是否显示歌词秀？
        {
            cxRgn = DPIS_CXPIC + DPIS_EDGE * 2;
            cyRgn = cxRgn;
        }
        else
        {
            cxRgn = (float)m_cxLeftBK;
            cyRgn = (float)(m_cyLeftBK - DPIS_CYPROGBAR - DPIS_BT - DPIS_CYSPE - DPIS_CYTOPBK);
        }

        if (cxRgn >= cyRgn)// 高度较小
        {
            rcF.Height = cyRgn - DPIS_EDGE * 2;
            rcF.Width = rcF.Height;
            rcF.Top = DPIS_EDGE + DPIS_CYTOPBK;
            rcF.Left = (cxRgn - rcF.Width) / 2;
        }
        else// 宽度较小
        {
            rcF.Width = cxRgn - DPIS_EDGE * 2;
            rcF.Height = rcF.Width;
            rcF.Left = DPIS_EDGE;
            rcF.Top = (cyRgn - rcF.Height) / 2 + DPIS_CYTOPBK;
        }
        ////////////////////绘制封面图
        ////////////比例缩放
        float f;
        if (cx >= cy)// 高度较小
        {
            f = rcF.Width / cx * cy;// 缩放到封面框中，要保证 水平 方向显示完全 高度 要多大？
            rcF.Top = rcF.Top + (rcF.Height - f) / 2;// 偏移
            rcF.Height = f;
        }
        else// 宽度较小
        {
            f = rcF.Height / cy * cx;// 缩放到封面框中，要保证 垂直 方向显示完全 宽度 要多大？
            rcF.Left = rcF.Left + (rcF.Width - f) / 2;// 偏移
            rcF.Width = f;
        }
        GdipDrawImageRectRect(pGdipGraphic, pGdipBitmap,
            rcF.Left,
            rcF.Top,
            rcF.Width,
            rcF.Height,
            0,
            0,
            (float)cx,
            (float)cy,
            UnitPixel, NULL, NULL, NULL);
    }
    else// 没有图就全刷白吧
    {
        GpBrush* pGdipBrush;
        GdipCreateSolidFill(0xFFFFFFFF, &pGdipBrush);
        GdipFillRectangle(pGdipGraphic, pGdipBrush, 0, 0, (float)m_cxLeftBK, (float)m_cyLeftBK);
        GdipDeleteBrush(pGdipBrush);
    }
    GdipDeleteGraphics(pGdipGraphic);
    ////////////////////画顶部提示信息
    ///////////画大标题
    SetTextColor(m_hcdcLeftBK, QKCOLOR_CYANDEEPER);
    RECT rcText = { DPIS_EDGE, 5, m_cxLeftBK - DPIS_EDGE, DPIS_CYTOPTITLE };
    if (!m_CurrSongInfo.pszFile)
        DrawTextW(m_hcdcLeftBK, L"未播放", -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);
    else
        DrawTextW(m_hcdcLeftBK, m_CurrSongInfo.pszFile, -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);
    ///////////画其他信息
    SelectObject(m_hcdcLeftBK, g_hFont);// 切换字体
    SetTextColor(m_hcdcLeftBK, QKCOLOR_BLACK);

    rcText.left = DPIS_EDGE;
    rcText.top = DPIS_CYTOPTITLE + DPIS_GAPTOPTIP;
    rcText.right = rcText.left + DPIS_CXTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, L"标题：", -1, &rcText, DT_VCENTER | DT_SINGLELINE);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, L"艺术家：", -1, &rcText, DT_VCENTER | DT_SINGLELINE);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, L"专辑：", -1, &rcText, DT_VCENTER | DT_SINGLELINE);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, L"备注：", -1, &rcText, DT_VCENTER | DT_SINGLELINE);

    rcText.left = DPIS_CXTOPTIP + DPIS_EDGE;
    rcText.right = m_cxLeftBK - DPIS_EDGE;
    rcText.top = DPIS_CYTOPTITLE + DPIS_GAPTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, m_CurrSongInfo.mi.pszTitle, -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, m_CurrSongInfo.mi.pszArtist, -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, m_CurrSongInfo.mi.pszAlbum, -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    rcText.top += DPIS_CYTOPTIP;
    rcText.bottom = rcText.top + DPIS_CYTOPTIP;
    DrawTextW(m_hcdcLeftBK, m_CurrSongInfo.mi.pszComment, -1, &rcText, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX);

    SelectObject(m_hcdcLeftBK, m_hFontDrawing);

    BitBlt(m_hcdcLeftBK2, 0, 0, m_cxLeftBK, m_cyLeftBK, m_hcdcLeftBK, 0, 0, SRCCOPY);
    m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = TRUE;
    TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
    TimerProc(NULL, 0, IDT_DRAWING_SPE, 0);
    TimerProc(NULL, 0, IDT_DRAWING_WAVES, 0);
    InvalidateRect(g_hTBProgess, NULL, FALSE);
    UpdateWindow(g_hTBProgess);
    InvalidateRect(g_hBKBtm, NULL, FALSE);
    UpdateWindow(g_hBKBtm);
    SendMessageW(g_hBKLeft, LEFTBKM_REDRAWSB, FALSE, 0);
    InvalidateRect(g_hBKLeft, NULL, FALSE);
    UpdateWindow(g_hBKLeft);
}
LRESULT CALLBACK QKC_TB_PaintProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)//滑块条绘制过程
{
    if (iMsg == QKCTBN_PAINT)
    {
        QKCTBPAINT* Pnt = (QKCTBPAINT*)lParam;
        RECT rc;
        int cxClient, cyClient;
        GetWindowRect(hWnd, &rc);
        cxClient = rc.right - rc.left;
        cyClient = rc.bottom - rc.top;
        ScreenToClient(g_hBKLeft, (LPPOINT)&rc);
        ScreenToClient(g_hBKLeft, (LPPOINT)&rc + 1);
        BitBlt(Pnt->hDC, 0, 0, cxClient, cyClient, m_hcdcLeftBK2, rc.left, rc.top, SRCCOPY);//画背景
        rc.left = 6;
        rc.top = Pnt->rcClient->bottom / 2 - 2;
        rc.right = Pnt->rcClient->right - 6;
        rc.bottom = rc.top + 4;
        HBRUSH hBrush = CreateSolidBrush(MYCLR_TBTRACK);
        FillRect(Pnt->hDC, &rc, hBrush);
        DeleteObject(hBrush);

        if (Pnt->byPressed == 1)
            hBrush = CreateSolidBrush(MYCLR_BTPUSHED);
        else
            hBrush = CreateSolidBrush(MYCLR_BTHOT);
        FillRect(Pnt->hDC, Pnt->rc, hBrush);
        DeleteObject(hBrush);
    }
    return 0;
}
void UI_SetRitCtrlPos()
{
    SetWindowPos(GetDlgItem(g_hBKRight, IDC_ST_LISTNAME), NULL, 0, 0,
		m_cxLV - DPIS_GAP,
        DPIS_CYSTLISTNAME,
        SWP_NOZORDER | SWP_NOMOVE);

    HWND hEdit = GetDlgItem(g_hBKRight, IDC_ED_SEARCH);
    SetWindowPos(hEdit, NULL, 0, 0,
        m_cxLV - DPIS_BT - DPIS_GAP,
        DPIS_BT,
        SWP_NOZORDER | SWP_NOMOVE);
    RECT rcText;
    SendMessageW(hEdit, EM_GETRECT, 0, (LPARAM)&rcText);
    rcText.left = DPIS_GAP;
    rcText.right = m_cxLV - DPIS_BT - DPIS_GAP * 2;
    OffsetRect(&rcText, 0, (DPIS_BT - (rcText.bottom - rcText.top)) / 2 - rcText.top);
    SendMessageW(hEdit, EM_SETRECT, 0, (LPARAM)&rcText);

    SetWindowPos(GetDlgItem(g_hBKRight, IDC_BT_SEARCH), NULL,
        m_cxLV - DPIS_BT - DPIS_GAP,
        DPIS_CYSTLISTNAME + DPIS_GAP * 2,
        0, 0, SWP_NOZORDER | SWP_NOSIZE);
}
void UI_SeparateListWnd(BOOL b)
{
	static ULONG_PTR uCommStyle = WS_VISIBLE | WS_CLIPCHILDREN;
    RECT rc;
	if (b)
	{
		if (g_bListSeped)
			return;
        SetWindowLongPtrW(g_hBKList, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_POPUP | uCommStyle);
		SetParent(g_hBKList, NULL);
		ShowWindow(g_hSEB, SW_HIDE);
		g_bListSeped = TRUE;

        GetClientRect(g_hBKList, &rc);
        SendMessageW(g_hBKList, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
	}
	else
	{
		if (!g_bListSeped)
			return;
		SetParent(g_hBKList, g_hMainWnd);
		SetWindowLongPtrW(g_hBKList, GWL_STYLE, WS_CHILD | uCommStyle);
		if (!g_bListHidden)
			ShowWindow(g_hSEB, SW_SHOWNOACTIVATE);
		g_bListSeped = FALSE;
	}
	GetClientRect(g_hMainWnd, &rc);
	SendMessageW(g_hMainWnd, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
}
void UI_ShowList(BOOL b)
{
    RECT rc;
    if (b)
    {
		if (!g_bListHidden)
			return;
		ShowWindow(g_hBKList, SW_SHOWNOACTIVATE);
		if (!g_bListSeped)
			ShowWindow(g_hSEB, SW_SHOWNOACTIVATE);
		g_bListHidden = FALSE;
	}
	else
	{
        if (g_bListHidden)
            return;
        ShowWindow(g_hBKList, SW_HIDE);
        ShowWindow(g_hSEB, SW_HIDE);
        g_bListHidden = TRUE;
    }
    GetClientRect(g_hMainWnd, &rc);
    SendMessageW(g_hMainWnd, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
}
LRESULT CALLBACK QKCProc_SEB(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == QKCSEPN_DRAGEND)
    {
        RECT rc;
        GetClientRect(g_hMainWnd, &rc);
        m_cxLV = rc.right - wParam - DPIS_GAP;
        UI_SetRitCtrlPos();
        SendMessageW(g_hMainWnd, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
    }
    return 0;
}
LRESULT CALLBACK WndProc_Edit(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_KEYDOWN:
    {
        if (wParam == VK_RETURN)//按回车键
            SendMessageW(g_hBKRight, WM_COMMAND, MAKELONG(IDC_BT_SEARCH, 0), (LPARAM)GetDlgItem(g_hBKRight, IDC_BT_SEARCH));
    }
    }

    return CallWindowProcW((WNDPROC)GetPropW(hWnd, PROP_WNDPROC), hWnd, message, wParam, lParam);
}
LRESULT CALLBACK WndProc_ListView(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int iLastHoverItem = -1;
    int iCurrItem = -1;
    LRESULT lRet = CallWindowProcW((WNDPROC)GetPropW(hWnd, PROP_WNDPROC), hWnd, message, wParam, lParam);

    switch (message)
    {
    case WM_LBUTTONDOWN:// 啊啊啊我没办法了，不这么写从别的控件点过来的时候LV不会获得焦点，WM_KEYDOWN也就不会发给LV......
        SetFocus(hWnd);
        break;
    case WM_KEYDOWN:
    {
        if (wParam == VK_RETURN)// 按回车键播放曲目
        {
            int iCount = QKArray_GetCount(g_ItemData);
            int i;
            for (i = 0; i < iCount; ++i)
            {
                if (SendMessageW(hWnd, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
                    break;
            }

            if (i != iCount)
                PlayFile(i);
        }
        else if (wParam == 0x41)// A键按下
        {
            if (GetKeyState(VK_CONTROL) & 0x80000000)// Ctrl + A 全选
            {
                LVITEMW li;
                li.stateMask = LVIS_SELECTED;
                li.state = LVIS_SELECTED;
                SendMessageW(hWnd, LVM_SETITEMSTATE, -1, (LPARAM)&li);// wParam = -1：应用于所有项目
            }
        }
    }
    break;
    }
    return lRet;
}
void UI_UpdateDPISize()
{
	GC.DS_CYPROGBAR = DPI(SIZE_CYPROGBAR);
	GC.DS_CYBTBK = DPI(SIZE_CYBTBK);
	GC.DS_CYSPE = DPI(SIZE_CYSPE);
	GC.DS_CYSPEHALF = DPI(SIZE_CYSPEHALF);
	GC.DS_CXSPEBAR = DPI(SIZE_CXSPEBAR);
	GC.DS_CXSPEBARDIV = DPI(SIZE_CXSPEBARDIV);
	GC.DS_CXSPE = DPI(SIZE_CXSPE);
	GC.DS_CXSPEHALF = DPI(SIZE_CXSPEHALF);
	GC.DS_CXBTMBTBK = DPI(SIZE_CXBTMBTBK);
	GC.DS_CXPIC = DPI(SIZE_CXPIC);
	GC.DS_EDGE = DPI(SIZE_EDGE);
	GC.DS_CYTOPBK = DPI(SIZE_CYTOPBK);
	GC.DS_BT = DPI(SIZE_BT);
	GC.DS_CXRITBT = DPI(SIZE_CXRITBT);
	GC.DS_GAP = DPI(SIZE_GAP);
	GC.DS_LARGEIMAGE = DPI(SIZE_LARGEIMAGE);
	GC.DS_CYRITBK = DPI(SIZE_CYRITBK);
	GC.DS_CYSTLISTNAME = DPI(SIZE_CYSTLISTNAME);
	GC.DS_CXTIME = DPI(SIZE_CXTIME);
	GC.DS_CXWAVESLINE = DPI(SIZE_CXWAVESLINE);
	GC.DS_CYTOPTITLE = DPI(SIZE_CYTOPTITLE);
	GC.DS_CXTOPTIP = DPI(SIZE_CXTOPTIP);
	GC.DS_CYTOPTIP = DPI(SIZE_CYTOPTIP);
	GC.DS_GAPTOPTIP = DPI(SIZE_GAPTOPTIP);
	GC.DS_CXABOUTPIC = DPI(SIZE_CXABOUTPIC);
	GC.DS_CYABOUTPIC = DPI(SIZE_CYABOUTPIC);
	GC.DS_LVTEXTSPACE = DPI(SIZE_LVTEXTSPACE);
	GC.DS_CXLRCTB = DPI(SIZE_CXLRCTB);
	GC.DS_DEFCXLV = DPI(SIZE_DEFCXLV);
    GC.DS_DTLRCEDGE = DPI(SIZE_DTLRCEDGE);
    GC.DS_DTLRCFRAME = DPI(SIZE_DTLRCFRAME);
    GC.DS_STDICON = DPI(SIZE_STDICON);
    GC.DS_CXDTLRCBTNRGN = DPIS_DTLRCEDGE * 3 + DPIS_BT * 4;
    GC.DS_CYLVITEM = DPI(SIZE_CYLVITEM);
    GC.DS_LRCSHOWGAP = DPI(SIZE_LRCSHOWGAP);
    GC.DS_CXDRAGDROPICON = DPI(SIZE_CXDRAGDROPICON);
    GC.DS_CYDRAGDROPICON = DPI(SIZE_CYDRAGDROPICON);
}
void GlobalEffect_ResetToDefault(int i)
{
    if (i & EFFECT_CHORUS)
    {
        m_GlobalEffect.Chorus =
        {
            50.0f,
            10.0f,
            25.0f,
            1.1f,
            1,
            16.0f,
            BASS_DX8_PHASE_90
        };
    }

    if (i & EFFECT_COMPRESSOR)
    {
        m_GlobalEffect.Compressor =
        {
            0.0f,
            10.0f,
            200.0f,
            -20.0f,
            3.0f,
            4.0f
        };
    }

    if (i & EFFECT_DISTORTION)
    {
        m_GlobalEffect.Distortion =
        {
            -18.0f,
            15.0f,
            2400.0f,
            2400.0f,
            8000.0f
        };
    }

    if (i & EFFECT_ECHO)
    {
        m_GlobalEffect.Echo =
        {
            50.0f,
            50.0f,
            500.0f,
            500.0f,
            FALSE
        };
    }

    if (i & EFFECT_FLANGER)
    {
        m_GlobalEffect.Flanger =
        {
            50.0f,
            100.0f,
            -50.0f,
            0.25f,
            1,
            2.0f,
            BASS_DX8_PHASE_ZERO
        };
    }

    if (i & EFFECT_GARGLE)
    {
        m_GlobalEffect.Gargle =
        {
            20,
            0
        };
    }

    if (i & EFFECT_I3DL2REVERB)
    {
        m_GlobalEffect.I3DL2Reverb =
        {
            -1000,
            -100,
            0.0f,
            1.49f,
            0.83f,
            -2602,
            0.007f,
            200,
            0.011f,
            100.0f,
            100.0f,
            5000.0f
        };
    }

    if (i & EFFECT_REVERB)
    {
        m_GlobalEffect.Reverb =
        {
            0.0f,
            0.0f,
            1000.0f,
            0.001f
        };
    }

    if (i & EFFECT_EQ)
    {
        for (int i = 0; i < 10; ++i)
        {
            m_GlobalEffect.EQ[i].fCenter = c_EQCenter[i];
            m_GlobalEffect.EQ[i].fBandwidth = 12;
            m_GlobalEffect.EQ[i].fGain = 0;
        }
    }
}
HRESULT CALLBACK OLEDrag_GiveFeedBack(DWORD dwEffect)
{
    return DRAGDROP_S_USEDEFAULTCURSORS;// 使用默认光标
}
HRESULT CALLBACK OLEDrop_OnEnter(IDataObject* pDataObj, DWORD grfKeyState, POINTL pt, DWORD* pdwEffect)
{
    SetPropW(g_hLV, PROP_OLEDROPLASTINDEX, (HANDLE)-1);
    SetPropW(g_hLV, PROP_OLEDROPTARGETINDEX, (HANDLE)g_ItemData->iCount);

    FORMATETC fe =
    {
        CF_HDROP,
        NULL,
        DVASPECT_CONTENT,
        -1,
        TYMED_HGLOBAL
    };

    if (SUCCEEDED(pDataObj->QueryGetData(&fe)))
    {
        SetPropW(g_hLV, PROP_OLEDROPINVALID, (HANDLE)FALSE);
        *pdwEffect = DROPEFFECT_COPY;
    }
    else
    {
        SetPropW(g_hLV, PROP_OLEDROPINVALID, (HANDLE)TRUE);
        *pdwEffect = DROPEFFECT_NONE;
    }
    return S_OK;
}
HRESULT CALLBACK OLEDrop_OnOver(DWORD grfKeyState, POINTL pt, DWORD* pdwEffect)
{
    if (GetPropW(g_hLV, PROP_OLEDROPINVALID))
        return S_OK;

    RECT rcLV;
    GetClientRect(g_hLV, &rcLV);
    POINT pti = { pt.x,pt.y };
	ScreenToClient(g_hLV, &pti);
	if (PtInRect(&rcLV, pti))
	{
		LVHITTESTINFO lhti;
		lhti.pt = { 0,pti.y };
		int iIndex = SendMessageW(g_hLV, LVM_HITTEST, 0, (LPARAM)&lhti);
        RECT rcItem;
        LVINSERTMARK lim = { 0 };
        if (iIndex != -1)
        {
            rcItem.left = LVIR_BOUNDS;
            SendMessageW(g_hLV, LVM_GETITEMRECT, iIndex, (LPARAM)&rcItem);
			if (pti.y > rcItem.top + (rcItem.bottom - rcItem.top) / 2)
			{
				++iIndex;
				if (iIndex >= g_ItemData->iCount)
				{
					iIndex = g_ItemData->iCount;
					lim.dwFlags = LVIM_AFTER;
				}
			}
		}
		else if (lhti.flags & LVHT_NOWHERE)
		{
			iIndex = g_ItemData->iCount;
			lim.dwFlags = LVIM_AFTER;
		}

		if ((int)GetPropW(g_hLV, PROP_OLEDROPLASTINDEX) != iIndex)
		{
			SetPropW(g_hLV, PROP_OLEDROPLASTINDEX, (HANDLE)iIndex);
            SetPropW(g_hLV, PROP_OLEDROPTARGETINDEX, (HANDLE)iIndex);
			lim.cbSize = sizeof(LVINSERTMARK);
            if (lim.dwFlags == LVIM_AFTER)
                --iIndex;
			lim.iItem = iIndex;
			SendMessageW(g_hLV, LVM_SETINSERTMARK, 0, (LPARAM)&lim);
		}
	}
	else
	{
        if ((int)GetPropW(g_hLV, PROP_OLEDROPLASTINDEX) != -1)
        {
            SetPropW(g_hLV, PROP_OLEDROPLASTINDEX, (HANDLE)-1);
            SetPropW(g_hLV, PROP_OLEDROPTARGETINDEX, (HANDLE)g_ItemData->iCount);
            LVINSERTMARK lim = { 0 };
            lim.cbSize = sizeof(LVINSERTMARK);
            lim.iItem = -1;
            SendMessageW(g_hLV, LVM_SETINSERTMARK, 0, (LPARAM)&lim);
        }
	}
	return S_OK;
}
HRESULT CALLBACK OLEDrop_OnLeave()
{
    RemovePropW(g_hLV, PROP_OLEDROPLASTINDEX);
    RemovePropW(g_hLV, PROP_OLEDROPTARGETINDEX);
    RemovePropW(g_hLV, PROP_OLEDROPINVALID);
    LVINSERTMARK lim = { 0 };
    lim.cbSize = sizeof(LVINSERTMARK);
    lim.iItem = -1;
    SendMessageW(g_hLV, LVM_SETINSERTMARK, 0, (LPARAM)&lim);
    return S_OK;
}
HRESULT CALLBACK OLEDrop_OnDrop(IDataObject* pDataObj, DWORD grfKeyState, POINTL pt, DWORD* pdwEffect)
{
    BOOL b = (BOOL)GetPropW(g_hLV, PROP_OLEDROPINVALID);

    int iTargetIndex = (int)GetPropW(g_hLV, PROP_OLEDROPTARGETINDEX);
    RemovePropW(g_hLV, PROP_OLEDROPLASTINDEX);
    RemovePropW(g_hLV, PROP_OLEDROPTARGETINDEX);
    RemovePropW(g_hLV, PROP_OLEDROPINVALID);
    if (b)
        return S_OK;

    LVINSERTMARK lim = { 0 };
    lim.cbSize = sizeof(LVINSERTMARK);
    lim.iItem = -1;
    SendMessageW(g_hLV, LVM_SETINSERTMARK, 0, (LPARAM)&lim);

    FORMATETC fe =
    {
        g_uMyClipBoardFmt,
        NULL,
        DVASPECT_CONTENT,
        -1,
        TYMED_HGLOBAL
    };

    STGMEDIUM sm = { 0 };
    sm.tymed = TYMED_HGLOBAL;
    sm.pUnkForRelease = NULL;

    if (SUCCEEDED(pDataObj->GetData(&fe, &sm)))// 判断有没有自定义拖放信息
	{
        List_SetRedraw(FALSE);
        int* p = (int*)GlobalLock(sm.hGlobal);
        int iCount = *p;
        ++p;
		int m = 0, n = 0;
        int iIndex;
		for (int i = 0; i < iCount; ++i)
		{
			iIndex = *p;
			if (iIndex >= iTargetIndex)
			{
				QKArray_Insert(&g_ItemData, QKArray_Get(g_ItemData, iIndex), iTargetIndex + m);
				QKArray_DeleteMember(&g_ItemData, iIndex + 1);
				++m;
			}
			else
			{
				iIndex -= n;
				QKArray_Insert(&g_ItemData, QKArray_Get(g_ItemData, iIndex), iTargetIndex);
				QKArray_DeleteMember(&g_ItemData, iIndex);
				++n;
			}
            ++p;
		}
		LVITEMW li;
		li.stateMask = LVIS_SELECTED;
		li.state = 0;
		SendMessageW(g_hLV, LVM_SETITEMSTATE, -1, (LPARAM)&li);// 清除选中；wParam = -1：应用于所有项目
		li.state = LVIS_SELECTED;

        iTargetIndex -= n;
        for (int i = 0; i < iCount; ++i)
        {
            SendMessageW(g_hLV, LVM_SETITEMSTATE, iTargetIndex + i, (LPARAM)&li);// 选中新移动的项
        }

        for (int i = 0; i < g_ItemData->iCount; ++i)// 捏麻麻地算这算那的劳资脑子不够用了，直接用个简单粗暴的方法还原现行播放索引
        {
            if (((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->dwFlags & QKLIF_DRAGMARK_CURRFILE)
            {
                g_iCurrFileIndex = i;
                ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->dwFlags &= ~QKLIF_DRAGMARK_CURRFILE;
                break;
            }
        }
        GlobalUnlock(sm.hGlobal);
        List_SetRedraw(TRUE);
        List_Redraw();
        ReleaseStgMedium(&sm);
    }
    else// 仅拖放文件
	{
		fe.cfFormat = CF_HDROP;
		if (FAILED(pDataObj->GetData(&fe, &sm)))// 取回HDROP
			return S_OK;
		HDROP hDrop = (HDROP)sm.hGlobal;
		int iFileCount = DragQueryFileW(hDrop, 0xFFFFFFFF, NULL, 0);// 取拖放文件总数，(int)0xFFFFFFFF == -1
		UINT iBufferSize;
		LPWSTR pszFile;
		for (int i = 0; i < iFileCount; i++)
        {
            iBufferSize = DragQueryFileW(hDrop, i, NULL, 0);// 取缓冲区大小
            pszFile = new WCHAR[iBufferSize + 1];
            DragQueryFileW(hDrop, i, pszFile, iBufferSize + 1);// 查询文件名
            List_Add(pszFile, NULL, iTargetIndex, FALSE);
            delete[] pszFile;
            ++iTargetIndex;
        }
        List_ResetLV();
        ReleaseStgMedium(&sm);
    }
    return S_OK;
}
LRESULT CALLBACK WndProc_TBGhost(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
    {
        ChangeWindowMessageFilter(WM_DWMSENDICONICTHUMBNAIL, MSGFLT_ADD);
        ChangeWindowMessageFilter(WM_DWMSENDICONICLIVEPREVIEWBITMAP, MSGFLT_ADD);
        BOOL b = TRUE;
        DwmSetWindowAttribute(hWnd, DWMWA_HAS_ICONIC_BITMAP, &b, sizeof(BOOL));
        DwmSetWindowAttribute(hWnd, DWMWA_FORCE_ICONIC_REPRESENTATION, &b, sizeof(b));
    }
    return 0;
    case WM_DWMSENDICONICTHUMBNAIL:
    {
        if (!m_CurrSongInfo.mi.pGdipImage)
            return 0;
        HBITMAP hBitmap;
        UINT cx0, cy0, cx, cy, cxMax = HIWORD(lParam), cyMax = LOWORD(lParam);
        GdipGetImageWidth(m_CurrSongInfo.mi.pGdipImage, &cx0);
        GdipGetImageHeight(m_CurrSongInfo.mi.pGdipImage, &cy0);

        if ((float)cxMax / (float)cyMax > (float)cx0 / (float)cy0)// y对齐
        {
            cy = cyMax;
            cx = cx0 * cy / cy0;
        }
        else// x对齐
        {
            cx = cxMax;
            cy = cx * cy0 / cx0;
        }
        GpBitmap* pGdipImage;
        GpGraphics* pGdipGraphics;
        GdipCreateBitmapFromScan0(cxMax, cyMax, 0, PixelFormat32bppArgb, NULL, &pGdipImage);
        GdipGetImageGraphicsContext(pGdipImage, &pGdipGraphics);
        GdipDrawImageRectRect(pGdipGraphics, m_CurrSongInfo.mi.pGdipImage,
            (cxMax - cx) / 2, (cyMax - cy) / 2, (float)cx, (float)cy,
            0, 0, (float)cx0, (float)cy0,
            UnitPixel, NULL, NULL, NULL);
        GdipDeleteGraphics(pGdipGraphics);
        GdipCreateHBITMAPFromBitmap(pGdipImage, &hBitmap, 0x00000000);
        DwmSetIconicThumbnail(hWnd, hBitmap, 0);
        GdipDisposeImage(pGdipImage);
        DeleteObject(hBitmap);
    }
    return 0;
    case WM_DWMSENDICONICLIVEPREVIEWBITMAP:
    {
        HBITMAP hBitmap;
        GpBitmap* pGdipImage;
        GdipCreateBitmapFromScan0(1, 1, 0, PixelFormat32bppArgb, NULL, &pGdipImage);// 很小且全透明
        POINT pt = {};
        GdipCreateHBITMAPFromBitmap(pGdipImage, &hBitmap, 0x00000000);
        DwmSetIconicLivePreviewBitmap(m_hTBGhost, hBitmap, &pt, 0);
        GdipDisposeImage(pGdipImage);
        DeleteObject(hBitmap);
    }
	return 0;
    case WM_ACTIVATE:// 窗口激活，转发（就是点击缩略图激活的那个操作）
    {
        SetForegroundWindow(g_hMainWnd);
        if (!g_pITaskbarList)
            return 0;
        g_pITaskbarList->SetTabActive(hWnd, g_hMainWnd, 0);
    }
    return 0;
    case WM_SYSCOMMAND:// 系统菜单，转发（最大化、最小化、关闭）
        return SendMessageW(g_hMainWnd, WM_SYSCOMMAND, wParam, lParam);
    case WM_COMMAND:// 任务栏工具栏按钮点击，转发
        return SendMessageW(g_hMainWnd, WM_COMMAND, wParam, lParam);
    }
    return DefWindowProcW(hWnd, message, wParam, lParam);
}
LRESULT CALLBACK WndProc_PlayList(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HTHEME hLVTheme = NULL;
    static int cxClient, cyClient;
    static int cyVSBArrow = GetSystemMetrics(SM_CYVSCROLL);
    static int cySBTrack;
    static COLORREF CustClr[16] = { 0 };
    switch (message)
    {
    case WM_CREATE:// 狠狠地创建窗口
    {
        SetPropW(hWnd, PROP_BOOKMARKCLRDLGBUF, (HANDLE)CustClr);
        HWND hCtrl, hCtrl2;
        ///////////////////////////右部工具栏
        hCtrl2 = CreateWindowExW(0, BKWNDCLASS, NULL, WS_CHILD | WS_VISIBLE,
            0, 0, m_cxLV, DPIS_CYRITBK,
            hWnd, (HMENU)IDC_BK_RIGHTBTBK, g_hInst, NULL);
        g_hBKRight = hCtrl2;
        SetWindowLongPtrW(hCtrl2, GWLP_WNDPROC, (LONG_PTR)WndProc_RitBK);
        ///////////////////////////列表名称静态
        hCtrl = CreateWindowExW(0, WC_STATICW, NULL, WS_CHILD | WS_VISIBLE | SS_CENTERIMAGE | SS_ELLIPSISMASK,
            0, DPIS_GAP, 0, 0,
            hCtrl2, (HMENU)IDC_ST_LISTNAME, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)m_hFontDrawing, FALSE);
        SetWindowTextW(hCtrl, L"/*当前无播放列表*/");
        ///////////////////////////搜索编辑框
        hCtrl = CreateWindowExW(0, WC_EDITW, NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_WANTRETURN,
            0, DPIS_CYSTLISTNAME + DPIS_GAP * 2, 0, 0,
            hCtrl2, (HMENU)IDC_ED_SEARCH, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SetPropW(hCtrl, PROP_WNDPROC,
            (HANDLE)SetWindowLongPtrW(hCtrl, GWLP_WNDPROC, (LONG_PTR)WndProc_Edit));
        ///////////////////////////搜索按钮
        hCtrl = CreateWindowExW(0, WC_BUTTONW, NULL, WS_CHILD | WS_VISIBLE | BS_ICON,
            0, 0, DPIS_BT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_SEARCH, g_hInst, NULL);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiSearch);
        UI_SetRitCtrlPos();
        ///////////////////////////
        int iLeft = 0;
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"定位", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_JUMP, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiLocate);
        iLeft += (DPIS_CXRITBT + DPIS_GAP);
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"添加", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_OPEN, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiAdd);
        iLeft += (DPIS_CXRITBT + DPIS_GAP);
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"读取", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_LOADLIST, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiLoadList);
        iLeft += (DPIS_CXRITBT + DPIS_GAP);
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"保存", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_SAVE, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiSaveList);
        iLeft += (DPIS_CXRITBT + DPIS_GAP);
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"清空", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_EMPTY, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiEmpty);
        iLeft += (DPIS_CXRITBT + DPIS_GAP);
        ///////////////////////////
        hCtrl = CreateWindowExW(0, WC_BUTTONW, L"管理", WS_CHILD | WS_VISIBLE,
            iLeft, DPIS_CYSTLISTNAME + DPIS_GAP * 3 + DPIS_BT, DPIS_CXRITBT, DPIS_BT,
            hCtrl2, (HMENU)IDC_BT_MANAGING, g_hInst, NULL);
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiListManaging);
        ///////////////////////////播放列表
        hCtrl = CreateWindowExW(0, WC_LISTVIEWW, NULL, WS_CHILD | WS_VISIBLE | LVS_OWNERDATA | LVS_SHOWSELALWAYS,
            0, 0, 0, 0, hWnd, (HMENU)IDC_LV_PLAY, g_hInst, NULL);
        g_hLV = hCtrl;
        SendMessageW(hCtrl, WM_SETFONT, (WPARAM)g_hFont, FALSE);
        SendMessageW(hCtrl, LVM_SETVIEW, LV_VIEW_DETAILS, 0);
        UINT uExStyle = LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER;
        SendMessageW(hCtrl, LVM_SETEXTENDEDLISTVIEWSTYLE, uExStyle, uExStyle);
        LVCOLUMNW lc;
        lc.mask = LVCF_TEXT | LVCF_WIDTH;
        lc.pszText = (PWSTR)L"名称";
        lc.cx = DPI(295);
        SendMessageW(hCtrl, LVM_INSERTCOLUMNW, 0, (LPARAM)&lc);
        lc.pszText = (PWSTR)L"时长";
        lc.cx = DPI(50);
        SendMessageW(hCtrl, LVM_INSERTCOLUMNW, 1, (LPARAM)&lc);
        SetWindowTheme(hCtrl, L"Explorer", NULL);
        hLVTheme = OpenThemeData(hCtrl, L"ListView");
        SetPropW(hCtrl, PROP_WNDPROC,
            (HANDLE)SetWindowLongPtrW(hCtrl, GWLP_WNDPROC, (LONG_PTR)WndProc_ListView));
        SendMessageW(hCtrl, LVM_SETIMAGELIST, LVSIL_SMALL, (LPARAM)ImageList_Create(1, DPIS_CYLVITEM, 0, 1, 0));// ILC_COLOR缺省

    }
    return 0;
    case WM_SIZE:
    {
        cxClient = LOWORD(lParam);
        cyClient = HIWORD(lParam);

        SetWindowPos(g_hBKRight, NULL,
            0,
            0,
            cxClient - DPIS_GAP,
            DPIS_CYRITBK,
            SWP_NOZORDER);//右部按钮容器

        SetWindowPos(g_hLV, NULL,
            0,
            DPIS_CYRITBK,
			cxClient - DPIS_GAP,
            cyClient - DPIS_CYRITBK,
            SWP_NOZORDER);//列表

        cySBTrack = cyClient - DPIS_CYRITBK - 6 - cyVSBArrow * 2;
    }
    return 0;
    case WM_NOTIFY:
	{
		if (((NMHDR*)lParam)->idFrom == IDC_LV_PLAY)
		{
			switch (((NMHDR*)lParam)->code)
			{
			case NM_DBLCLK:// 双击
			{
				NMITEMACTIVATE* p = (NMITEMACTIVATE*)lParam;
				if (p->iItem != -1)
					PlayFile(p->iItem);
			}
			break;// 该通知不使用返回值
			case NM_CUSTOMDRAW://自定义绘制
			{
				NMLVCUSTOMDRAW* p = (NMLVCUSTOMDRAW*)lParam;
				switch (p->nmcd.dwDrawStage)
				{
				case CDDS_PREPAINT:
					return CDRF_NOTIFYITEMDRAW;
				case CDDS_ITEMPREPAINT:
				{
					int iState;
					/*对于具有LVS_SHOWSELALWAYS样式的所有者绘制的列表视图控件，此标志(指CDIS_SELECTED)不能正常工作
					对于这些控件，您可以通过使用LVM_GETITEMSTATE并检查LVIS_SELECTED标志来确定是否选择了项目(MSDN)*/
					if (SendMessageW(g_hLV, LVM_GETITEMSTATE, p->nmcd.dwItemSpec, LVIS_SELECTED) == LVIS_SELECTED)//选中
					{
						if (p->nmcd.uItemState & CDIS_HOT)
							iState = LISS_HOTSELECTED;
						else
							iState = LISS_SELECTED;
					}
					else if (p->nmcd.uItemState & CDIS_HOT)
						iState = LISS_HOT;
					else
						iState = 0;

					HBRUSH hBrush;

					if (p->nmcd.dwItemSpec % 2)//交替行色
					{
						hBrush = CreateSolidBrush(MYCLR_LISTGRAY);
						FillRect(p->nmcd.hdc, &p->nmcd.rc, hBrush);
						DeleteObject(hBrush);
					}
					if (p->nmcd.dwItemSpec == g_iCurrFileIndex)//标记现行播放项
					{
						hBrush = CreateSolidBrush(MYCLR_LISTPLAYING);
						FillRect(p->nmcd.hdc, &p->nmcd.rc, hBrush);
						DeleteObject(hBrush);
					}
					if (iState)//画表项框
						DrawThemeBackground(hLVTheme, p->nmcd.hdc, LVP_LISTITEM, iState, &p->nmcd.rc, NULL);

					PLAYERLISTUNIT* pI = List_GetArrayItem(p->nmcd.dwItemSpec);

					if (pI->dwFlags & QKLIF_IGNORED)
						SetTextColor(p->nmcd.hdc, QKCOLOR_GRAY);
					else
						SetTextColor(p->nmcd.hdc, QKCOLOR_BLACK);

					RECT rc = p->nmcd.rc;
					rc.left = DPIS_LVTEXTSPACE;
					rc.right = SendMessageW(g_hLV, LVM_GETCOLUMNWIDTH, 0, 0);
					DrawTextW(p->nmcd.hdc, pI->pszName, -1, &rc, DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS | DT_NOPREFIX);
					rc.left = rc.right;
					rc.right = p->nmcd.rc.right;
					DrawTextW(p->nmcd.hdc, pI->pszTime, -1, &rc, DT_SINGLELINE | DT_VCENTER | DT_CENTER | DT_END_ELLIPSIS);

					if (pI->dwFlags & QKLIF_BOOKMARK)
					{
						HGDIOBJ hOldPen = SelectObject(p->nmcd.hdc, CreatePen(PS_SOLID, 1, pI->crBookMark));
						MoveToEx(p->nmcd.hdc, p->nmcd.rc.left, p->nmcd.rc.top, NULL);
						LineTo(p->nmcd.hdc, p->nmcd.rc.right, p->nmcd.rc.top);
						DeleteObject(SelectObject(p->nmcd.hdc, hOldPen));
					}
					if (p->nmcd.dwItemSpec == g_iLaterPlay)
						FrameRect(p->nmcd.hdc, &p->nmcd.rc, GC.hbrCyanDeeper);
				}
				return CDRF_SKIPDEFAULT;
				}
			}
			break;
			case NM_RCLICK://右键单击
			{
				int iItem = ((NMITEMACTIVATE*)lParam)->iItem;
				UINT uFlags = (iItem == -1) ? MF_GRAYED : 0,
					uFlags2 = m_bSort || m_iSearchResult != -1 ? MF_GRAYED : uFlags;
				HMENU hMenu = CreatePopupMenu();
				AppendMenuW(hMenu, uFlags, IDMI_TL_PLAY, L"播放");
				AppendMenuW(hMenu, uFlags, IDMI_TL_PLAYLATER, L"稍后播放");
				SetMenuDefaultItem(hMenu, IDMI_TL_PLAY, FALSE);
				AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
				AppendMenuW(hMenu, uFlags, IDMI_TL_OPEN_IN_EXPLORER, L"打开文件位置");
				AppendMenuW(hMenu, uFlags2, IDMI_TL_DELETE_FROM_LIST, L"从播放列表中删除");
				AppendMenuW(hMenu, uFlags2, IDMI_TL_DELETE, L"从磁盘中删除");
				AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
				AppendMenuW(hMenu, uFlags, IDMI_TL_IGNORE, L"忽略/取消忽略此项目");
				AppendMenuW(hMenu, uFlags, IDMI_TL_RENAME, L"重命名");
				AppendMenuW(hMenu, uFlags, IDMI_TL_INFO, L"详细信息");
				AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
				AppendMenuW(hMenu, uFlags, IDMI_TL_LASTBOOKMARK, L"跳到上一书签");
				AppendMenuW(hMenu, uFlags, IDMI_TL_NEXTBOOKMARK, L"跳到下一书签");
				AppendMenuW(hMenu, uFlags, IDMI_TL_ADDBOOKMARK, L"添加书签");
				AppendMenuW(hMenu, uFlags, IDMI_TL_REMOVEBOOKMARK, L"删除书签");
				//SetMenuItemBitmaps()

				POINT pt;
				GetCursorPos(&pt);
				int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, pt.x, pt.y, 0, g_hMainWnd, NULL);
				DestroyMenu(hMenu);
				switch (iRet)
				{
				case IDMI_TL_PLAY:
				{
					if (iItem != -1)
						PlayFile(iItem);
				}
				break;
				case IDMI_TL_OPEN_IN_EXPLORER:
				{
					int iCount = QKArray_GetCount(g_ItemData);
					QKARRAY pArray = QKArray_Create(0);
					for (int i = 0; i < iCount; ++i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
							QKArray_Add(&pArray, List_GetArrayItem(i)->pszFile);
					}
					iCount = QKArray_GetCount(pArray);
					if (!iCount)
						return 0;
					WCHAR pszPath[MAX_PATH];
					lstrcpyW(pszPath, (PCWSTR)QKArray_Get(pArray, 0));
					PathRemoveFileSpecW(pszPath);
					LPITEMIDLIST pPathIDL;
					SHParseDisplayName(pszPath, NULL, &pPathIDL, 0, 0);

					LPITEMIDLIST* pFileIDL = new LPITEMIDLIST[iCount];

					for (int i = 0; i < iCount; i++)
					{
						SHParseDisplayName((PCWSTR)QKArray_Get(pArray, i), NULL, pFileIDL + i, 0, 0);
					}

					HRESULT hr = SHOpenFolderAndSelectItems(pPathIDL, iCount, (LPCITEMIDLIST*)pFileIDL, 0);

					for (int i = 0; i < iCount; i++)
					{
						CoTaskMemFree(pFileIDL[i]);
					}
					CoTaskMemFree(pPathIDL);
					delete[] pFileIDL;
					QKArray_Delete(pArray);
				}
				break;
				case IDMI_TL_ADDBOOKMARK:
				{
					CHOOSECOLORW cc = { sizeof(CHOOSECOLORW) };
					cc.hwndOwner = hWnd;
					cc.lpCustColors = CustClr;
					cc.Flags = CC_FULLOPEN;
					PLAYERLISTUNIT* p;
					if (ChooseColorW(&cc))
					{
						for (int i = 0; i < g_ItemData->iCount; ++i)
						{
							if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
							{
								p = List_GetArrayItem(i);
								p->dwFlags |= QKLIF_BOOKMARK;
								p->crBookMark = cc.rgbResult;
								if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
									SendMessageW(g_hLV, LVM_REDRAWITEMS, i, i);
							}
						}
						UI_RedrawBookMarkPos();
					}
				}
				break;
				case IDMI_TL_REMOVEBOOKMARK:
				{
					for (int i = 0; i < g_ItemData->iCount; ++i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
						{
							((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->dwFlags &= ~QKLIF_BOOKMARK;
							if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
								SendMessageW(g_hLV, LVM_REDRAWITEMS, i, i);
						}
					}
					UI_RedrawBookMarkPos();
				}
				break;
				case IDMI_TL_LASTBOOKMARK:
				{
					LVITEMW li;
					li.stateMask = li.state = LVIS_SELECTED;
					int iIndex;
					for (int i = iItem; i >= 0; --i)
					{
						if (List_GetArrayItem(i)->dwFlags & QKLIF_BOOKMARK)
						{
							SendMessageW(hWnd, LVM_SETITEMSTATE, i, (LPARAM)&li);
							iIndex = i - SendMessageW(g_hLV, LVM_GETCOUNTPERPAGE, 0, 0);// 把书签顶到最下面
							if (iIndex < 0)
								iIndex = 0;

							SendMessageW(g_hLV, LVM_ENSUREVISIBLE, iIndex, FALSE);
							break;
						}
					}
				}
				return 0;
				case IDMI_TL_NEXTBOOKMARK:
				{
					LVITEMW li;
					li.stateMask = li.state = LVIS_SELECTED;
					int iIndex;
					for (int i = iItem; i < g_ItemData->iCount; ++i)
					{
						if (List_GetArrayItem(i)->dwFlags & QKLIF_BOOKMARK)
						{
							SendMessageW(hWnd, LVM_SETITEMSTATE, i, (LPARAM)&li);
							iIndex = i + SendMessageW(g_hLV, LVM_GETCOUNTPERPAGE, 0, 0) - 1;// 把书签顶到最上面
							if (iIndex >= g_ItemData->iCount)
								iIndex = g_ItemData->iCount - 1;
							SendMessageW(g_hLV, LVM_ENSUREVISIBLE, iIndex, FALSE);
							break;
						}
					}
				}
				return 0;
				case IDMI_TL_DELETE:
				{
					if (QKMessageBox(L"确定要删除选中的文件吗", L"删除后不可恢复，请确认是否要继续删除", (HICON)TD_INFORMATION_ICON, L"询问", NULL, 2) == QKMSGBOX_BTID_2)
						return 0;
					for (int i = g_ItemData->iCount; i >= 0; --i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
						{
							DeleteFileW(((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->pszFile);
							List_Delete(i, FALSE);
						}
					}
					List_ResetLV();
				}
				return 0;
				case IDMI_TL_DELETE_FROM_LIST:
				{
					for (int i = g_ItemData->iCount; i >= 0; --i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
							List_Delete(i, FALSE);
					}
					List_ResetLV();
				}
				return 0;
				case IDMI_TL_RENAME:
				{
					PWSTR pBuf;
					PLAYERLISTUNIT* p;
					if (QKInputBox(L"重命名", L"输入新名称：", &pBuf, hWnd))
					{
						p = List_GetArrayItem(iItem);
						delete[] p->pszName;
						p->pszName = pBuf;
						SendMessageW(g_hLV, LVM_REDRAWITEMS, iItem, iItem);
					}
				}
				return 0;
				case IDMI_TL_INFO:
				{

				}
				return 0;
				case IDMI_TL_IGNORE:
				{
					PLAYERLISTUNIT* p;
					for (int i = 0; i < g_ItemData->iCount; ++i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
						{
							p = List_GetArrayItem(i);
							if (p->dwFlags & QKLIF_IGNORED)
								p->dwFlags &= (~QKLIF_IGNORED);
							else
								p->dwFlags |= QKLIF_IGNORED;
							SendMessageW(g_hLV, LVM_REDRAWITEMS, i, i);
						}
					}
				}
				return 0;
				case IDMI_TL_PLAYLATER:
				{
					if (g_iLaterPlay != -1)
						SendMessageW(g_hLV, LVM_REDRAWITEMS, g_iLaterPlay, g_iLaterPlay);

					if (g_iLaterPlay == iItem)
						g_iLaterPlay = -1;
					else
						g_iLaterPlay = iItem;
					SendMessageW(g_hLV, LVM_REDRAWITEMS, iItem, iItem);
				}
				return 0;
				}
			}
			return TRUE;// 返回非零以不允许默认处理，或返回零以允许默认处理
			case LVN_BEGINDRAG:// 开始拖放
			{
				// 这才是LV拖放正统触发方式，拖放不应该由WM_LBUTTONDOWN触发
				if (((NMLISTVIEW*)lParam)->iItem != -1)
				{
					if (m_iSearchResult != -1 || m_bSort)
						QKMessageBox(L"现在不可重排项目", L"可逆式排序或搜索状态下不可拖动", (HICON)TD_ERROR_ICON, L"错误");

					if (g_iCurrFileIndex != -1)
						((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, g_iCurrFileIndex))->dwFlags |= QKLIF_DRAGMARK_CURRFILE;

					QKARRAY Files = QKArray_Create(0);
					QKARRAY Items = QKArray_Create(0);

					for (int i = 0; i < g_ItemData->iCount; ++i)
					{
						if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
						{
							QKArray_Add(&Files, List_GetArrayItem(i)->pszFile);
							QKArray_AddValue(&Items, &i);
						}
					}

					CDataObject* pDataObject;
					CDropSource* pDropSource;
					QKMakeDropSource(Files, OLEDrag_GiveFeedBack, &pDataObject, &pDropSource, TRUE);
					QKArray_Delete(Files);

					FORMATETC fe =
					{
						g_uMyClipBoardFmt,
						NULL,
						DVASPECT_CONTENT,
						-1,
						TYMED_HGLOBAL
					};
					STGMEDIUM sm;
					sm.tymed = TYMED_HGLOBAL;
					sm.pUnkForRelease = NULL;
					sm.hGlobal = GlobalAlloc(GMEM_MOVEABLE | GMEM_DDESHARE, (Items->iCount + 1) * sizeof(int));

					int* p = (int*)GlobalLock(sm.hGlobal);
					*p = Items->iCount;
					++p;
					for (int i = 0; i < Items->iCount; ++i)
					{
						memcpy(p, QKArray_GetValue(Items, i), sizeof(int));
						++p;
					}
					GlobalUnlock(sm.hGlobal);

					pDataObject->SetData(&fe, &sm, TRUE);

					DWORD dwEffect = DROPEFFECT_NONE;
					HRESULT hr = SHDoDragDrop(hWnd, pDataObject, pDropSource, DROPEFFECT_COPY, &dwEffect);
					delete pDataObject;
					delete pDropSource;

					return 0;
				}
			}
			break;// 没有返回值
			}
			break;
		}
	}
	break;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hDC = BeginPaint(hWnd, &ps);
		FillRect(hDC, &ps.rcPaint, (HBRUSH)GetStockObject(WHITE_BRUSH));
		if (!GS.bNoBookMarkWhenSort || !m_bSort)
		{
			if (m_iSearchResult == -1)
			{
				HGDIOBJ hOldPen = SelectObject(hDC, CreatePen(PS_SOLID, 3, MYCLR_LISTPLAYING));
				int y;
				for (int i = 0; i < g_ItemData->iCount; ++i)
				{
					if (List_GetArrayItem(i)->dwFlags & QKLIF_BOOKMARK)
					{
						y = cyVSBArrow + cySBTrack * i / g_ItemData->iCount + DPIS_CYRITBK;
						MoveToEx(hDC, cxClient - DPIS_GAP, y, NULL);
						LineTo(hDC, cxClient, y);
					}
				}
				DeleteObject(SelectObject(hDC, hOldPen));
			}
		}
		EndPaint(hWnd, &ps);
	}
	return 0;
	case WM_DESTROY:
		CloseThemeData(hLVTheme);
		return 0;
	case WM_THEMECHANGED:
	{
		CloseThemeData(hLVTheme);
		hLVTheme = OpenThemeData(g_hLV, L"ListView");
		cyVSBArrow = GetSystemMetrics(SM_CYVSCROLL);
	}
	return 0;
	}


    return DefWindowProcW(hWnd, message, wParam, lParam);
}
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int cxClient, cyClient;
    if (message == WM_TASKBARBUTTONCREATED)
    {
        if (g_pITaskbarList)
            g_pITaskbarList->Release();

        CoCreateInstance(CLSID_TaskbarList, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&g_pITaskbarList));// 创建ITaskbarList4对象
        g_pITaskbarList->HrInit();// 初始化

        g_pITaskbarList->RegisterTab(m_hTBGhost, hWnd);
        THUMBBUTTON tb[3];
        THUMBBUTTONMASK dwMask = THB_ICON | THB_TOOLTIP;
        tb[0].dwMask = dwMask;
        tb[0].hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(IDI_LAST_TB));//这个图标必须用LoadIcon载入，不知道咋回事..........
        tb[0].iId = IDTBB_LAST;
        lstrcpyW(tb[0].szTip, L"上一曲");

        tb[1].dwMask = dwMask;
        tb[1].hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(IDI_PLAY_TB));
        tb[1].iId = IDTBB_PLAY;
        lstrcpyW(tb[1].szTip, L"播放");

        tb[2].dwMask = dwMask;
        tb[2].hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(IDI_NEXT_TB));
        tb[2].iId = IDTBB_NEXT;
        lstrcpyW(tb[2].szTip, L"下一曲");
        g_pITaskbarList->ThumbBarAddButtons(m_hTBGhost, 3, tb);

        return 0;
    }
	switch (message)
	{
    case WM_COMMAND:
    {
        if (!lParam)//是菜单发出，lParam为0
        {
            
        }
        else//不是菜单或加速器发出
        {
            switch (LOWORD(wParam))
            {
            case IDTBB_LAST:
                SendMessageW(g_hBKBtm, BTMBKM_DOBTOPE, 0, 0);
                return 0;
            case IDTBB_PLAY:
                SendMessageW(g_hBKBtm, BTMBKM_DOBTOPE, 1, 0);
                return 0;
            case IDTBB_NEXT:
                SendMessageW(g_hBKBtm, BTMBKM_DOBTOPE, 2, 0);
                return 0;
            }
        }
    }
    break;
    case WM_CREATE:// 疯狂创建窗口
    {
        ///////////////////////////创建用于支持任务栏操作的幽灵窗口（生命周期与主窗口相同）
        g_hMainWnd = hWnd;
        m_hTBGhost = CreateWindowExW(0, TBGHOSTWNDCLASS, ((CREATESTRUCTW*)lParam)->lpszName, 
			WS_POPUP | WS_CAPTION, -32000, -32000, 10, 10, NULL, NULL, g_hInst, NULL);
        ///////////////////////////初始化.....
        g_iDPI = QKGetDPIForWindow(hWnd);
        UI_UpdateDPISize();
        m_cxLV = DPIS_DEFCXLV;
        
        HWND hCtrl, hCtrl2;
        ///////////////////////////左侧背景（剪辑子窗口）
        hCtrl2 = CreateWindowExW(0, BKWNDCLASS, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
            0, 0, 0, 0,
            hWnd, (HMENU)IDC_BK_LEFT, g_hInst, NULL);
        g_hBKLeft = hCtrl2;
        SetWindowLongPtrW(hCtrl2, GWLP_WNDPROC, (LONG_PTR)WndProc_LeftBK);
        ///////////////////////////歌词滚动条（其实是滑块条啦）
        hCtrl = CreateWindowExW(0, TRACKBAR_CLASSW, NULL, WS_CHILD | TBS_VERT | TBS_FIXEDLENGTH,
			0, 0, DPI(20), DPI(600),
            hCtrl2, (HMENU)IDC_TB_LRCSCROLL, g_hInst, NULL);
        g_hTBLrc = hCtrl;
        SendMessageW(hCtrl, TBM_SETTHUMBLENGTH, DPI(80), 0);
        // 设置后必须自己绘制滑块，默认窗口过程不会扩大滑块
        // 虽然默认窗口过程绘制的轨道会偏离边缘，但命中测试仍然是根据滑块大小来的
        SendMessageW(hCtrl, TBM_SETRANGEMIN, FALSE, 0);
        ///////////////////////////进度滑块条
        hCtrl = CreateWindowExW(0, QKCCN_TRACKBAR, NULL, WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0,
            hCtrl2, (HMENU)IDC_TB_PGS, g_hInst, NULL);
        g_hTBProgess = hCtrl;
        SendMessageW(hCtrl, QKCTBM_SETPROC, FALSE, (LPARAM)QKC_TB_PaintProc);
        SendMessageW(hCtrl, QKCTBM_GETRANGE, FALSE, MAKELONG(0, 10));
        ///////////////////////////底部按钮容器
        hCtrl2 = CreateWindowExW(0, BKWNDCLASS, NULL, WS_CHILD | WS_VISIBLE,
            0, 0, DPIS_CXBTMBTBK, DPIS_BT,
            hCtrl2, (HMENU)IDC_BK_BOTTOMBTBK, g_hInst, NULL);
        g_hBKBtm = hCtrl2;
        SetWindowLongPtrW(hCtrl2, GWLP_WNDPROC, (LONG_PTR)WndProc_BtmBK);
        SendMessageW(hCtrl2, BTMBKM_INIT, 0, 0);
        ///////////////////////////分隔条
        hCtrl = CreateWindowExW(0, QKCCN_SEPARATEBAR, NULL, WS_CHILD | WS_VISIBLE,
            0, 0, 0, 0, hWnd, (HMENU)IDC_SEB, g_hInst, NULL);
        g_hSEB = hCtrl;
        SendMessageW(hCtrl, QKCSEBM_SETCOLOR, QKCOLOR_WHITE, 0);
        SendMessageW(hCtrl, QKCSEBM_SETCOLOR2, 0x9097D2CB, 0);
        SendMessageW(hCtrl, QKCSEBM_SETPROC, (WPARAM)QKCProc_SEB, 0);
        ///////////////////////////列表容器
		hCtrl = CreateWindowExW(0, WNDCLASS_LIST, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
            0, 0, 0, 0,
            hWnd, (HMENU)IDC_BK_LIST, g_hInst, NULL);
        g_hBKList = hCtrl;

        m_pDropTarget = new CDropTarget(OLEDrop_OnEnter, OLEDrop_OnOver, OLEDrop_OnLeave, OLEDrop_OnDrop);
        RegisterDragDrop(hWnd, m_pDropTarget);// 注册拖放目标
	}
	return 0;
	case WM_DESTROY:
	{
        delete m_pDropTarget;
        DestroyWindow(m_hTBGhost);
		
		Stop();
		if (IsWindow(g_hLrcWnd))
			DestroyWindow(g_hLrcWnd);
		if (g_pITaskbarList)
			g_pITaskbarList->Release();
		PostQuitMessage(0);
	}
	return 0;
    case WM_SIZE:
    {
        if (wParam == SIZE_MINIMIZED)
            return 0;
        cxClient = LOWORD(lParam);
        cyClient = HIWORD(lParam);

		int cxLeft;

        if (g_bListSeped || g_bListHidden)
        {
            cxLeft = cxClient;
        }
        else
        {
            cxLeft = cxClient - m_cxLV - DPIS_GAP;
            SetWindowPos(g_hSEB, NULL,
                cxLeft,
                0,
                DPIS_GAP,
                cyClient,
                SWP_NOZORDER);

            SetWindowPos(g_hBKList, NULL,
                cxLeft + DPIS_GAP,
                0,
                m_cxLV,
                cyClient,
                SWP_NOZORDER);

            SendMessageW(g_hSEB, QKCSEBM_SETRANGE, DPI(80), cxClient - DPI(80));
        }

        SetWindowPos(g_hBKLeft, NULL, 0, 0,
            cxLeft,
            cyClient,
            SWP_NOZORDER | SWP_NOMOVE);
    }
    return 0;
    case WM_GETMINMAXINFO:// 限制窗口大小
	{
		LPMINMAXINFO pInfo = (LPMINMAXINFO)lParam;
		pInfo->ptMinTrackSize.x = DPI(450);
		pInfo->ptMinTrackSize.y = DPI(640);
	}
	return 0;
    case MAINWND_REDRAWBOOKMARK:
    {
        RECT rc = { cxClient - DPIS_GAP,DPIS_CYRITBK,cxClient,cyClient };
        InvalidateRect(hWnd, &rc, FALSE);
        UpdateWindow(hWnd);
    }
    return 0;
	case WM_DPICHANGED:
	{
		g_iDPI = HIWORD(wParam);
		UI_UpdateDPISize();
        ImageList_Destroy((HIMAGELIST)SendMessageW(g_hLV, LVM_GETIMAGELIST, LVSIL_SMALL, 0));
        SendMessageW(g_hLV, LVM_SETIMAGELIST, LVSIL_SMALL, (LPARAM)ImageList_Create(1, DPIS_CYLVITEM, 0, 1, 0));// ILC_COLOR缺省
		RECT* p = (RECT*)lParam;
		SetWindowPos(hWnd, NULL, p->left, p->top, p->right - p->left, p->bottom - p->top, SWP_NOZORDER);
	}
	return 0;
    case WM_SETTEXT:// 设置标题，转发，否则预览时不会显示标题（鸣谢：nlmhc）
        SetWindowTextW(m_hTBGhost, (PCWSTR)lParam);
        break;
	}
    return DefWindowProcW(hWnd, message, wParam, lParam);
}
INT_PTR CALLBACK DlgProc_EQ(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hTB[10];
    static BOOL bApply = FALSE;
    static int iCBSel = 0;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        for (int i = 0; i < 23; i++)
        {
			SendDlgItemMessageW(hDlg, IDC_CB_EQ, CB_INSERTSTRING, -1, (LPARAM)c_EQSetting[i].pszText);
        }
        SendDlgItemMessageW(hDlg, IDC_CB_EQ, CB_SETCURSEL, iCBSel, 0);

		SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_SETRANGE, FALSE, MAKELPARAM(10, 360));
		SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_SETPOS, TRUE, m_GlobalEffect.EQ[0].fBandwidth * 10);// 缩小10倍
        SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_SETPAGESIZE, 0, 10);

		hTB[0] = GetDlgItem(hDlg, IDC_TB1);
		hTB[1] = GetDlgItem(hDlg, IDC_TB2);
		hTB[2] = GetDlgItem(hDlg, IDC_TB3);
		hTB[3] = GetDlgItem(hDlg, IDC_TB4);
		hTB[4] = GetDlgItem(hDlg, IDC_TB5);
		hTB[5] = GetDlgItem(hDlg, IDC_TB6);
		hTB[6] = GetDlgItem(hDlg, IDC_TB7);
		hTB[7] = GetDlgItem(hDlg, IDC_TB8);
		hTB[8] = GetDlgItem(hDlg, IDC_TB9);
		hTB[9] = GetDlgItem(hDlg, IDC_TB10);
		for (int i = 0; i < 10; i++)
		{
			SendMessageW(hTB[i], TBM_SETRANGE, FALSE, MAKELPARAM(0, 300));// 减去150再缩小10倍
			SendMessageW(hTB[i], TBM_SETPOS, TRUE, (LPARAM)(m_GlobalEffect.EQ[i].fGain * 10) + 150);
			SendMessageW(hTB[i], TBM_SETPAGESIZE, 0, 10);
		}
	}
    return FALSE;
	case WM_COMMAND:
	{
		switch (HIWORD(wParam))
		{
		case CBN_SELCHANGE:
		{
			iCBSel = SendMessageW((HWND)lParam, CB_GETCURSEL, 0, 0);
			for (int i = 0; i < 10; i++)
			{
				m_GlobalEffect.EQ[i].fGain = c_EQSetting[iCBSel].Setting[i];
				SendMessageW(hTB[i], TBM_SETPOS, TRUE, (LPARAM)(m_GlobalEffect.EQ[i].fGain * 10 + 150));
			}
			goto SetEQ;
		}
		return TRUE;
		case BN_CLICKED:
		{
			if (LOWORD(wParam) == IDC_CB_ENABLE)//启用
			{
				bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
				if (!g_hStream)
					return TRUE;
				if (bApply)
				{
					for (int i = 0; i < 10; ++i)
					{
						if (m_GlobalEffect.hFXEQ[i])
							BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXEQ[i]);
						m_GlobalEffect.hFXEQ[i] = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_PARAMEQ, 1);
					}

					for (int i = 0; i < 10; i++)
					{
						m_GlobalEffect.EQ[i].fGain = (float)SendMessageW(hTB[i], TBM_GETPOS, 0, 0) / 10.0f - 15.0f;
						m_GlobalEffect.EQ[i].fBandwidth = (float)SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_GETPOS, 0, 0) / 10.0f;
					}

					goto SetEQ;
				}
				else
				{
					for (int i = 0; i < 10; ++i)
					{
						if (m_GlobalEffect.hFXEQ[i])
							BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXEQ[i]);
						m_GlobalEffect.hFXEQ[i] = NULL;
					}
				}
			}
			else if (LOWORD(wParam) == IDC_BT_RESET)//重置
			{
				GlobalEffect_ResetToDefault(EFFECT_EQ);
				DlgProc_EQ(hDlg, WM_INITDIALOG, 0, 0);
				goto SetEQ;
			}
		}
		return TRUE;
		}
	}
	return FALSE;
	case WM_VSCROLL:
	{
		for (int i = 0; i < 10; i++)
		{
			if (hTB[i] == (HWND)lParam)
			{
				m_GlobalEffect.EQ[i].fGain = (float)SendMessageW((HWND)lParam, TBM_GETPOS, 0, 0) / 10.0f - 15.0f;
				break;
			}

			m_GlobalEffect.EQ[i].fBandwidth = (float)SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_GETPOS, 0, 0) / 10.0f;
		}

	SetEQ:
		if (!bApply && g_hStream)
			return TRUE;
		for (int i = 0; i < 10; i++)
		{
			BASS_FXSetParameters(m_GlobalEffect.hFXEQ[i], &m_GlobalEffect.EQ[i]);
		}
	}
	return TRUE;
	}
	return FALSE;
}
INT_PTR CALLBACK DlgProc_SBV(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hTBSpeed,
        hTBBlance,
        hTBVol,
        hSTSpeed,
        hSTBlance,
        hSTVol,
        hSTVU;
    static WCHAR szValue[10];
    static HDC hCDC;
    static HBITMAP hBitmap;
	static int cxVU, cyVU;

    switch (message)
    {
    case WM_INITDIALOG:
    {
        hTBSpeed = GetDlgItem(hDlg, IDC_TB_SPEED);
        hTBBlance = GetDlgItem(hDlg, IDC_TB_BLANCE);
        hTBVol = GetDlgItem(hDlg, IDC_TB_VOL);
        hSTSpeed = GetDlgItem(hDlg, IDC_ST_SPEED2);
        hSTBlance = GetDlgItem(hDlg, IDC_ST_BLANCE2);
        hSTVol = GetDlgItem(hDlg, IDC_ST_VOL2);
        hSTVU = GetDlgItem(hDlg, IDC_ST_VU);

        float f;
        HWND hST;
        hST = GetDlgItem(hDlg, IDC_ST_SPEED);
        hST = GetDlgItem(hDlg, IDC_ST_BLANCE);

        SendMessageW(hTBSpeed, TBM_SETRANGEMAX, TRUE, 500);
        if (m_fDefSpeed != 0)
        {
            f = 0;
            BASS_ChannelGetAttribute(g_hStream, BASS_ATTRIB_FREQ, &f);
            f = f / m_fDefSpeed;
            SendMessageW(hTBSpeed, TBM_SETPOS, TRUE, (LPARAM)(f * 100));
            swprintf(szValue, 6, L"x%.2f", f);
            SetWindowTextW(hSTSpeed, szValue);
        }
        else
            SetWindowTextW(hSTSpeed, L"x0.00");
        SendMessageW(hTBSpeed, TBM_SETPAGESIZE, TRUE, 1);

        f = 0;
        BASS_ChannelGetAttribute(g_hStream, BASS_ATTRIB_PAN, &f);
        SendMessageW(hTBBlance, TBM_SETRANGEMAX, TRUE, 200);
        f = f * 100;
        SendMessageW(hTBBlance, TBM_SETPOS, TRUE, (LPARAM)(f + 100));
        wsprintfW(szValue, L"%2d", (int)f);
        SetWindowTextW(hSTBlance, szValue);
        SendMessageW(hTBBlance, TBM_SETPAGESIZE, TRUE, 1);

        f = 0;
        BASS_ChannelGetAttribute(g_hStream, BASS_ATTRIB_VOL, &f);
        SendMessageW(hTBVol, TBM_SETRANGEMAX, TRUE, 100);
        SendMessageW(hTBVol, TBM_SETPAGESIZE, TRUE, 1);
        if (m_bSlient)
        {
            SetWindowTextW((HWND)lParam, L"静音");
            EnableWindow(hTBVol, FALSE);
            f = m_fVolChanged;
        }
        else
        {
            SetWindowTextW((HWND)lParam, L"音量：");
            f = f * 100;
        }
        SendMessageW(hTBVol, TBM_SETPOS, TRUE, (LPARAM)f);
        wsprintfW(szValue, L"%3d", (int)f);
        SetWindowTextW(hSTVol, szValue);

        RECT rc;
        GetClientRect(hSTVU, &rc);
        cxVU = rc.right;
        cyVU = rc.bottom;

        HDC hDC = GetDC(hDlg);
        hCDC = CreateCompatibleDC(NULL);
        hBitmap = CreateCompatibleBitmap(hDC, cxVU, DPIS_CYSPE);
        SelectObject(hCDC, hBitmap);
        ReleaseDC(hDlg, hDC);

        SetTimer(hDlg, IDT_VU_SPE_TIME, TIMERELAPSE_VU_SPE_TIME, NULL);
        SetTimer(hDlg, IDT_DRAWING_VU, TIMERELAPSE_VU_SPE, NULL);
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (LOWORD(wParam) == IDC_BT_VOL)
        {
            m_bSlient = !m_bSlient;
            if (m_bSlient)
            {
                SetWindowTextW((HWND)lParam, L"静音");
                BASS_ChannelGetAttribute(g_hStream, BASS_ATTRIB_VOL, &m_fVolChanged);
                BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_VOL, 0);
                EnableWindow(hTBVol, FALSE);
            }
            else
            {
                SetWindowTextW((HWND)lParam, L"音量：");
                BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_VOL, m_fVolChanged);
                EnableWindow(hTBVol, TRUE);
            }

            return TRUE;
        }
    }
    return FALSE;
    case WM_TIMER:
    {
        switch (wParam)
        {
        case IDT_VU_SPE_TIME:
            m_TimeStru_VU[0].uTime += 500;
            if (m_TimeStru_VU[0].uTime >= 1000)
            {
                m_TimeStru_VU[0].bbool = TRUE;
                m_TimeStru_VU[0].uTime = 0;
            }
            return TRUE;
        case IDT_DRAWING_VU:
        {
            static RECT rc = { 0,0,cxVU,cyVU };
            HDC hDC = GetDC(hSTVU);
            QKGradientFill(
                hCDC,
                &rc,
                RGB(0, (int)(255.0f * 0.7f), 0),
                RGB((int)(255.0f * 0.7f), 0, 0)
            );//画暗色背景

            if (g_hStream)
            {
                //仍然是右上左下
                static int cxRightOld, cxLeftOld;
                int cxRight, cxLeft;
                HRGN hRgn1, hRgn2, hRgn3;

                int iStep = 10, iStep2 = 15;
                int dwLevel = BASS_ChannelGetLevel(g_hStream);//取电平
                cxRight = (int)((float)cxVU * (float)HIWORD(dwLevel) / 32768.0f);//右声道
                if (cxRight > cxRightOld)
                    cxRightOld = cxRight;
                else
                    cxRightOld -= iStep;
                //------------
                if (cxRightOld < 3)
                    cxRightOld = 3;
                //------------
                if (m_TimeStru_VU[0].bbool)
                    m_TimeStru_VU[0].i -= iStep2;
                //------------
                if (cxRightOld > m_TimeStru_VU[0].i)
                {
                    m_TimeStru_VU[0].i = cxRightOld;
                    m_TimeStru_VU[0].bbool = FALSE;
                    m_TimeStru_VU[0].uTime = 0;
                }
                //------------
                if (m_TimeStru_VU[0].i < 3)
                {
                    m_TimeStru_VU[0].i = 3;
                }
                hRgn1 = CreateRectRgn(0, 0, cxRightOld, cyVU / 2);//上区域
                hRgn2 = CreateRectRgn(m_TimeStru_VU[0].i - 3, 0, m_TimeStru_VU[0].i, cyVU / 2);//峰值
                CombineRgn(hRgn1, hRgn1, hRgn2, RGN_OR);//合并上区域和上峰值
                DeleteObject(hRgn2);

                cxLeft = (int)((float)cxVU * (float)LOWORD(dwLevel) / 32768.0f);//左声道
                if (cxLeft > cxLeftOld)
                    cxLeftOld = cxLeft;
                else
                    cxLeftOld -= iStep;
                //------------
                if (cxLeftOld < 3)
                    cxLeftOld = 3;
                //------------
                if (m_TimeStru_VU[1].bbool)
                    m_TimeStru_VU[1].i -= iStep2;
                //------------
                if (cxLeftOld > m_TimeStru_VU[1].i)
                {
                    m_TimeStru_VU[1].i = cxLeftOld;
                    m_TimeStru_VU[1].bbool = FALSE;
                    m_TimeStru_VU[1].uTime = 0;
                }
                //------------
                if (m_TimeStru_VU[1].i < 3)
                {
                    m_TimeStru_VU[1].i = 3;
                }
                hRgn2 = CreateRectRgn(0, cyVU / 2, cxLeftOld, cyVU);//下区域
                hRgn3 = CreateRectRgn(m_TimeStru_VU[1].i - 3, cyVU / 2, m_TimeStru_VU[1].i, cyVU);//峰值
                CombineRgn(hRgn2, hRgn2, hRgn3, RGN_OR);//下区域和下峰值
                DeleteObject(hRgn3);
                CombineRgn(hRgn1, hRgn1, hRgn2, RGN_OR);//合并上下
                DeleteObject(hRgn2);
                SelectClipRgn(hCDC, hRgn1);//设置剪辑区
                DeleteObject(hRgn1);//删除，GDI会为剪辑区保存一个备份
                QKGradientFill(hCDC, &rc, QKCOLOR_GREEN, QKCOLOR_RED);//再次填充
                SelectClipRgn(hCDC, NULL);//清除剪辑区
            }
            BitBlt(hDC, 0, 0, cxVU, cyVU, hCDC, 0, 0, SRCCOPY);//显示
            ReleaseDC(hSTVU, hDC);
        }
        }
    }
    return TRUE;
    case WM_DESTROY:
        DeleteDC(hCDC);
        DeleteObject(hBitmap);
        KillTimer(hDlg, IDT_VU_SPE_TIME);
        KillTimer(hDlg, IDT_DRAWING_VU);
        return TRUE;
    case WM_HSCROLL:
    {
        DWORD dwPos = SendMessageW((HWND)lParam, TBM_GETPOS, 0, 0);

        if ((HWND)lParam == hTBSpeed)
        {
            m_fSpeedChanged = (float)dwPos / 100.0f;
            if (g_hStream)
                BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_FREQ, m_fSpeedChanged * m_fDefSpeed);
            swprintf(szValue, 6, L"x%.2f", (float)dwPos / 100.0f);
            SetWindowTextW(hSTSpeed, szValue);
            return 0;
        }
        else if ((HWND)lParam == hTBBlance)
        {
            m_fBlanceChanged = ((float)dwPos - 100.0f) / 100.0f;
            if (g_hStream)
                BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_PAN, m_fBlanceChanged);
            wsprintfW(szValue, L"%2d", dwPos - 100);
            SetWindowTextW(hSTBlance, szValue);
            return 0;
        }
        else if ((HWND)lParam == hTBVol)
        {
            m_fVolChanged = (float)dwPos / 100.0f;
            if (g_hStream)
                BASS_ChannelSetAttribute(g_hStream, BASS_ATTRIB_VOL, m_fVolChanged);//范围0~1
            wsprintfW(szValue, L"%3d", dwPos);
            SetWindowTextW(hSTVol, szValue);
            return 0;
        }
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Chorus(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETPOS, TRUE, m_GlobalEffect.Chorus.fWetDryMix);

        SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_SETPOS, TRUE, m_GlobalEffect.Chorus.fDepth);

        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETRANGE, FALSE, MAKELPARAM(0, 99 * 2));
        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETPOS, TRUE, m_GlobalEffect.Chorus.fFeedback + 99);// 减去99

		SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
		SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_SETPOS, TRUE, m_GlobalEffect.Chorus.fFrequency * 10);// 缩小十倍

		SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
		SendDlgItemMessageW(hDlg, IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
		SendDlgItemMessageW(hDlg, m_GlobalEffect.Chorus.lWaveform == 1 ? IDC_RB_SINEWAVE : IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_CHECKED, 0);

		SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 40));
		SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_SETPOS, TRUE, m_GlobalEffect.Chorus.fDelay);

        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"-180");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"-90");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"0");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"90");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"180");

        int iIndex = BASS_DX8_PHASE_90;
        switch (m_GlobalEffect.Chorus.lPhase)
        {
        case BASS_DX8_PHASE_NEG_180:iIndex = 0;
        case BASS_DX8_PHASE_NEG_90:iIndex = 1;
        case BASS_DX8_PHASE_ZERO:iIndex = 2;
        case BASS_DX8_PHASE_90:iIndex = 3;
        case BASS_DX8_PHASE_180:iIndex = 4;
        }

        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_SETCURSEL, iIndex, 0);
    }
    return FALSE;
	case WM_COMMAND:
	{
		switch (HIWORD(wParam))
		{
		case CBN_SELCHANGE:
			goto SetChorus;
			return TRUE;
		case BN_CLICKED:
		{
			switch (LOWORD(wParam))
			{
			case IDC_CB_ENABLE:
				bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXChorus)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXChorus);
                    m_GlobalEffect.hFXChorus = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_CHORUS, 1);
                    goto SetChorus;
                }
                else
                {
                    if (m_GlobalEffect.hFXChorus)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXChorus);
                    m_GlobalEffect.hFXChorus = NULL;
                }

				return TRUE;
			case IDC_BT_RESET:
				GlobalEffect_ResetToDefault(EFFECT_CHORUS);
				DlgProc_Chorus(hDlg, WM_INITDIALOG, 0, 0);
                goto SetChorus;
				return TRUE;
			case IDC_RB_SINEWAVE:
			case IDC_RB_TRIANGLEWAVE:
				goto SetChorus;
				return TRUE;
			}
		}
		return TRUE;
        }
    }
    return FALSE;
    case WM_HSCROLL:
    {
	SetChorus:
		DWORD dwPhase = BASS_DX8_PHASE_90;
		switch (SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_GETCURSEL, 0, 0))
		{
		case 0:dwPhase = BASS_DX8_PHASE_NEG_180;
		case 1:dwPhase = BASS_DX8_PHASE_NEG_90;
		case 2:dwPhase = BASS_DX8_PHASE_ZERO;
		case 3:dwPhase = BASS_DX8_PHASE_90;
		case 4:dwPhase = BASS_DX8_PHASE_180;
		}

		m_GlobalEffect.Chorus =
		{
			(float)SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_GETPOS, 0, 0),
		    (float)SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_GETPOS, 0, 0),
		    (float)SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_GETPOS, 0, 0) - 99,
		    (float)SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_GETPOS, 0, 0) / 10,
		    (SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1ul : 0ul),
		    (float)SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_GETPOS, 0, 0),
		    dwPhase
		};
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXChorus, &m_GlobalEffect.Chorus);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Compressor(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETRANGE, FALSE, MAKELPARAM(0, 60 * 2));
        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fGain);

        SendDlgItemMessageW(hDlg, IDC_TB_ATTACK, TBM_SETRANGEMIN, FALSE, 1);
        SendDlgItemMessageW(hDlg, IDC_TB_ATTACK, TBM_SETRANGEMAX, FALSE, 50000);
        SendDlgItemMessageW(hDlg, IDC_TB_ATTACK, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fAttack * 100);// 缩小100倍

        SendDlgItemMessageW(hDlg, IDC_TB_RELEASE, TBM_SETRANGE, FALSE, MAKELPARAM(50, 3000));
        SendDlgItemMessageW(hDlg, IDC_TB_RELEASE, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fRelease);

        SendDlgItemMessageW(hDlg, IDC_TB_THRESHOLD, TBM_SETRANGE, FALSE, MAKELPARAM(0, 60));
        SendDlgItemMessageW(hDlg, IDC_TB_THRESHOLD, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fThreshold + 60);// 减去60

        SendDlgItemMessageW(hDlg, IDC_TB_RATIO, TBM_SETRANGE, FALSE, MAKELPARAM(1, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_RATIO, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fRatio);

        SendDlgItemMessageW(hDlg, IDC_TB_PREDELAY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 40));
        SendDlgItemMessageW(hDlg, IDC_TB_PREDELAY, TBM_SETPOS, TRUE, m_GlobalEffect.Compressor.fPredelay * 10);// 缩小10倍
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (HIWORD(wParam) == BN_CLICKED)
        {
            if (LOWORD(wParam) == IDC_CB_ENABLE)// 启用
            {
                bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXCompressor)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXCompressor);
                    m_GlobalEffect.hFXCompressor = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_COMPRESSOR, 1);
                    goto SetCompressor;
                }
                else
                {
                    if (m_GlobalEffect.hFXCompressor)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXCompressor);
                    m_GlobalEffect.hFXCompressor = NULL;
                }
            }
            else if (LOWORD(wParam) == IDC_BT_RESET)//重置
            {
                GlobalEffect_ResetToDefault(EFFECT_COMPRESSOR);
                DlgProc_Compressor(hDlg, WM_INITDIALOG, 0, 0);
                goto SetCompressor;
            }
        }
    }
    return TRUE;
    case WM_HSCROLL:
    {
    SetCompressor:
        m_GlobalEffect.Compressor =
        {
            (float)SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_ATTACK, TBM_GETPOS, 0, 0) / 100,
            (float)SendDlgItemMessageW(hDlg, IDC_TB_RELEASE, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_THRESHOLD, TBM_GETPOS, 0, 0) - 60,
            (float)SendDlgItemMessageW(hDlg, IDC_TB_RATIO, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_PREDELAY, TBM_GETPOS, 0, 0) / 10,
        };
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXCompressor, &m_GlobalEffect.Compressor);
    }
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Distortion(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETRANGE, FALSE, MAKELPARAM(0, 60));
        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETPOS, TRUE, m_GlobalEffect.Distortion.fGain + 60);// 减去60

        SendDlgItemMessageW(hDlg, IDC_TB_EDGE, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_EDGE, TBM_SETPOS, TRUE, m_GlobalEffect.Distortion.fEdge);

        SendDlgItemMessageW(hDlg, IDC_TB_CENTERFREQUENCY, TBM_SETRANGE, FALSE, MAKELPARAM(100, 8000));
        SendDlgItemMessageW(hDlg, IDC_TB_CENTERFREQUENCY, TBM_SETPOS, TRUE, m_GlobalEffect.Distortion.fPostEQCenterFrequency);

        SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_SETRANGE, FALSE, MAKELPARAM(100, 8000));
        SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_SETPOS, TRUE, m_GlobalEffect.Distortion.fPostEQBandwidth);

        SendDlgItemMessageW(hDlg, IDC_TB_PRELOWPASSCUTOFF, TBM_SETRANGE, FALSE, MAKELPARAM(100, 8000));
        SendDlgItemMessageW(hDlg, IDC_TB_PRELOWPASSCUTOFF, TBM_SETPOS, TRUE, m_GlobalEffect.Distortion.fPreLowpassCutoff);
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (HIWORD(wParam) == BN_CLICKED)
        {
            if (LOWORD(wParam) == IDC_CB_ENABLE)// 启用
            {
                bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXDistortion)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXDistortion);
                    m_GlobalEffect.hFXDistortion = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_DISTORTION, 1);
                    goto SetDistortion;
                }
                else
                {
                    if (m_GlobalEffect.hFXDistortion)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXDistortion);
                    m_GlobalEffect.hFXDistortion = NULL;
                }
            }
            else if (LOWORD(wParam) == IDC_BT_RESET)//重置
            {
                GlobalEffect_ResetToDefault(EFFECT_DISTORTION);
                DlgProc_Distortion(hDlg, WM_INITDIALOG, 0, 0);
                goto SetDistortion;
            }
        }
    }
    return TRUE;
    case WM_HSCROLL:
    {
    SetDistortion:
        m_GlobalEffect.Distortion =
        {
            (float)SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_GETPOS, 0, 0) - 60,
            (float)SendDlgItemMessageW(hDlg, IDC_TB_EDGE, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_CENTERFREQUENCY, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_BANDWIDTH, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_PRELOWPASSCUTOFF, TBM_GETPOS, 0, 0)
        };
        if (!bApply || !g_hStream)
            return TRUE;
		BASS_FXSetParameters(m_GlobalEffect.hFXDistortion, &m_GlobalEffect.Distortion);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Echo(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETPOS, TRUE, m_GlobalEffect.Echo.fWetDryMix);

        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETPOS, TRUE, m_GlobalEffect.Echo.fFeedback);

        SendDlgItemMessageW(hDlg, IDC_TB_LEFTDELAY, TBM_SETRANGE, FALSE, MAKELPARAM(1, 2000));
        SendDlgItemMessageW(hDlg, IDC_TB_LEFTDELAY, TBM_SETPOS, TRUE, m_GlobalEffect.Echo.fLeftDelay);

        SendDlgItemMessageW(hDlg, IDC_TB_RIGHTDELAY, TBM_SETRANGE, FALSE, MAKELPARAM(1, 2000));
        SendDlgItemMessageW(hDlg, IDC_TB_RIGHTDELAY, TBM_SETPOS, TRUE, m_GlobalEffect.Echo.fRightDelay);

        SendDlgItemMessageW(hDlg, IDC_CB_PANDELAY, BM_SETCHECK, m_GlobalEffect.Echo.lPanDelay ? BST_CHECKED : BST_UNCHECKED, 0);
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (HIWORD(wParam) == BN_CLICKED)
		{
			switch (LOWORD(wParam))
			{
			case IDC_CB_ENABLE:// 启用
				bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
				if (bApply)
				{
					if (m_GlobalEffect.hFXEcho)
						BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXEcho);
					m_GlobalEffect.hFXEcho = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_ECHO, 1);
					goto SetEcho;
				}
				else
				{
					if (m_GlobalEffect.hFXEcho)
						BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXEcho);
					m_GlobalEffect.hFXEcho = NULL;
				}
				return TRUE;
			case IDC_BT_RESET: // 重置
				GlobalEffect_ResetToDefault(EFFECT_ECHO);
				DlgProc_Echo(hDlg, WM_INITDIALOG, 0, 0);
				goto SetEcho;
				return TRUE;
			case IDC_CB_PANDELAY:
				goto SetEcho;
				return TRUE;
			}
        }
    }
    return TRUE;
    case WM_HSCROLL:
    {
    SetEcho:
        m_GlobalEffect.Echo =
        {
            (float)SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_LEFTDELAY, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_RIGHTDELAY, TBM_GETPOS, 0, 0),
			(SendDlgItemMessageW(hDlg, IDC_CB_PANDELAY, BM_GETCHECK, 0, 0) == BST_CHECKED ? TRUE : FALSE)
        };
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXEcho, &m_GlobalEffect.Echo);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Flanger(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_SETPOS, TRUE, m_GlobalEffect.Flanger.fWetDryMix);

        SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_SETPOS, TRUE, m_GlobalEffect.Flanger.fDepth);

        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETRANGE, FALSE, MAKELPARAM(0, 99 * 2));
        SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_SETPOS, TRUE, m_GlobalEffect.Flanger.fFeedback + 99);// 减去99

        SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_SETPOS, TRUE, m_GlobalEffect.Flanger.fFrequency * 10);// 缩小十倍

        SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
        SendDlgItemMessageW(hDlg, IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
        SendDlgItemMessageW(hDlg, m_GlobalEffect.Flanger.lWaveform == 1 ? IDC_RB_SINEWAVE : IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_CHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 40));
        SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_SETPOS, TRUE, m_GlobalEffect.Flanger.fDelay);

        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"-180");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"-90");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"0");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"90");
        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_INSERTSTRING, -1, (LPARAM)L"180");

        int iIndex = BASS_DX8_PHASE_90;
        switch (m_GlobalEffect.Flanger.lPhase)
        {
        case BASS_DX8_PHASE_NEG_180:iIndex = 0;
        case BASS_DX8_PHASE_NEG_90:iIndex = 1;
        case BASS_DX8_PHASE_ZERO:iIndex = 2;
        case BASS_DX8_PHASE_90:iIndex = 3;
        case BASS_DX8_PHASE_180:iIndex = 4;
        }

        SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_SETCURSEL, iIndex, 0);
    }
    return FALSE;
    case WM_COMMAND:
    {
        switch (HIWORD(wParam))
        {
        case CBN_SELCHANGE:
            goto SetFlanger;
            return TRUE;
        case BN_CLICKED:
        {
            switch (LOWORD(wParam))
            {
            case IDC_CB_ENABLE:
                bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXFlanger)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXFlanger);
                    m_GlobalEffect.hFXFlanger = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_FLANGER, 1);
                    goto SetFlanger;
                }
                else
                {
                    if (m_GlobalEffect.hFXFlanger)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXFlanger);
                    m_GlobalEffect.hFXFlanger = NULL;
                }

                return TRUE;
            case IDC_BT_RESET:
                GlobalEffect_ResetToDefault(EFFECT_FLANGER);
                DlgProc_Flanger(hDlg, WM_INITDIALOG, 0, 0);
                goto SetFlanger;
                return TRUE;
            case IDC_RB_SINEWAVE:
            case IDC_RB_TRIANGLEWAVE:
                goto SetFlanger;
                return TRUE;
            }
        }
        return TRUE;
        }
    }
    return FALSE;
    case WM_HSCROLL:
    {
    SetFlanger:
        DWORD dwPhase = BASS_DX8_PHASE_90;
        switch (SendDlgItemMessageW(hDlg, IDC_CB_LFOPHASE, CB_GETCURSEL, 0, 0))
        {
        case 0:dwPhase = BASS_DX8_PHASE_NEG_180;
        case 1:dwPhase = BASS_DX8_PHASE_NEG_90;
        case 2:dwPhase = BASS_DX8_PHASE_ZERO;
        case 3:dwPhase = BASS_DX8_PHASE_90;
        case 4:dwPhase = BASS_DX8_PHASE_180;
        }

        m_GlobalEffect.Flanger =
        {
            (float)SendDlgItemMessageW(hDlg, IDC_TB_WETDRYMIX, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_LFODEPTH, TBM_GETPOS, 0, 0),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_FEEDBACK, TBM_GETPOS, 0, 0) - 99,
            (float)SendDlgItemMessageW(hDlg, IDC_TB_LFOFREQUENCY, TBM_GETPOS, 0, 0) / 10,
            (SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1ul : 0ul),
            (float)SendDlgItemMessageW(hDlg, IDC_TB_DELAY, TBM_GETPOS, 0, 0),
            dwPhase
        };
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXFlanger, &m_GlobalEffect.Flanger);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Gargle(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
	{
		SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

		SendDlgItemMessageW(hDlg, IDC_TB_RATEHZ, TBM_SETRANGE, FALSE, MAKELPARAM(1, 1000));
		SendDlgItemMessageW(hDlg, IDC_TB_RATEHZ, TBM_SETPOS, TRUE, m_GlobalEffect.Gargle.dwRateHz);

        SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
        SendDlgItemMessageW(hDlg, IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_UNCHECKED, 0);
		SendDlgItemMessageW(hDlg, m_GlobalEffect.Gargle.dwWaveShape == 1 ? IDC_RB_SINEWAVE : IDC_RB_TRIANGLEWAVE, BM_SETCHECK, BST_CHECKED, 0);
	}
    return FALSE;
    case WM_COMMAND:
    {
        if (HIWORD(wParam) == BN_CLICKED)
        {
            switch (LOWORD(wParam))
            {
            case IDC_CB_ENABLE:
                bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXGargle)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXGargle);
                    m_GlobalEffect.hFXGargle = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_GARGLE, 1);
                    goto SetGargle;
                }
                else
                {
                    if (m_GlobalEffect.hFXGargle)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXGargle);
                    m_GlobalEffect.hFXGargle = NULL;
                }

                return TRUE;
            case IDC_BT_RESET:
                GlobalEffect_ResetToDefault(EFFECT_GARGLE);
                DlgProc_Gargle(hDlg, WM_INITDIALOG, 0, 0);
                goto SetGargle;
                return TRUE;
            case IDC_RB_SINEWAVE:
            case IDC_RB_TRIANGLEWAVE:
                goto SetGargle;
                return TRUE;
            }
        }
    }
    return TRUE;
    case WM_HSCROLL:
    {
    SetGargle:
        m_GlobalEffect.Gargle =
        {
            (DWORD)SendDlgItemMessageW(hDlg, IDC_TB_RATEHZ, TBM_GETPOS, 0, 0),
            (SendDlgItemMessageW(hDlg, IDC_RB_SINEWAVE, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1ul : 0ul)
        };
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXGargle, &m_GlobalEffect.Gargle);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_I3DL2Reverb(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_ROOM, TBM_SETRANGE, FALSE, MAKELPARAM(0, 10000));
        SendDlgItemMessageW(hDlg, IDC_TB_ROOM, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.lRoom + 10000);// 减去10000

        SendDlgItemMessageW(hDlg, IDC_TB_ROOMHF, TBM_SETRANGE, FALSE, MAKELPARAM(0, 10000));
        SendDlgItemMessageW(hDlg, IDC_TB_ROOMHF, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.lRoomHF + 10000);// 减去10000

        SendDlgItemMessageW(hDlg, IDC_TB_ROOMROLLOFFFACTOR, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_ROOMROLLOFFFACTOR, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flRoomRolloffFactor * 10);// 缩小10倍

        SendDlgItemMessageW(hDlg, IDC_TB_DECAYTIME, TBM_SETRANGE, FALSE, MAKELPARAM(10, 2000));
        SendDlgItemMessageW(hDlg, IDC_TB_DECAYTIME, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flDecayTime * 100);// 缩小100倍

        SendDlgItemMessageW(hDlg, IDC_TB_DECAYHFRADIO, TBM_SETRANGE, FALSE, MAKELPARAM(10, 2000));
        SendDlgItemMessageW(hDlg, IDC_TB_DECAYHFRADIO, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flDecayHFRatio * 100);// 缩小100倍

        SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONS, TBM_SETRANGE, FALSE, MAKELPARAM(0, 11000));
        SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONS, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.lReflections + 10000);// 减去10000

        SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONSDELAY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 300));
        SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONSDELAY, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flReflectionsDelay * 1000);// 缩小1000倍

        SendDlgItemMessageW(hDlg, IDC_TB_REVERB, TBM_SETRANGE, FALSE, MAKELPARAM(0, 12000));
        SendDlgItemMessageW(hDlg, IDC_TB_REVERB, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.lReverb + 10000);// 减去10000

        SendDlgItemMessageW(hDlg, IDC_TB_REVERBDELAY, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_REVERBDELAY, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flReverbDelay * 1000);// 缩小1000倍

        SendDlgItemMessageW(hDlg, IDC_TB_DIFFUSION, TBM_SETRANGE, FALSE, MAKELPARAM(0, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_DIFFUSION, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flDiffusion);

        SendDlgItemMessageW(hDlg, IDC_TB_DENSITY, TBM_SETRANGE, FALSE, MAKELPARAM(1, 100));
        SendDlgItemMessageW(hDlg, IDC_TB_DENSITY, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flDensity);

        SendDlgItemMessageW(hDlg, IDC_TB_HFREFERENCE, TBM_SETRANGE, FALSE, MAKELPARAM(20, 20000));
        SendDlgItemMessageW(hDlg, IDC_TB_HFREFERENCE, TBM_SETPOS, TRUE, m_GlobalEffect.I3DL2Reverb.flHFReference);
    }
    return FALSE;
    case WM_COMMAND:
	{
		if (HIWORD(wParam) == BN_CLICKED)
		{
			if (LOWORD(wParam) == IDC_CB_ENABLE)// 启用
			{
				bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
				if (bApply)
				{
					if (m_GlobalEffect.hFXI3DL2Reverb)
						BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXI3DL2Reverb);
					m_GlobalEffect.hFXI3DL2Reverb = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_I3DL2REVERB, 1);
					goto SetI3DL2Reverb;
				}
				else
				{
					if (m_GlobalEffect.hFXI3DL2Reverb)
						BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXI3DL2Reverb);
					m_GlobalEffect.hFXI3DL2Reverb = NULL;
				}
			}
			else if (LOWORD(wParam) == IDC_BT_RESET)//重置
			{
				GlobalEffect_ResetToDefault(EFFECT_I3DL2REVERB);
				DlgProc_I3DL2Reverb(hDlg, WM_INITDIALOG, 0, 0);
				goto SetI3DL2Reverb;
			}
		}
	}
    return TRUE;
    case WM_HSCROLL:
    {
	SetI3DL2Reverb:
		m_GlobalEffect.I3DL2Reverb =
		{
			SendDlgItemMessageW(hDlg, IDC_TB_ROOM, TBM_GETPOS, 0, 0) - 10000,
			SendDlgItemMessageW(hDlg, IDC_TB_ROOMHF, TBM_GETPOS, 0, 0) - 10000,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_ROOMROLLOFFFACTOR, TBM_GETPOS, 0, 0) / 10,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_DECAYTIME, TBM_GETPOS, 0, 0) / 100,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_DECAYHFRADIO, TBM_GETPOS, 0, 0) / 100,
			SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONS, TBM_GETPOS, 0, 0) - 10000,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_REFLECTIONSDELAY, TBM_GETPOS, 0, 0) / 1000,
			SendDlgItemMessageW(hDlg, IDC_TB_REVERB, TBM_GETPOS, 0, 0) - 10000,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_REVERBDELAY, TBM_GETPOS, 0, 0) / 1000,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_DIFFUSION, TBM_GETPOS, 0, 0),
			(float)SendDlgItemMessageW(hDlg, IDC_TB_DENSITY, TBM_GETPOS, 0, 0) ,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_HFREFERENCE, TBM_GETPOS, 0, 0)
		};
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXI3DL2Reverb, &m_GlobalEffect.I3DL2Reverb);
	}
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Reverb(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bApply = FALSE;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        SendDlgItemMessageW(hDlg, IDC_CB_ENABLE, BM_SETCHECK, bApply ? BST_CHECKED : BST_UNCHECKED, 0);

        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETRANGE, FALSE, MAKELPARAM(0, 96));
        SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_SETPOS, TRUE, m_GlobalEffect.Reverb.fInGain + 96);// 减去96

        SendDlgItemMessageW(hDlg, IDC_TB_REVERBMIX, TBM_SETRANGE, FALSE, MAKELPARAM(0, 96));
        SendDlgItemMessageW(hDlg, IDC_TB_REVERBMIX, TBM_SETPOS, TRUE, m_GlobalEffect.Reverb.fReverbMix + 96);// 减去96

        SendDlgItemMessageW(hDlg, IDC_TB_REVERBTIME, TBM_SETRANGEMIN, FALSE, 1);
        SendDlgItemMessageW(hDlg, IDC_TB_REVERBTIME, TBM_SETRANGEMAX, FALSE, 3000000);
        SendDlgItemMessageW(hDlg, IDC_TB_REVERBTIME, TBM_SETPOS, TRUE, m_GlobalEffect.Reverb.fReverbTime * 1000);// 缩小1000

        SendDlgItemMessageW(hDlg, IDC_TB_HIGHFREQRTRATIO, TBM_SETRANGE, FALSE, MAKELPARAM(1, 999));
        SendDlgItemMessageW(hDlg, IDC_TB_HIGHFREQRTRATIO, TBM_SETPOS, TRUE, m_GlobalEffect.Reverb.fHighFreqRTRatio * 1000);// 缩小1000倍
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (HIWORD(wParam) == BN_CLICKED)
        {
            if (LOWORD(wParam) == IDC_CB_ENABLE)// 启用
            {
                bApply = (SendMessageW((HWND)lParam, BM_GETCHECK, 0, 0) == BST_CHECKED);
                if (!g_hStream)
                    return TRUE;
                if (bApply)
                {
                    if (m_GlobalEffect.hFXReverb)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXReverb);
                    m_GlobalEffect.hFXReverb = BASS_ChannelSetFX(g_hStream, BASS_FX_DX8_REVERB, 1);
                    goto SetReverb;
                }
                else
                {
                    if (m_GlobalEffect.hFXReverb)
                        BASS_ChannelRemoveFX(g_hStream, m_GlobalEffect.hFXReverb);
                    m_GlobalEffect.hFXReverb = NULL;
                }
            }
            else if (LOWORD(wParam) == IDC_BT_RESET)//重置
            {
                GlobalEffect_ResetToDefault(EFFECT_REVERB);
                DlgProc_Reverb(hDlg, WM_INITDIALOG, 0, 0);
                goto SetReverb;
            }
        }
    }
    return TRUE;
    case WM_HSCROLL:
    {
	SetReverb:
		m_GlobalEffect.Reverb =
		{
			(float)SendDlgItemMessageW(hDlg, IDC_TB_GAIN, TBM_GETPOS, 0, 0) - 96,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_REVERBMIX, TBM_GETPOS, 0, 0) - 96,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_REVERBTIME, TBM_GETPOS, 0, 0) / 1000,
			(float)SendDlgItemMessageW(hDlg, IDC_TB_HIGHFREQRTRATIO, TBM_GETPOS, 0, 0) / 1000
		};
        if (!bApply || !g_hStream)
            return TRUE;
        BASS_FXSetParameters(m_GlobalEffect.hFXReverb, &m_GlobalEffect.Reverb);
    }
    return TRUE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Effect(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hTab;
    static HWND hChild[EFFECTWNDTABCOUNT];
    switch (message)
    {
    case WM_INITDIALOG:
    {
        RECT rc, rc2;
        GetWindowRect(hDlg, &rc);
        GetWindowRect(g_hMainWnd, &rc2);
        SetWindowPos(hDlg, NULL,
            ((rc2.right - rc2.left) - (rc.right - rc.left)) / 2 + rc2.left,
            ((rc2.bottom - rc2.top) - (rc.bottom - rc.top)) / 2 + rc2.top,
            0, 0, SWP_NOZORDER | SWP_NOSIZE);

        hTab = GetDlgItem(hDlg, IDC_TAB);
        SetWindowLongPtrW(hTab, GWL_STYLE, GetWindowLongPtrW(hTab, GWL_STYLE) | WS_CLIPCHILDREN);//剪辑子窗口
        TCITEMW tci = { 0 };
        tci.mask = TCIF_TEXT;

        tci.pszText = (LPWSTR)L"参数调节";
        SendMessageW(hTab, TCM_INSERTITEMW, 0, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"均衡器";
        SendMessageW(hTab, TCM_INSERTITEMW, 1, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"合唱";
        SendMessageW(hTab, TCM_INSERTITEMW, 2, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"压缩";
        SendMessageW(hTab, TCM_INSERTITEMW, 3, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"失真";
        SendMessageW(hTab, TCM_INSERTITEMW, 4, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"回声";
        SendMessageW(hTab, TCM_INSERTITEMW, 5, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"镶边";
        SendMessageW(hTab, TCM_INSERTITEMW, 6, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"漱口";
        SendMessageW(hTab, TCM_INSERTITEMW, 7, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"3D混响";
        SendMessageW(hTab, TCM_INSERTITEMW, 8, (LPARAM)&tci);

        tci.pszText = (LPWSTR)L"混响";
        SendMessageW(hTab, TCM_INSERTITEMW, 9, (LPARAM)&tci);

        SendMessageW(hTab, TCM_SETCURSEL, 0, 0);

        SendMessageW(hTab, TCM_GETITEMRECT, 0, (LPARAM)&rc);
        GetClientRect(hTab, &rc2);

        PWSTR DialogID[EFFECTWNDTABCOUNT] =
        {
            MAKEINTRESOURCEW(IDD_SBV),
            MAKEINTRESOURCEW(IDD_EQ),
            MAKEINTRESOURCEW(IDD_CHORUS),
            MAKEINTRESOURCEW(IDD_COMPRESSOR),
            MAKEINTRESOURCEW(IDD_DISTORTION),
            MAKEINTRESOURCEW(IDD_ECHO),
            MAKEINTRESOURCEW(IDD_FLANGER),
            MAKEINTRESOURCEW(IDD_GARGLE),
            MAKEINTRESOURCEW(IDD_I3DL2REVERB),
            MAKEINTRESOURCEW(IDD_REVERB)
        };
        DLGPROC DialogProc[EFFECTWNDTABCOUNT] =
        {
            DlgProc_SBV,
            DlgProc_EQ,
            DlgProc_Chorus,
            DlgProc_Compressor,
            DlgProc_Distortion,
            DlgProc_Echo,
            DlgProc_Flanger,
            DlgProc_Gargle,
            DlgProc_I3DL2Reverb,
            DlgProc_Reverb
		};
        HWND hWnd;
		for (int i = 0; i < 10; ++i)
		{
			hChild[i] = CreateDialogParamW(g_hInst, DialogID[i], hDlg, DialogProc[i], 0);
			SetParent(hChild[i], hTab);
			SetWindowPos(hChild[i], NULL, 0, rc.bottom, rc2.right + 3, rc2.bottom - rc.bottom + 3, SWP_NOZORDER);
			SetWindowLongPtrW(hChild[i], GWL_STYLE, WS_CHILD);
			ShowWindow(hChild[i], SW_HIDE);

            SendDlgItemMessageW(hChild[i], IDC_CB_ENABLE, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiTick);
            SendDlgItemMessageW(hChild[i], IDC_BT_RESET, BM_SETIMAGE, IMAGE_ICON, (LPARAM)GR.hiRMTotalLoop);// 设置图标
		}
        ShowWindow(hChild[0], SW_SHOW);
    }
    return FALSE;
    case WM_CLOSE:
    {
        DestroyWindow(hDlg);
    }
    return TRUE;
    case WM_NOTIFY:
    {
        if (((NMHDR*)lParam)->idFrom == IDC_TAB)
        {
            if (((NMHDR*)lParam)->code == TCN_SELCHANGE)//返回值不使用
            {
                int j = SendMessageW(hTab, TCM_GETCURSEL, 0, 0);
                for (int i = 0; i < EFFECTWNDTABCOUNT; ++i)
                {
                    if (i == j)
                        ShowWindow(hChild[i], SW_SHOW);
                    else
                        ShowWindow(hChild[i], SW_HIDE);
                }
                return TRUE;
            }
        }
    }
    return FALSE;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_BookMark(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hLV,
        hStatic;
    static HBRUSH hbrStatic = NULL;
    switch (message)
    {
    case WM_INITDIALOG:
    {
        hLV = GetDlgItem(hDlg, IDC_LV_BOOKMARK);
        hStatic = GetDlgItem(hDlg, IDC_ST_BMCLR);
        ///////////////设置风格
        DWORD dwStyle = LVS_EX_FULLROWSELECT | LVS_EX_DOUBLEBUFFER;
		SendMessageW(hLV, LVM_SETEXTENDEDLISTVIEWSTYLE, dwStyle, dwStyle);
		SetWindowTheme(hLV, L"Explorer", NULL);
		///////////////插入列
		LVCOLUMNW lc;
		lc.mask = LVCF_TEXT | LVCF_WIDTH;
		lc.pszText = (PWSTR)L"索引";
		lc.cx = DPI(34);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 0, (LPARAM)&lc);

		lc.pszText = (PWSTR)L"名称";
		lc.cx = DPI(110);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 1, (LPARAM)&lc);

		lc.pszText = (PWSTR)L"颜色";
		lc.cx = DPI(70);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 2, (LPARAM)&lc);

		lc.pszText = (PWSTR)L"备注";
		lc.cx = DPI(170);
		SendMessageW(hLV, LVM_INSERTCOLUMNW, 3, (LPARAM)&lc);
        LVITEMW li;
        ///////////////插入表项
        SendMessageW(hLV, WM_SETREDRAW, FALSE, 0);
        li.mask = LVIF_TEXT | LVIF_PARAM;
        PLAYERLISTUNIT* p;
        int j = 0;
        WCHAR szBuf[20];
        int iIndex;
        for (int i = 0; i < g_ItemData->iCount; ++i)
        {
            p = List_GetArrayItem(i);
            if (p->dwFlags & QKLIF_BOOKMARK)
            {
                iIndex = List_GetArrayItemIndex(i);
                li.iItem = j;
                li.iSubItem = 0;
                wsprintfW(szBuf, L"%d", iIndex);
                li.pszText = szBuf;
                li.lParam = iIndex;
                SendMessageW(hLV, LVM_INSERTITEMW, 0, (LPARAM)&li);// 索引

                li.iSubItem = 1;
                li.pszText = p->pszBookMark;
                SendMessageW(hLV, LVM_SETITEMTEXTW, j, (LPARAM)&li);// 名称
                li.iSubItem = 2;
                wsprintfW(szBuf, L"0x%06X", QKGDIClrToCommonClr(p->crBookMark));// 如果在格式化文本里加#会把0x里的x一起大写，那样不太好看...
                li.pszText = szBuf;
                SendMessageW(hLV, LVM_SETITEMTEXTW, j, (LPARAM)&li);// 颜色
                li.iSubItem = 3;
                li.pszText = p->pszBookMarkComment;
                SendMessageW(hLV, LVM_SETITEMTEXTW, j, (LPARAM)&li);// 备注
                ++j;
            }
        }
        SendMessageW(hLV, WM_SETREDRAW, TRUE, 0);
        InvalidateRect(hLV, NULL, FALSE);
    }
    return TRUE;
    case WM_COMMAND:
    {
        switch (LOWORD(wParam))
        {
        case IDC_BT_OK:
            EndDialog(hDlg, 0);
            return TRUE;
        case IDC_BT_BMDEL:
        {
            LVITEMW li;
            for (int i = SendMessageW(hLV, LVM_GETITEMCOUNT, 0, 0); i >= 0; --i)
            {
                if (SendMessageW(hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
                {
                    li.iItem = i;
                    li.iSubItem = 0;
                    li.mask = LVIF_PARAM;
                    SendMessageW(hLV, LVM_GETITEMW, 0, (LPARAM)&li);
                    List_GetArrayItem(li.lParam)->dwFlags &= ~QKLIF_BOOKMARK;
                    SendMessageW(g_hLV, LVM_REDRAWITEMS, li.lParam, li.lParam);
                    SendMessageW(hLV, LVM_DELETEITEM, i, 0);
                }
            }
            ///////////////清除现行信息
            SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMNAME), NULL);
            SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCOMMENT), NULL);
            SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCLR), NULL);
            SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMINDEX), NULL);
            if (hbrStatic)
                DeleteObject(hbrStatic);
            hbrStatic = NULL;
        }
        return TRUE;
        case IDC_BT_BMSAVE:
        {
            ///////////////取首选中项
            int i;
            int iCount = SendMessageW(hLV, LVM_GETITEMCOUNT, 0, 0);
            for (i = 0; i < iCount; ++i)
            {
                if (SendMessageW(hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
                    break;
            }
            if (i == iCount)
                return TRUE;
            LVITEMW li;
            li.iItem = i;
            li.iSubItem = 0;
            li.mask = LVIF_PARAM;
            SendMessageW(hLV, LVM_GETITEMW, 0, (LPARAM)&li);
            PLAYERLISTUNIT* p = List_GetArrayItem(li.lParam);
            int iLength;
            ///////////////名称
            iLength = GetWindowTextLengthW(GetDlgItem(hDlg, IDC_ED_BMNAME));
            delete[] p->pszBookMark;
            if (!iLength)
                p->pszBookMark = NULL;
            else
            {
                p->pszBookMark = new WCHAR[iLength + 1];
                GetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMNAME), p->pszBookMark, iLength + 1);
            }
            li.iSubItem = 1;
            li.pszText = p->pszBookMark;
            SendMessageW(hLV, LVM_SETITEMTEXTW, i, (LPARAM)&li);
            ///////////////备注
            iLength = GetWindowTextLengthW(GetDlgItem(hDlg, IDC_ED_BMCOMMENT));
            delete[] p->pszBookMarkComment;
            if (!iLength)
                p->pszBookMarkComment = NULL;
            else
            {
                p->pszBookMarkComment = new WCHAR[iLength + 1];
                GetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCOMMENT), p->pszBookMarkComment, iLength + 1);
            }
            li.iSubItem = 3;
            li.pszText = p->pszBookMarkComment;
            SendMessageW(hLV, LVM_SETITEMTEXTW, i, (LPARAM)&li);
            ///////////////颜色
            PWSTR pszBuf;
            iLength = GetWindowTextLengthW(GetDlgItem(hDlg, IDC_ED_BMCLR));
            pszBuf = new WCHAR[iLength + 1];
            GetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCLR), pszBuf, iLength + 1);
            StrToIntExW(pszBuf, STIF_SUPPORT_HEX, (int*)&p->crBookMark);
            p->crBookMark = QKCommonClrToGDIClr(p->crBookMark);
            li.iSubItem = 2;
            li.pszText = pszBuf;
            SendMessageW(hLV, LVM_SETITEMTEXTW, i, (LPARAM)&li);
            delete[] pszBuf;
        }
        return TRUE;
        case IDC_BT_BMJUMP:// 跳转且不关闭对话框
        {
            int i;
            int iCount = SendMessageW(hLV, LVM_GETITEMCOUNT, 0, 0);
            for (i = 0; i < iCount; ++i)
            {
                if (SendMessageW(hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
                    break;
            }
            if (i == iCount)
                return TRUE;
            LVITEMW li;
            li.iItem = i;
            li.iSubItem = 0;
            li.mask = LVIF_PARAM;
            SendMessageW(hLV, LVM_GETITEMW, 0, (LPARAM)&li);
            SendMessageW(g_hLV, LVM_ENSUREVISIBLE, List_GetArrayItemIndex(li.lParam), FALSE);
        }
        return TRUE;
        case IDC_ST_BMCLR:
        {
            if (HIWORD(wParam) == STN_DBLCLK)// 要求SS_NOTIFY样式；双击静态重新选择颜色
            {
                CHOOSECOLORW cc = { sizeof(CHOOSECOLORW) };
                cc.hwndOwner = hDlg;
                cc.lpCustColors = (COLORREF*)GetPropW(g_hMainWnd, PROP_BOOKMARKCLRDLGBUF);
                cc.Flags = CC_FULLOPEN;
                if (ChooseColorW(&cc))
                {
                    if (hbrStatic)
                        DeleteObject(hbrStatic);
                    hbrStatic = CreateSolidBrush(cc.rgbResult);// 更新静态画刷
                    InvalidateRect(hStatic, NULL, TRUE);
                    WCHAR szBuf[20];
                    wsprintfW(szBuf, L"0x%06X", QKGDIClrToCommonClr(cc.rgbResult));
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCLR), szBuf);// 重设编辑框
                }
            }
        }
        }
    }
    break;
    case WM_CLOSE:
        EndDialog(hDlg, 0);
        return TRUE;
    case WM_DESTROY:
        if (hbrStatic)
            DeleteObject(hbrStatic);
        hbrStatic = NULL;
        return TRUE;
    case WM_NOTIFY:
    {
        if (wParam == IDC_LV_BOOKMARK)
        {
            switch (((NMHDR*)lParam)->code)
            {
            case LVN_ITEMCHANGED:
            {
                NMLISTVIEW* p = (NMLISTVIEW*)lParam;
                if (p->uNewState & LVIS_SELECTED && p->iItem != -1)
                {
                    LVITEMW li;
                    li.iItem = p->iItem;
                    li.mask = LVIF_PARAM;
                    SendMessageW(hLV, LVM_GETITEMW, 0, (LPARAM)&li);
                    PLAYERLISTUNIT* p = List_GetArrayItem(li.lParam);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMNAME), p->pszBookMark);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCOMMENT), p->pszBookMarkComment);
                    if (hbrStatic)
                        DeleteObject(hbrStatic);
                    hbrStatic = CreateSolidBrush(p->crBookMark);
                    InvalidateRect(hStatic, NULL, TRUE);
                    WCHAR szBuf[20];
                    wsprintfW(szBuf, L"0x%06X", QKGDIClrToCommonClr(p->crBookMark));
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCLR), szBuf);
                    wsprintfW(szBuf, L"%d", li.lParam);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMINDEX), szBuf);
                }
                else
                {
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMNAME), NULL);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCOMMENT), NULL);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMCLR), NULL);
                    SetWindowTextW(GetDlgItem(hDlg, IDC_ED_BMINDEX), NULL);
                    if (hbrStatic)
                        DeleteObject(hbrStatic);
                    hbrStatic = NULL;
                    InvalidateRect(hStatic, NULL, TRUE);
                }
            }
            return TRUE;
            case NM_DBLCLK:// 跳转且关闭对话框
                DlgProc_BookMark(hDlg, WM_COMMAND, MAKELONG(IDC_BT_BMJUMP, 0), 0);
                SetFocus(g_hLV);
                EndDialog(hDlg, 0);
                return TRUE;
            }
        }
    }
    break;
    case WM_CTLCOLORSTATIC:// 静态着色
        if (lParam == (LPARAM)hStatic)
            return (INT_PTR)hbrStatic;// 没有画刷的时候画刷句柄为NULL，这时候相当于返回FALSE，也就是使用默认处理
        else
            break;
    }
    return FALSE;
}
void Settings_Read()
{
	WCHAR szBuffer[MAXPROFILEBUFFER];
	UINT u;
	GS.uDefTextCode = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DEFTEXTCODE, 0, g_pszProfie);

	GetPrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_LRCDIR, NULL, szBuffer, MAXPROFILEBUFFER, g_pszProfie);
	delete[] GS.pszLrcDir;
	GS.pszLrcDir = new WCHAR[lstrlenW(szBuffer) + 1];
	lstrcpyW(GS.pszLrcDir, szBuffer);

	GS.bLrcAnimation = !GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DISABLEVANIMATION, FALSE, g_pszProfie);
	GS.bForceTwoLines = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DISABLEWORDBREAK, TRUE, g_pszProfie);
	GS.bDTLrcShandow = !GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DISABLEDTLRCSHANDOW, FALSE, g_pszProfie);

	GetPrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_FONTNAME, L"微软雅黑", szBuffer, MAXPROFILEBUFFER, g_pszProfie);
	delete[] GS.pszDTLrcFontName;
	GS.pszDTLrcFontName = new WCHAR[lstrlenW(szBuffer) + 1];
	lstrcpyW(GS.pszDTLrcFontName, szBuffer);

	GS.uDTLrcFontSize = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_FONTSIZE, 40, g_pszProfie);
	GS.uDTLrcFontWeight = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_FONTWEIGHT, 400, g_pszProfie);

	GS.crDTLrc1 = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DTLRCCLR1, 0x00FF00, g_pszProfie);
	GS.crDTLrc2 = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DTLRCCLR2, 0x0000FF, g_pszProfie);

	GS.uDTLrcTransparent = GetPrivateProfileIntW(PPF_SECTIONLRC, PPF_KEY_DTLRCTRANSPARENT, 0xFF, g_pszProfie);

	GetPrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DTLRCSPACELINE, L"♬♪♬♪♬", szBuffer, MAXPROFILEBUFFER, g_pszProfie);
	delete[] GS.pszDTLrcSpaceLine;
	GS.pszDTLrcSpaceLine = new WCHAR[lstrlenW(szBuffer) + 1];
	lstrcpyW(GS.pszDTLrcSpaceLine, szBuffer);
}
void Settings_Save()
{
    WCHAR sz[MAXPROFILEBUFFER];
    wsprintfW(sz, L"%u", GS.uDefTextCode);
    WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DEFTEXTCODE, sz, g_pszProfie);

    WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_LRCDIR, GS.pszLrcDir, g_pszProfie);

    wsprintfW(sz, L"%u", !GS.bLrcAnimation);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DISABLEVANIMATION, sz, g_pszProfie);

    wsprintfW(sz, L"%u", GS.bForceTwoLines);
    WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DISABLEWORDBREAK, sz, g_pszProfie);

    wsprintfW(sz, L"%u", !GS.bDTLrcShandow);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DISABLEDTLRCSHANDOW, sz, g_pszProfie);

	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_FONTNAME, GS.pszDTLrcFontName, g_pszProfie);

	wsprintfW(sz, L"%u", GS.uDTLrcFontSize);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_FONTSIZE, sz, g_pszProfie);

	wsprintfW(sz, L"%u", GS.uDTLrcFontWeight);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_FONTWEIGHT, sz, g_pszProfie);

	wsprintfW(sz, L"%u", GS.crDTLrc1);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DTLRCCLR1, sz, g_pszProfie);
	wsprintfW(sz, L"%u", GS.crDTLrc2);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DTLRCCLR2, sz, g_pszProfie);

	wsprintfW(sz, L"%u", GS.uDTLrcTransparent);
	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DTLRCTRANSPARENT, sz, g_pszProfie);

	WritePrivateProfileStringW(PPF_SECTIONLRC, PPF_KEY_DTLRCSPACELINE, GS.pszDTLrcSpaceLine, g_pszProfie);
}
INT_PTR CALLBACK DlgProc_Settings2(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HBRUSH hbr1, hbr2;
	static HWND hST1, hST2;
	switch (message)
    {
    case WM_INITDIALOG:
    {
        hST1 = GetDlgItem(hDlg, IDC_ST_DTLRCCLR1);
        hST2 = GetDlgItem(hDlg, IDC_ST_DTLRCCLR2);

        HWND hCtrl = GetDlgItem(hDlg, IDC_CB_DEFTEXTCODE);
        SendMessageW(hCtrl, CB_INSERTSTRING, -1, (LPARAM)L"自动判断（不一定准确）");
        SendMessageW(hCtrl, CB_INSERTSTRING, -1, (LPARAM)L"GBK");
        SendMessageW(hCtrl, CB_INSERTSTRING, -1, (LPARAM)L"UTF-8");
        SendMessageW(hCtrl, CB_INSERTSTRING, -1, (LPARAM)L"UTF-16LE");
        SendMessageW(hCtrl, CB_INSERTSTRING, -1, (LPARAM)L"UTF-16BE");
        SendMessageW(hCtrl, CB_SETCURSEL, GS.uDefTextCode, 0);

        SetDlgItemTextW(hDlg, IDC_ED_LRCDIR, GS.pszLrcDir);

        SendDlgItemMessageW(hDlg, IDC_CB_DISABLEVANIMATION, BM_SETCHECK, GS.bLrcAnimation ? BST_UNCHECKED : BST_CHECKED, 0);
        SendDlgItemMessageW(hDlg, IDC_CB_DISABLEWORDBREAK, BM_SETCHECK, GS.bForceTwoLines ? BST_CHECKED : BST_UNCHECKED, 0);
        SendDlgItemMessageW(hDlg, IDC_CB_DISABLEDTLRCSHANDOW, BM_SETCHECK, GS.bDTLrcShandow ? BST_UNCHECKED : BST_CHECKED, 0);

        SetDlgItemTextW(hDlg, IDC_ED_DTLRCFONTINFO, GS.pszDTLrcFontName);

        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_SETSEL, -2, -1);
        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_REPLACESEL, FALSE, (LPARAM)L",");

        WCHAR sz[10];
        wsprintfW(sz, L"%u", GS.uDTLrcFontSize);
        SetPropW(GetDlgItem(hDlg, IDC_ED_DTLRCFONTINFO), PROP_DTLRCFONTSIZE, (HANDLE)GS.uDTLrcFontSize);
        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_SETSEL, -2, -1);
        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_REPLACESEL, FALSE, (LPARAM)sz);

        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_SETSEL, -2, -1);
        SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_REPLACESEL, FALSE, (LPARAM)L",");

		wsprintfW(sz, L"%u", GS.uDTLrcFontWeight);
        SetPropW(GetDlgItem(hDlg, IDC_ED_DTLRCFONTINFO), PROP_DTLRCFONTWEIGHT, (HANDLE)GS.uDTLrcFontWeight);
		SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_SETSEL, -2, -1);
		SendDlgItemMessageW(hDlg, IDC_ED_DTLRCFONTINFO, EM_REPLACESEL, FALSE, (LPARAM)sz);

		hbr1 = CreateSolidBrush(QKCommonClrToGDIClr(GS.crDTLrc1));
		hbr2 = CreateSolidBrush(QKCommonClrToGDIClr(GS.crDTLrc2));
        SetPropW(GetDlgItem(hDlg, IDC_ST_DTLRCCLR1), PROP_DTLRCCLR1, (HANDLE)GS.crDTLrc1);
        SetPropW(GetDlgItem(hDlg, IDC_ST_DTLRCCLR2), PROP_DTLRCCLR2, (HANDLE)GS.crDTLrc2);

        SendDlgItemMessageW(hDlg, IDC_TB_DTLRCTRANSPARENT, TBM_SETRANGE, FALSE, MAKELPARAM(0, 0xFF));
        SendDlgItemMessageW(hDlg, IDC_TB_DTLRCTRANSPARENT, TBM_SETPOS, TRUE, GS.uDTLrcTransparent);

        SetDlgItemTextW(hDlg, IDC_ED_DTLRCSPACELINE, GS.pszDTLrcSpaceLine);

        DlgProc_Settings2(hDlg, WM_COMMAND, MAKEWPARAM(IDC_BT_REFRESHDEV, BN_CLICKED), 0);
	}
	return FALSE;
    case WM_NCPAINT:
        return TRUE;
    case WM_COMMAND:
    {
        switch (HIWORD(wParam))
        {
        case CBN_SELCHANGE:
        {
            BASS_Init(SendMessageW((HWND)lParam, CB_GETCURSEL, 0, 0) + 1, 44100, BASS_DEVICE_REINIT, g_hMainWnd, NULL);
        }
        case BN_CLICKED:
        {
            switch (LOWORD(wParam))
            {
            case IDC_BT_CHANGELRCDIR:
            {
                IFileOpenDialog* pfod;
                HRESULT hr = CoCreateInstance(CLSID_FileOpenDialog,
                    NULL,
                    CLSCTX_INPROC_SERVER,
                    IID_PPV_ARGS(&pfod));
                if (!SUCCEEDED(hr))
                    return 0;
                pfod->SetOptions(FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST);
                pfod->Show(hDlg);
                IShellItem* psi;
                hr = pfod->GetResult(&psi);
                if (!SUCCEEDED(hr))
                {
                    pfod->Release();
                    return 0;
                }
                LPWSTR pszPath;
                hr = psi->GetDisplayName(SIGDN_DESKTOPABSOLUTEPARSING, &pszPath);
                psi->Release();
                pfod->Release();
                if (!SUCCEEDED(hr))
                    return 0;
                SetDlgItemTextW(hDlg, IDC_ED_LRCDIR, pszPath);
                CoTaskMemFree(pszPath);
            }
            return TRUE;
            case IDC_BT_CHANGEFONT:
            {
                LOGFONTW lf = { 0 };
                CHOOSEFONTW cf = { 0 };
                cf.lStructSize = sizeof(CHOOSEFONTW);
                cf.hwndOwner = hDlg;
                cf.lpLogFont = &lf;
                cf.Flags = CF_INITTOLOGFONTSTRUCT | CF_SCREENFONTS | CF_EFFECTS | CF_FORCEFONTEXIST | CF_NOVERTFONTS;

            }
            return TRUE;
            case IDC_BT_REFRESHDEV:
            {
                BASS_DEVICEINFO DevInfo;
                PWSTR psz;
                DWORD dwCurrDev = BASS_GetDevice();
                for (DWORD i = 1; BASS_GetDeviceInfo(i, &DevInfo); ++i)
                {
                    int iBufferSize = MultiByteToWideChar(CP_ACP, 0, DevInfo.name, -1, NULL, 0);
                    if (iBufferSize)
                    {
                        psz = new WCHAR[iBufferSize];//包含结尾NULL
                        MultiByteToWideChar(CP_ACP, 0, DevInfo.name, -1, psz, iBufferSize);
                    }
                    else
                        psz = NULL;

                    SendDlgItemMessageW(hDlg, IDC_CB_DEVICES, CB_INSERTSTRING, -1, (LPARAM)psz);
                    delete[] psz;
                }

                SendDlgItemMessageW(hDlg, IDC_CB_DEVICES, CB_SETCURSEL, BASS_GetDevice() - 1, 0);
            }
            return TRUE;
            }
        }
        }
    }
    return TRUE;
    case WM_CTLCOLORSTATIC:
    {
        if (lParam == (LPARAM)hST1)
            return (LRESULT)hbr1;
        else if (lParam == (LPARAM)hST2)
            return (LRESULT)hbr2;
    }
    return NULL;
    }
    return FALSE;
}
INT_PTR CALLBACK DlgProc_Settings(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hWnd;
	switch (message)
	{
	case WM_INITDIALOG:
	{
		int iGap = DPI(50);
		int cxClient;
		int cyClient;
		RECT rc;
		GetClientRect(hDlg, &rc);
		cxClient = rc.right;
		cyClient = rc.bottom;

		hWnd = CreateDialogParamW(g_hInst, MAKEINTRESOURCEW(IDD_OPTIONS2), NULL, DlgProc_Settings2, 0);
		GetClientRect(hWnd, &rc);
		SetParent(hWnd, hDlg);
		SetWindowPos(hWnd, NULL, 0, 0, rc.right, cyClient - iGap, SWP_NOZORDER);
		SetWindowLongPtrW(hWnd, GWL_STYLE, WS_CHILD);
		ShowWindow(hWnd, SW_SHOW);

		HWND hCtrl = GetDlgItem(hDlg, IDC_SB_SETTINGS);
		SetWindowPos(hCtrl, NULL, rc.right, 0, cxClient - rc.right, cyClient - iGap, SWP_NOZORDER);
		SCROLLINFO si;
		si.cbSize = sizeof(SCROLLINFO);
		si.fMask = SIF_ALL;
		si.nPos = 0;
		si.nMax = rc.bottom;
		si.nMin = 0;
		si.nPage = cyClient - iGap;
		SetScrollInfo(hCtrl, SB_CTL, &si, TRUE);
	}
	return FALSE;
	case WM_COMMAND:
	{
		switch (LOWORD(wParam))
		{
		case IDOK:
		{
			GS.uDefTextCode = SendDlgItemMessageW(hWnd, IDC_CB_DEFTEXTCODE, CB_GETCURSEL, 0, 0);

			delete[] GS.pszLrcDir;
			int iLength = GetWindowTextLengthW(GetDlgItem(hWnd, IDC_ED_LRCDIR));
			GS.pszLrcDir = new WCHAR[iLength + 1];
			GetDlgItemTextW(hWnd, IDC_ED_LRCDIR, GS.pszLrcDir, iLength + 1);

            GS.bLrcAnimation = !(SendDlgItemMessageW(hWnd, IDC_CB_DISABLEVANIMATION, BM_GETCHECK, 0, 0) == BST_CHECKED);
            GS.bForceTwoLines = (SendDlgItemMessageW(hWnd, IDC_CB_DISABLEWORDBREAK, BM_GETCHECK, 0, 0) == BST_CHECKED);
            GS.bDTLrcShandow = !(SendDlgItemMessageW(hWnd, IDC_CB_DISABLEDTLRCSHANDOW, BM_GETCHECK, 0, 0) == BST_CHECKED);

            delete[] GS.pszDTLrcFontName;
            iLength = GetWindowTextLengthW(GetDlgItem(hWnd, IDC_ED_FONTINFO));
            GS.pszDTLrcFontName = new WCHAR[iLength + 1];
            GetDlgItemTextW(hWnd, IDC_ED_FONTINFO, GS.pszDTLrcFontName, iLength + 1);

            int iPos = QKStrInStr(GS.pszDTLrcFontName, L",");
			*(GS.pszDTLrcFontName + iPos - 1) = L'\0';
            GS.uDTLrcFontSize = (UINT)GetPropW(GetDlgItem(hWnd, IDC_ED_DTLRCFONTINFO), PROP_DTLRCFONTSIZE);
            GS.uDTLrcFontWeight = (UINT)GetPropW(GetDlgItem(hWnd, IDC_ED_DTLRCFONTINFO), PROP_DTLRCFONTWEIGHT);

            GS.crDTLrc1 = (COLORREF)GetPropW(GetDlgItem(hWnd, IDC_ST_DTLRCCLR1), PROP_DTLRCCLR1);
            GS.crDTLrc2 = (COLORREF)GetPropW(GetDlgItem(hWnd, IDC_ST_DTLRCCLR2), PROP_DTLRCCLR2);

            GS.uDTLrcTransparent = SendDlgItemMessageW(hWnd, IDC_TB_DTLRCTRANSPARENT, TBM_GETPOS, 0, 0);
            delete[] GS.pszDTLrcSpaceLine;
            iLength = GetWindowTextLengthW(GetDlgItem(hWnd, IDC_ED_DTLRCSPACELINE));
            GS.pszDTLrcSpaceLine = new WCHAR[iLength + 1];
            GetDlgItemTextW(hWnd, IDC_ED_DTLRCSPACELINE, GS.pszDTLrcSpaceLine, iLength + 1);

			Settings_Save();
			EndDialog(hDlg, 0);
		}
		return TRUE;
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return TRUE;
		}

	}
	return TRUE;
	case WM_MOUSEWHEEL:
	{
		int iDistance = -GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA;

		int iPos;
		SCROLLINFO si;
		si.cbSize = sizeof(SCROLLINFO);
		si.fMask = SIF_ALL;
		GetScrollInfo(GetDlgItem(hDlg, IDC_SB_SETTINGS), SB_CTL, &si);
		iPos = si.nPos;
		si.nPos += (si.nPage / 3 * iDistance);
		if (si.nPos < 0)
			si.nPos = 0;
		else if (si.nPos > si.nMax - si.nPage)
			si.nPos = si.nMax - si.nPage;

		SetScrollPos(GetDlgItem(hDlg, IDC_SB_SETTINGS), SB_CTL, si.nPos, TRUE);
		ScrollWindow(hWnd, 0, iPos - si.nPos, NULL, NULL);
	}
	return TRUE;
	case WM_VSCROLL:
	{
		int iPos;
		SCROLLINFO si;
		si.cbSize = sizeof(SCROLLINFO);
		si.fMask = SIF_ALL;
		GetScrollInfo((HWND)lParam, SB_CTL, &si);
		iPos = si.nPos;
		switch (LOWORD(wParam))
		{
		case SB_LEFT:
			si.nPos = 0;
			break;
		case SB_RIGHT:
			si.nPos = si.nMax;
			break;
		case SB_LINELEFT:
			si.nPos--;
			break;
		case SB_LINERIGHT:
			si.nPos++;
			break;
		case SB_PAGELEFT:
			si.nPos -= si.nPage;
			break;
		case SB_PAGERIGHT:
			si.nPos += si.nPage;
			break;
		case SB_THUMBTRACK:
			si.nPos = si.nTrackPos;
			break;
		}

		SetScrollPos((HWND)lParam, SB_CTL, si.nPos, TRUE);
		ScrollWindow(hWnd, 0, iPos - si.nPos, NULL, NULL);
	}
	return TRUE;
	case WM_CLOSE:
		EndDialog(hDlg, 0);
		return TRUE;
	}
	return FALSE;
}
// 输入相对坐标，返回按钮索引
int BtmBK_HitTest(int x, int y)
{
    if (x < DPIS_CXTIME || y < 0 || x > DPIS_CXBTMBTBK || y > DPIS_BT)
        return -1;

    for (int i = 0; i < 9; i++)
    {
        if (x > DPIS_CXTIME + i * DPIS_BT && x < DPIS_CXTIME + (i + 1) * DPIS_BT)
            return i;
    }
    return -1;
}
LRESULT CALLBACK WndProc_BtmBK(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) 
{
    static WCHAR szTime[20] = L"00:00/00:00";
    static int iRepeatMode = REPEATMODE_TOTALLOOP;
    static RECT rcTimeText = { 0,0,DPIS_CXTIME,DPIS_BT };
    static int iHot = -1, iPushed = -1, iLastHot = -1, iLastOver = -1;
    static BOOL bBTPLPushed = FALSE, bBTIGPushed = FALSE;
    static HWND hToolTip;
    static BOOL bLBTDown = FALSE;
    static TTTOOLINFOW ti = { sizeof(TTTOOLINFOW),0,hWnd,1 };
    static HWND hDlg = NULL;
    static int i;
    static HDC hCDC;
    static HBITMAP hBitmap;
    switch (message)
    {
    case BTMBKM_INIT:
    {
        hToolTip = CreateWindowExW(0, TOOLTIPS_CLASSW, NULL, 0, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);
        RECT rc;
        GetClientRect(hWnd, &rc);
        ti.rect = rc;
        ti.uFlags = TTF_SUBCLASS;
        SendMessageW(hToolTip, TTM_ADDTOOLW, 0, (LPARAM)&ti);
        SendMessageW(hToolTip, TTM_POP, 0, 0);
        SetTimer(hWnd, IDT_PGS, TIMERELAPSE_PGS, NULL);

        HDC hDC = GetDC(hWnd);
        hBitmap = CreateCompatibleBitmap(hDC, DPIS_CXBTMBTBK, DPIS_BT);
        hCDC = CreateCompatibleDC(hDC);
        ReleaseDC(hWnd, hDC);
        SelectObject(hCDC, hBitmap);
        BitBlt(hCDC, 0, 0, DPIS_CXBTMBTBK, DPIS_BT, m_hcdcLeftBK, m_xBtmBK, m_yBtmBK, SRCCOPY);
        SelectObject(hCDC, g_hFont);
        SetBkMode(hCDC, TRANSPARENT);
    }
    return 0;
    case BTMBKM_GETREPEATMODE:
        return iRepeatMode;
    case BTMBKM_SETPLAYBTICON:
    {
        g_bPlayIcon = wParam;
        if (g_bPlayIcon)
        {
            THUMBBUTTON tb;
            tb.dwMask = THB_ICON | THB_TOOLTIP;
            tb.hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(IDI_PLAY_TB));
            tb.iId = IDTBB_PLAY;
            lstrcpyW(tb.szTip, L"播放");
            if (g_pITaskbarList)
                g_pITaskbarList->ThumbBarUpdateButtons(m_hTBGhost, 1, &tb);
            BASS_ChannelPause(g_hStream);
            KillTimer(g_hMainWnd, IDT_DRAWING_LRC);
            KillTimer(g_hMainWnd, IDT_DRAWING_SPE);
            KillTimer(g_hMainWnd, IDT_DRAWING_WAVES);
            KillTimer(hWnd, IDT_PGS);
        }
        else
        {
            THUMBBUTTON tb;
            tb.dwMask = THB_ICON | THB_TOOLTIP;
            tb.hIcon = LoadIconW(g_hInst, MAKEINTRESOURCEW(IDI_PAUSE_TB));
            tb.iId = IDTBB_PLAY;
            lstrcpyW(tb.szTip, L"暂停");
            if (g_pITaskbarList)
                g_pITaskbarList->ThumbBarUpdateButtons(m_hTBGhost, 1, &tb);
            BASS_ChannelPlay(g_hStream, FALSE);
            SetTimer(g_hMainWnd, IDT_DRAWING_LRC, TIMERELAPSE_LRC, TimerProc);
            SetTimer(g_hMainWnd, IDT_DRAWING_SPE, TIMERELAPSE_VU_SPE, TimerProc);
            SetTimer(g_hMainWnd, IDT_DRAWING_WAVES, TIMERELAPSE_WAVES, TimerProc);
            SetTimer(hWnd, IDT_PGS, TIMERELAPSE_PGS, NULL);
        }

        InvalidateRect(hWnd, NULL, FALSE);
        UpdateWindow(hWnd);
        LrcWnd_DrawLrc();
    }
    return 0;
    case BTMBKM_DOBTOPE:
        switch (wParam)
        {
        case 0:goto BTOpe_Last;
        case 1:goto BTOpe_Play;
        case 2:goto BTOpe_Next;
        }
        return 0;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hDC = BeginPaint(hWnd, &ps);
        BitBlt(hCDC, 0, 0, DPIS_CXBTMBTBK, DPIS_BT, m_hcdcLeftBK, m_xBtmBK, m_yBtmBK, SRCCOPY);
        DrawTextW(hCDC, szTime, -1, &rcTimeText, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
        int x = rcTimeText.right + 3;
        int iIconOffest = (DPIS_BT - SIZE_STDICON) / 2;
        HBRUSH hBrush;
        RECT rc = { 0,0,0,DPIS_BT };
        if (iHot != -1 || iPushed != -1)
        {
            int i;
            if (iPushed != -1)
            {
                i = iPushed;
                hBrush = CreateSolidBrush(MYCLR_BTPUSHED);
            }
            else
            {
                i = iHot;
                hBrush = CreateSolidBrush(MYCLR_BTHOT);
            }
            rc.left = x + DPIS_BT * i;
            rc.right = rc.left + DPIS_BT;
            FillRect(hCDC, &rc, hBrush);
            DeleteObject(hBrush);
        }
        

        DrawIconEx(hCDC, x+ iIconOffest, iIconOffest, GR.hiBTLast, 0, 0, 0, NULL, DI_NORMAL);// 1 上一曲
        x += DPIS_BT;
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, g_bPlayIcon ? GR.hiBTPlay : GR.hiBTPause, 0, 0, 0, NULL, DI_NORMAL);// 2 播放/暂停
        x += DPIS_BT;
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTStop, 0, 0, 0, NULL, DI_NORMAL);// 3 停止
        x += DPIS_BT;
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTNext, 0, 0, 0, NULL, DI_NORMAL);// 4 下一曲
        x += DPIS_BT;
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTLrc, 0, 0, 0, NULL, DI_NORMAL);// 5 歌词
        x += DPIS_BT;
        HICON hi;
        switch (iRepeatMode)
        {
        case REPEATMODE_TOTALLOOP:
            hi = GR.hiRMTotalLoop;
            break;
        case REPEATMODE_RADOM:
            hi = GR.hiRMRadom;
            break;
        case REPEATMODE_SINGLE:
            hi = GR.hiRMSingle;
            break;
        case REPEATMODE_SINGLELOOP:
            hi = GR.hiRMSingleLoop;
            break;
        case REPEATMODE_TOTAL:
            hi = GR.hiRMTotal;
            break;
        default:
            hi = GR.hiRMTotalLoop;
            break;
        }

        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, hi, 0, 0, 0, NULL, DI_NORMAL);// 6 循环方式
        x += DPIS_BT;

        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTPlaySetting, 0, 0, 0, NULL, DI_NORMAL);// 7 均衡器
        x += DPIS_BT;
        if (bBTPLPushed)
        {
            hBrush = CreateSolidBrush(MYCLR_BTPUSHED);
            rc.left = x;
            rc.right = rc.left + DPIS_BT;
            FillRect(hCDC, &rc, hBrush);
            DeleteObject(hBrush);
        }
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTPlayList, 0, 0, 0, NULL, DI_NORMAL);// 8 显示播放列表
        x += DPIS_BT;
        if (bBTPLPushed)
        {
            hBrush = CreateSolidBrush(MYCLR_BTPUSHED);
            rc.left = x;
            rc.right = rc.left + DPIS_BT;
            FillRect(hCDC, &rc, hBrush);
            DeleteObject(hBrush);
        }
        DrawIconEx(hCDC, x + iIconOffest, iIconOffest, GR.hiBTMore, 0, 0, 0, NULL, DI_NORMAL);// 9 更多
        x += DPIS_BT;
        BitBlt(hDC, 0, 0, DPIS_CXBTMBTBK, DPIS_BT, hCDC, 0, 0, SRCCOPY);

        EndPaint(hWnd, &ps);
    }
    return 0;
    case WM_MOUSEMOVE:
    {
        if (!bLBTDown)
        {
            iHot = BtmBK_HitTest(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
            if (iLastHot != iHot)
            {
                ti.lpszText = NULL;
                SendMessageW(hToolTip, TTM_GETTOOLINFOW, 0, (LPARAM)&ti);
                SendMessageW(hToolTip, TTM_SETTOOLINFOW, 0, (LPARAM)&ti);
                iLastHot = iHot;
                InvalidateRect(hWnd, NULL, FALSE);
            }
            TRACKMOUSEEVENT tme;
            tme.cbSize = sizeof(tme);
            tme.hwndTrack = hWnd;
            tme.dwFlags = TME_LEAVE | TME_HOVER;
            tme.dwHoverTime = 200;
            TrackMouseEvent(&tme);
        }
    }
    return 0;
    case WM_MOUSEHOVER:
    {
        if (iHot != -1 && iPushed == -1 && iLastOver != iHot)
        {
        ShowToolTip:
            iLastOver = iHot;
            ti.lpszText = NULL;
            SendMessageW(hToolTip, TTM_GETTOOLINFOW, 0, (LPARAM)&ti);
            if (iHot == 5)
                ti.lpszText = (LPWSTR)c_szBtmTip[10 + iRepeatMode];
            else
                ti.lpszText = (LPWSTR)c_szBtmTip[iHot];
            SendMessageW(hToolTip, TTM_SETTOOLINFOW, 0, (LPARAM)&ti);
            SendMessageW(hToolTip, TTM_POPUP, 0, 0);
        }
    }
    return 0;
    case WM_MOUSELEAVE:
    {
        if (iHot != -1)
        {
            ti.lpszText = NULL;
            SendMessageW(hToolTip, TTM_GETTOOLINFOW, 0, (LPARAM)&ti);
            SendMessageW(hToolTip, TTM_SETTOOLINFOW, 0, (LPARAM)&ti);
            iLastHot = iHot = -1;
            InvalidateRect(hWnd, NULL, FALSE);
        }
    }
    return 0;
    case WM_LBUTTONDOWN:
    {
        SetCapture(hWnd);
        iPushed = BtmBK_HitTest(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        if (iPushed == -1)
            ReleaseCapture();
        else
        {
            InvalidateRect(hWnd, NULL, FALSE);
            UpdateWindow(hWnd);
        }
    }
    return 0;
    case WM_LBUTTONUP:
    {
        ReleaseCapture();
        if (iPushed == -1)
            return 0;
        i = iPushed;
        iPushed = -1;
        if (i != BtmBK_HitTest(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam)))
            return 0;
        ti.lpszText = NULL;
        SendMessageW(hToolTip, TTM_GETTOOLINFOW, 0, (LPARAM)&ti);
        SendMessageW(hToolTip, TTM_SETTOOLINFOW, 0, (LPARAM)&ti);
        InvalidateRect(hWnd, NULL, FALSE);
        UpdateWindow(hWnd);
        switch (i)
        {
        case 0://上一曲
        BTOpe_Last:
        {
            if (g_iCurrFileIndex == -1)
                return 0;
            PlayNext(TRUE);
        }
        break;
        case 1://播放/暂停
        BTOpe_Play:
        {
            if (g_iCurrFileIndex == -1)
                return 0;
            DWORD dwState = BASS_ChannelIsActive(g_hStream);
            if (dwState == BASS_ACTIVE_PLAYING)
                WndProc_BtmBK(hWnd, BTMBKM_SETPLAYBTICON, TRUE, 0);
            else if (dwState == BASS_ACTIVE_PAUSED)
                WndProc_BtmBK(hWnd, BTMBKM_SETPLAYBTICON, FALSE, 0);
        }
        break;
        case 2://停止
            if (g_iCurrFileIndex == -1)
                return 0;
            Stop();
            break;
        case 3://下一曲
        BTOpe_Next:
            if (g_iCurrFileIndex == -1)
                return 0;
            PlayNext();
            break;
        case 4://歌词
        {
            HMENU hMenu = CreatePopupMenu();
			AppendMenuW(hMenu, IsWindow(g_hLrcWnd) ? MF_CHECKED : 0, IDMI_LRC_SHOW, L"桌面歌词");
			AppendMenuW(hMenu, m_bLrcShow ? MF_CHECKED : 0, IDMI_LRC_LRCSHOW, L"滚动歌词");
			AppendMenuW(hMenu, GS.bForceTwoLines ? MF_CHECKED : 0, IDMI_LRC_FORCETWOLINES, L"禁止自动换行");
            RECT rc;
            GetWindowRect(g_hBKBtm, &rc);
            int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, rc.left + DPIS_CXTIME + DPIS_BT * 4, rc.top + DPIS_BT, 0, g_hMainWnd, NULL);
            DestroyMenu(hMenu);
            switch (iRet)
            {
            case IDMI_LRC_SHOW:
            {
                LrcWnd_Show();
            }
            break;
            case IDMI_LRC_LRCSHOW:
            {
                m_bLrcShow = !m_bLrcShow;
                RECT rc;
                GetClientRect(g_hBKLeft, &rc);
                SendMessageW(g_hBKLeft, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
            }
            break;
            case IDMI_LRC_FORCETWOLINES:
            {
                if (GS.bForceTwoLines)
                {
                    GS.bForceTwoLines = FALSE;
                    KillTimer(g_hMainWnd, IDT_ANIMATION);
                }
                else
                    GS.bForceTwoLines = TRUE;

                m_IsDraw[2] = TRUE;
                TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
            }
            break;
            }
        }
        break;
        case 5://循环方式
            iRepeatMode++;
            if (iRepeatMode > 4)
                iRepeatMode %= 5;
            InvalidateRect(hWnd, NULL, FALSE);
            goto ShowToolTip;
            break;
        case 6://播放设置
            if (!IsWindow(hDlg))
            {
                hDlg = CreateDialogParamW(g_hInst, MAKEINTRESOURCEW(IDD_EFFECT), hWnd, DlgProc_Effect, 0);
                ShowWindow(hDlg, SW_SHOW);
            }
            else
                SetFocus(hDlg);
            break;
		case 7://播放列表
		{
			HMENU hMenu = CreatePopupMenu();
			AppendMenuW(hMenu, g_bListSeped ? MF_CHECKED : 0, IDMI_PL_SEPARATE, L"将列表从主窗口拆离");//MF_STRING缺省
			AppendMenuW(hMenu, g_bListHidden ? 0 : MF_CHECKED, IDMI_PL_SHOW, L"显示播放列表");
			RECT rc;
			GetWindowRect(g_hBKBtm, &rc);
			int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, rc.left + DPIS_CXTIME + DPIS_BT * 8, rc.top + DPIS_BT, 0, g_hMainWnd, NULL);
			DestroyMenu(hMenu);
			switch (iRet)
			{
			case IDMI_PL_SEPARATE:
				UI_SeparateListWnd(!g_bListSeped);
				break;
			case IDMI_PL_SHOW:
				UI_ShowList(g_bListHidden);
				break;
			}
		}
		break;
		case 8://更多
		{
            HMENU hMenu = CreatePopupMenu();
            AppendMenuW(hMenu, 0, IDMI_MORE_SETTING, L"设置");//MF_STRING缺省
            AppendMenuW(hMenu, 0, IDMI_MORE_ABOUT, L"关于");
            RECT rc;
            GetWindowRect(g_hBKBtm, &rc);
            int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, rc.left + DPIS_CXTIME + DPIS_BT * 8, rc.top + DPIS_BT, 0, g_hMainWnd, NULL);
            DestroyMenu(hMenu);
            switch (iRet)
            {
            case IDMI_MORE_ABOUT:
                DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_ABOUT), g_hMainWnd, DlgProc_About, 0);
                return 0;
            case IDMI_MORE_SETTING:
                DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_OPTIONS), g_hMainWnd, DlgProc_Settings, 0);
                return 0;
            }
        }
        break;
        }
    }
    return 0;
    case WM_DESTROY:
    {
        DestroyWindow(hToolTip);
        DeleteDC(hCDC);
        DeleteObject(hBitmap);
    }
    return 0;
    case WM_TIMER:
    {
        if (!g_hStream)
            return 0;
        int iMin = g_fTime / 60,
            iMin2 = m_llLength / 1000 / 60;

        wsprintfW(szTime, L"%02d:%02d/%02d:%02d",
            iMin,
            (int)g_fTime - iMin * 60,
            iMin2,
            (int)(m_llLength / 1000) - iMin2 * 60);

        BitBlt(hCDC, 0, 0, rcTimeText.right, rcTimeText.bottom, m_hcdcLeftBK, m_xBtmBK, m_yBtmBK, SRCCOPY);
        DrawTextW(hCDC, szTime, -1, &rcTimeText, DT_RIGHT | DT_SINGLELINE | DT_VCENTER);
        HDC hDC = GetDC(hWnd);
        BitBlt(hDC, 0, 0, rcTimeText.right, rcTimeText.bottom, hCDC, rcTimeText.left, rcTimeText.top, SRCCOPY);
        ReleaseDC(hWnd, hDC);

        SendMessageW(g_hTBProgess, QKCTBM_SETPOS, TRUE, (LPARAM)g_fTime * 100);
        if (g_pITaskbarList)
            g_pITaskbarList->SetProgressValue(g_hMainWnd, (ULONGLONG)g_fTime * 100, (ULONGLONG)m_llLength / 10);

        m_TimeStru_VU[1].uTime += 500;
        if (m_TimeStru_VU[1].uTime >= 1000)
        {
            m_TimeStru_VU[1].bbool = TRUE;
            m_TimeStru_VU[1].uTime = 0;
        }
    }
    return 0;
    }
    return DefWindowProcW(hWnd, message, wParam, lParam);
}
LRESULT CALLBACK WndProc_RitBK(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)//右上容器窗口过程
{
    static WCHAR szListName[MAX_PATH];
    switch (message)
    {
    case WM_COMMAND:
    {
        if (lParam)
        {
            switch (LOWORD(wParam))
            {
            case IDC_BT_JUMP:
            {
                if (g_iCurrFileIndex != -1)
                {
                    SendMessageW(g_hLV, LVM_ENSUREVISIBLE, g_iCurrFileIndex, FALSE);
                    SetFocus(g_hLV);
                }
            }
            return 0;
            case IDC_BT_OPEN:
            {
                HMENU hMenu = CreatePopupMenu();
                UINT uFlags = m_bSort || m_iSearchResult != -1 ? MF_GRAYED : 0;
                AppendMenuW(hMenu, uFlags, IDMI_OPEN_FILE, L"打开文件");//MF_STRING缺省
                AppendMenuW(hMenu, uFlags, IDMI_OPEN_FOLDER, L"打开文件夹");

                RECT rc;
                GetWindowRect((HWND)lParam, &rc);
                int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, rc.left, rc.bottom, 0, g_hMainWnd, NULL);
                DestroyMenu(hMenu);
                int iIndex = -1;
				for (int i = 0; i < g_ItemData->iCount; ++i)
                {
                    if (SendMessageW(g_hLV, LVM_GETITEMSTATE, i, LVIS_SELECTED) == LVIS_SELECTED)
                    {
                        iIndex = i;
                        break;
                    }
                }
                switch (iRet)
                {
                case IDMI_OPEN_FILE:
                {
                    IFileOpenDialog* pfod;
                    HRESULT hr = CoCreateInstance(CLSID_FileOpenDialog,
                        NULL,
                        CLSCTX_INPROC_SERVER,
                        IID_PPV_ARGS(&pfod));
                    if (!SUCCEEDED(hr))
                        return 0;
                    pfod->SetTitle(L"打开音频文件");
                    pfod->SetOptions(FOS_ALLOWMULTISELECT | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST);
                    COMDLG_FILTERSPEC cf[] =
                    {
                        {L"音频文件(*.mp1;*.mp2;*.xm;*.mp3;*.flac;*.wma;*.wav;*.m4a;*.ogg;*.acc;*.ape;*.aiff)",
                        L"*.mp1;*.mp2;*.xm;*.mp3;*.flac;*.wma;*.wav;*.m4a;*.ogg;*.acc;*.ape;*.aiff"},
                        {L"所有文件",L"*.*"}
                    };
                    pfod->SetFileTypes(2, cf);
                    pfod->Show(hWnd);
                    IShellItemArray* psia;
                    hr = pfod->GetResults(&psia);
                    if (!SUCCEEDED(hr))
                    {
                        pfod->Release();
                        return 0;
                    }
                    DWORD cItem;
                    hr = psia->GetCount(&cItem);
                    if (!SUCCEEDED(hr))
                    {
                        psia->Release();
                        pfod->Release();
                        return 0;
                    }
                    IShellItem* psi;
                    LPWSTR pszFile;
                    List_SetRedraw(FALSE);
                    DWORD dwExitCode;
                    if (GetExitCodeThread(m_hThread[1], &dwExitCode))
                        StopThread_MusicTime();
                    else
                        dwExitCode = 0;

					if (iIndex <= g_iCurrFileIndex && g_iCurrFileIndex != -1 && cItem)
                        g_iCurrFileIndex += cItem;

                    for (DWORD i = 0; i < cItem; i++)
                    {
                        psia->GetItemAt(i, &psi);
                        psi->GetDisplayName(SIGDN_DESKTOPABSOLUTEPARSING, &pszFile);
                        List_Add(pszFile, NULL, iIndex, FALSE);
                        ++iIndex;
                        CoTaskMemFree(pszFile);
                        psi->Release();
                    }

                    psia->Release();
                    pfod->Release();
                    List_SetRedraw(TRUE);
                    List_ResetLV();
                    List_FillMusicTimeColumn(TRUE);
                }
                return 0;
                case IDMI_OPEN_FOLDER:
                {
                    IFileOpenDialog* pfod;
                    HRESULT hr = CoCreateInstance(CLSID_FileOpenDialog,
                        NULL,
                        CLSCTX_INPROC_SERVER,
                        IID_PPV_ARGS(&pfod));
                    if (!SUCCEEDED(hr))
                        return 0;
                    pfod->SetOptions(FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST);
                    pfod->Show(hWnd);
                    IShellItem* psi;
                    hr = pfod->GetResult(&psi);
                    if (!SUCCEEDED(hr))
                    {
                        pfod->Release();
                        return 0;
                    }
                    LPWSTR pszPath;
                    hr = psi->GetDisplayName(SIGDN_DESKTOPABSOLUTEPARSING, &pszPath);
                    psi->Release();
                    pfod->Release();
                    if (!SUCCEEDED(hr))
                        return 0;
                    WIN32_FIND_DATAW wfd;
                    WCHAR szFile[MAX_PATH];
                    lstrcpyW(szFile, pszPath);
                    lstrcatW(szFile, L"\\*.mp3");
                    HANDLE hFind = FindFirstFileW(szFile, &wfd);//开始枚举
                    if (hFind == INVALID_HANDLE_VALUE)
                        return 0;
                    List_SetRedraw(FALSE);
                    DWORD dwExitCode;
                    if (GetExitCodeThread(m_hThread[1], &dwExitCode))
                        StopThread_MusicTime();
                    else
                        dwExitCode = 0;

                    int cItem = 0;
                    do
                    {
                        lstrcpyW(szFile, pszPath);
                        lstrcatW(szFile, L"\\");
                        lstrcatW(szFile, wfd.cFileName);
                        List_Add(szFile, NULL, iIndex, FALSE);
                        ++cItem;
                        ++iIndex;
                    } while (FindNextFileW(hFind, &wfd));//继续枚举
                    if (cItem)
                    {
						if (iIndex - cItem <= g_iCurrFileIndex && g_iCurrFileIndex != -1)
                            g_iCurrFileIndex += cItem;
                    }

                    FindClose(hFind);//释放
                    CoTaskMemFree(pszPath);
                    List_SetRedraw(TRUE);
                    List_ResetLV();
                    List_FillMusicTimeColumn(TRUE);
                }
                return 0;
                }
            }
            return 0;
            case IDC_BT_LOADLIST:
            {
                INT_PTR pResult = DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_LIST), g_hMainWnd, DlgProc_List, DLGTYPE_LOADLIST);
                if (pResult == NULL)
                    return 0;

                lstrcpyW(szListName, ((DLGRESULT_LIST*)pResult)->szFileName);

                HANDLE hFile = CreateFileW(
                    ((DLGRESULT_LIST*)pResult)->szFileName,
                    GENERIC_READ,
                    0,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL,
                    NULL);
                if (hFile == INVALID_HANDLE_VALUE)
                {
                    delete (DLGRESULT_LIST*)pResult;
                    return 0;
                }

                BYTE byFileMark[4];
                DWORD cbRead;
                ReadFile(hFile, byFileMark, 4, &cbRead, NULL);
                if (memcmp(byFileMark, "QKPL", 4))
                {
                    CloseHandle(hFile);
                    delete (DLGRESULT_LIST*)pResult;
                    return 0;
                }

                DWORD dwExitCode;
                if (GetExitCodeThread(m_hThread[1], &dwExitCode))
                    StopThread_MusicTime();
                else
                    dwExitCode = 0;

                DWORD dwSize = GetFileSize(hFile, NULL);
                HANDLE hMapping = CreateFileMappingW(hFile, NULL, PAGE_READONLY, 0, dwSize, NULL);
                BYTE* pFile = (BYTE*)MapViewOfFile(hMapping, FILE_MAP_READ, 0, 0, dwSize);
                BYTE* pCurr = pFile;

                LISTFILEHEADER* pListHeader = (LISTFILEHEADER*)pCurr;
                LISTFILEITEM* pListItem;
                PLAYERLISTUNIT t = { 0 };
                int iLenght;

                pCurr += sizeof(LISTFILEHEADER);//跳过文件头
                List_SetRedraw(FALSE);
                for (int i = 0; i < pListHeader->iCount; ++i)
                {
                    //读项目头
                    pListItem = (LISTFILEITEM*)pCurr;
                    pCurr += sizeof(LISTFILEITEM);
                    //读名称
                    t.pszName = (PWSTR)pCurr;
                    pCurr += (lstrlenW(t.pszName) + 1) * sizeof(WCHAR);
                    //读文件名
                    t.pszFile = (PWSTR)pCurr;
                    pCurr += (lstrlenW(t.pszFile) + 1) * sizeof(WCHAR);
                    if (pListItem->uFlags & QKLIF_BOOKMARK)
                    {
                        memcpy(&t.crBookMark, pCurr, sizeof(COLORREF));// 读书签颜色
                        pCurr += sizeof(COLORREF);

                        iLenght = lstrlenW((PWSTR)pCurr);
                        if (iLenght)
                            t.pszBookMark = (PWSTR)pCurr;// 读书签名称
                        else
                            t.pszBookMark = NULL;
                        pCurr += (iLenght + 1) * sizeof(WCHAR);

                        iLenght = lstrlenW((PWSTR)pCurr);
                        if (iLenght)
                            t.pszBookMarkComment = (PWSTR)pCurr;// 读书签备注
                        else
                            t.pszBookMarkComment = NULL;
                        pCurr += (iLenght + 1) * sizeof(WCHAR);
                    }
                    else
                        pCurr += sizeof(COLORREF) + sizeof(WCHAR) * 2;

                    if (pListHeader->dwVer >= QKLFVER_2)// 版本2
                    {
                        if (pListItem->uFlags & QKLIF_TIME)
                        {
                            t.pszTime = (PWSTR)pCurr;
                            pCurr += (lstrlenW(t.pszTime) + 1) * sizeof(WCHAR);
                        }
                        else
                        {
                            t.pszTime = NULL;
                            pCurr += sizeof(WCHAR);
                        }
                    }
                    else
                        t.pszTime = NULL;

					List_Add(t.pszFile, t.pszName, -1, FALSE, pListItem->uFlags, t.crBookMark, t.pszBookMark, t.pszBookMarkComment, t.pszTime);
                }
                List_SetRedraw(TRUE);
                List_ResetLV();
                UI_RedrawBookMarkPos();

                UnmapViewOfFile(pFile);
                CloseHandle(hMapping);
                CloseHandle(hFile);
                delete (DLGRESULT_LIST*)pResult;

                PathStripPathW(szListName);
                PathRemoveExtensionW(szListName);
                SetWindowTextW(GetDlgItem(g_hBKRight, IDC_ST_LISTNAME), szListName);
                g_iLaterPlay = -1;
                List_FillMusicTimeColumn(TRUE);
            }
            return 0;
            case IDC_BT_SAVE:
            {
                if (!QKArray_GetCount(g_ItemData))
                    return 0;

                INT_PTR pResult = DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_LIST), g_hMainWnd, DlgProc_List, DLGTYPE_SAVELIST);
                if (!pResult)
                    return 0;

                lstrcpyW(szListName, ((DLGRESULT_LIST*)pResult)->szFileName);

                HANDLE hFile = CreateFileW(
                    ((DLGRESULT_LIST*)pResult)->szFileName,
                    GENERIC_WRITE | GENERIC_READ,
                    0,
                    NULL,
                    CREATE_ALWAYS,
                    FILE_ATTRIBUTE_NORMAL,
                    NULL);// 打开文件
                if (hFile == INVALID_HANDLE_VALUE)
                {
                    delete (DLGRESULT_LIST*)pResult;
                    return 0;
                }

                DWORD cbWritten;
                LISTFILEHEADER ListHeader = { 0 };
                memcpy(&(ListHeader.cHeader), "QKPL", 4);// 文件头
                ListHeader.iCount = g_ItemData->iCount;
                ListHeader.dwVer = QKLFVER_2;

                WriteFile(hFile, &ListHeader, sizeof(LISTFILEHEADER), &cbWritten, NULL);//写文件头

                int iIndex = 0;

                LISTFILEITEM ListItem = { 0 };
                PLAYERLISTUNIT* p;
                WCHAR cNULL = 0;
                for (int i = 0; i < ListHeader.iCount; ++i)
                {
                    p = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
					ListItem.uFlags = p->dwFlags | (p->pszTime ? QKLIF_TIME : 0);
                    WriteFile(hFile, &ListItem, sizeof(LISTFILEITEM), &cbWritten, NULL);// 项目头
                    WriteFile(hFile, p->pszName, (lstrlenW(p->pszName) + 1) * sizeof(WCHAR), &cbWritten, NULL);// 名称
                    WriteFile(hFile, p->pszFile, (lstrlenW(p->pszFile) + 1) * sizeof(WCHAR), &cbWritten, NULL);// 文件名
                    WriteFile(hFile, &p->crBookMark, sizeof(COLORREF), &cbWritten, NULL);// 书签颜色
                    if (p->pszBookMark)
                        WriteFile(hFile, p->pszBookMark, (lstrlenW(p->pszBookMark) + 1) * sizeof(WCHAR), &cbWritten, NULL);// 书签名称
                    else
                        WriteFile(hFile, &cNULL, sizeof(WCHAR), &cbWritten, NULL);// 没有则写NULL
                    if (p->pszBookMarkComment)
                        WriteFile(hFile, p->pszBookMarkComment, (lstrlenW(p->pszBookMarkComment) + 1) * sizeof(WCHAR), &cbWritten, NULL);// 书签备注
                    else
                        WriteFile(hFile, &cNULL, sizeof(WCHAR), &cbWritten, NULL);// 没有则写NULL
                    if (p->pszTime)
                        WriteFile(hFile, p->pszTime, (lstrlenW(p->pszTime) + 1) * sizeof(WCHAR), &cbWritten, NULL);// 书签备注
					else
						WriteFile(hFile, &cNULL, sizeof(WCHAR), &cbWritten, NULL);// 没有则写NULL
                }
                CloseHandle(hFile);
                delete (DLGRESULT_LIST*)pResult;

                PathStripPathW(szListName);
                PathRemoveExtensionW(szListName);
                SetWindowTextW(GetDlgItem(g_hBKRight, IDC_ST_LISTNAME), szListName);
            }
            return 0;
            case IDC_BT_EMPTY:
            {
                if (MessageBoxW(g_hMainWnd, L"确定要清空播放列表吗？", L"询问", MB_ICONWARNING | MB_YESNO) == IDYES)
                {
                    List_Delete(-1, TRUE);
                    SetWindowTextW(GetDlgItem(g_hBKRight, IDC_ST_LISTNAME), L"/*当前无播放列表*/");
                    Stop();
                    UI_RedrawBookMarkPos();
                    g_iLaterPlay = -1;
                }
            }
            return 0;
            case IDC_BT_SEARCH:
            {
                PWSTR pszEdit;
                int iLength = GetWindowTextLengthW(GetDlgItem(g_hBKRight, IDC_ED_SEARCH));
                static int iTopIndex = -1, iVisibleItemCount = 0;
                if (!iLength)// 没有文本
                {
                    if (m_iSearchResult != -1)// 做现行播放项LV索引转换
                    {
                        if (g_iCurrFileIndex < m_iSearchResult && g_iCurrFileIndex != -1)// 索引落在结果数之内，说明搜索时现行索引被转换，现在要转换回来
                            g_iCurrFileIndex = List_GetArrayItemIndex(g_iCurrFileIndex);
                        // 没有落在结果数之内，搜索时索引未转换，一切保持原状
                        m_iSearchResult = -1;
                        List_ResetLV();// 数目变了，不是List_Redraw而是List_ResetLV
                        SendMessageW(g_hLV, LVM_ENSUREVISIBLE, iTopIndex + iVisibleItemCount - 1, TRUE);// 回到原来的位置（话说微软就不能搞个设置滚动条位置的消息？）
                        UI_RedrawBookMarkPos();
                    }
                }
                else
                {
                    iTopIndex = SendMessageW(g_hLV, LVM_GETTOPINDEX, 0, 0);
                    iVisibleItemCount = SendMessageW(g_hLV, LVM_GETCOUNTPERPAGE, 0, 0);

                    pszEdit = new WCHAR[iLength + 1];
                    GetWindowTextW(GetDlgItem(g_hBKRight, IDC_ED_SEARCH), pszEdit, iLength + 1);// 取编辑框文本
                    m_iSearchResult = 0;// 搜索结果置0
                    int iIndex;
                    BOOL b = (g_iCurrFileIndex != -1);// 是否要比对并转换现行索引
                    for (int i = 0; i < g_ItemData->iCount; ++i)
                    {
                        iIndex = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort;
                        if (iIndex == -1)
                            iIndex = i;
                        // 上面是处理索引映射
                        if (QKStrInStr(((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, iIndex))->pszName, pszEdit))// 比对文本
                        {
                            ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, m_iSearchResult))->iMappingIndexSearch = iIndex;// 映射，这个要从列表的开头开始映射，顺次往下，使用m_iSearchResult做到这一点
                            if (b)
                            {
                                if (i == g_iCurrFileIndex)
                                {
                                    g_iCurrFileIndex = m_iSearchResult;// 转换现行索引
                                    b = FALSE;
                                }
                            }
                            ++m_iSearchResult;// 结果数递增
                        }
                    }
                    List_ResetLV();
                    UI_RedrawBookMarkPos();
                    SetScrollPos(g_hLV, SB_VERT, 0, TRUE);
                    SendMessageW(g_hLV, WM_VSCROLL, MAKEWPARAM(SB_THUMBPOSITION, 0), NULL);
                    SendMessageW(g_hLV, WM_MOUSEWHEEL, 0, 0);
                }
            }
            return 0;
            case IDC_BT_MANAGING:
            {
                static BOOL bAscending = TRUE;// 升序：从小到大；降序：从大到小
                HMENU hMenu = CreatePopupMenu();
                UINT uFlags = m_iSearchResult == -1 ? 0 : MF_GRAYED;
                AppendMenuW(hMenu, m_bSort ? uFlags : MF_GRAYED, IDMI_LM_SORT_DEF, L"默认排序");
                AppendMenuW(hMenu, uFlags, IDMI_LM_SORT_FILENAME, L"按文件名排序");
                AppendMenuW(hMenu, uFlags, IDMI_LM_SORT_NAME, L"按名称排序");
                AppendMenuW(hMenu, uFlags, IDMI_LM_SORT_CTIME, L"按创建时间排序");
                AppendMenuW(hMenu, uFlags, IDMI_LM_SORT_MTIME, L"按修改时间排序");
                AppendMenuW(hMenu, uFlags, IDMI_LM_SORT_REVERSE, L"倒置排序");
                AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
                AppendMenuW(hMenu, 0, IDMI_LM_SORT_ASCENDING, L"升序");
                AppendMenuW(hMenu, 0, IDMI_LM_SORT_DESCENDING, L"降序");
                CheckMenuRadioItem(hMenu, IDMI_LM_SORT_ASCENDING, IDMI_LM_SORT_DESCENDING,
                    GS.bAscending ? IDMI_LM_SORT_ASCENDING : IDMI_LM_SORT_DESCENDING, MF_BYCOMMAND);// 处理单选项

				AppendMenuW(hMenu, GS.bNoBookMarkWhenSort ? MF_CHECKED : 0, IDMI_LM_NOBOOKMARK, L"排序时不显示书签标记");
                AppendMenuW(hMenu, m_bSort ? uFlags : MF_GRAYED, IDMI_LM_FIXSORT, L"固定为默认排序");
                AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
                AppendMenuW(hMenu, uFlags, IDMI_LM_BOOKMARK, L"书签...");
                AppendMenuW(hMenu, 0, IDMI_LM_DETAIL, L"详细信息...");
                AppendMenuW(hMenu, 0, IDMI_LM_SETLVDEFWIDTH, L"将列表调至默认宽度");
                AppendMenuW(hMenu, 0, IDMI_LM_UPDATETIME, L"强制更新列表时间信息");
                RECT rc;
                GetWindowRect((HWND)lParam, &rc);
                int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, rc.left, rc.bottom, 0, g_hMainWnd, NULL);
                DestroyMenu(hMenu);
                switch (iRet)
                {
                case IDMI_LM_SORT_DEF:// 返回默认排序
                {
                    if (g_iCurrFileIndex != -1)
                        g_iCurrFileIndex = ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, g_iCurrFileIndex))->iMappingIndexSort;

                    for (int i = 0; i < g_ItemData->iCount; ++i)
                        ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort = -1;

                    m_bSort = FALSE;
                    List_Redraw();
                    UI_RedrawBookMarkPos();
                }
                return 0;
                case IDMI_LM_SORT_FILENAME:// 按文件名排序
                {
                    m_bSort = TRUE;
                    int iCount = g_ItemData->iCount;
                    PLAYERLISTUNIT* p1, * p2;
                    int m, n;
                    int iResult = GS.bAscending ? 1 : -1;
                    // StrCmpLogicalW：字符串相同返回零；psz1大于psz2返回1；psz1小于psz2返回-1
                    // 冒泡.........
                    for (int i = 0; i < iCount - 1; ++i)
                    {
                        for (int j = 0; j < iCount - i - 1; ++j)
                        {
                            p1 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j);
                            p2 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j + 1);
                            m = p1->iMappingIndexSort == -1 ? j : p1->iMappingIndexSort;
                            n = p2->iMappingIndexSort == -1 ? j + 1 : p2->iMappingIndexSort;
                            if (StrCmpLogicalW(
                                ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, m))->pszFile,
                                ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, n))->pszFile) == iResult)
                            {
                                p1->iMappingIndexSort = n;
                                p2->iMappingIndexSort = m;
                            }
                        }
                    }
                    if (g_iCurrFileIndex != -1)
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            if (((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort == g_iCurrFileIndex)
                            {
                                g_iCurrFileIndex = i;// 转换现行索引
                                break;
                            }
                        }
                    }
                    List_Redraw();
                    UI_RedrawBookMarkPos();
                }
                return 0;
                case IDMI_LM_SORT_NAME:// 按列表名称排序
                {
                    m_bSort = TRUE;
                    int iCount = g_ItemData->iCount;
                    PLAYERLISTUNIT* p1, * p2;
                    int m, n;
                    int iResult = GS.bAscending ? 1 : -1;
                    // StrCmpLogicalW：字符串相同返回零；psz1大于psz2返回1；psz1小于psz2返回-1
                    for (int i = 0; i < iCount - 1; ++i)
                    {
                        for (int j = 0; j < iCount - i - 1; ++j)
                        {
                            p1 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j);
                            p2 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j + 1);
                            m = p1->iMappingIndexSort == -1 ? j : p1->iMappingIndexSort;
                            n = p2->iMappingIndexSort == -1 ? j + 1 : p2->iMappingIndexSort;
                            if (StrCmpLogicalW(
                                ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, m))->pszName,
                                ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, n))->pszName) == iResult)
                            {
                                p1->iMappingIndexSort = n;
                                p2->iMappingIndexSort = m;
                            }
                        }
                    }
                    if (g_iCurrFileIndex != -1)
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            if (((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort == g_iCurrFileIndex)
                            {
                                g_iCurrFileIndex = i;
                                break;
                            }
                        }
                    }
                    List_Redraw();
                    UI_RedrawBookMarkPos();
                }
                return 0;
                case IDMI_LM_SORT_CTIME:// 按创建时间排序
                case IDMI_LM_SORT_MTIME:// 按修改时间排序
                {
                    List_SetRedraw(FALSE);
                    m_bSort = TRUE;
                    int iCount = g_ItemData->iCount;
                    PLAYERLISTUNIT* p1, * p2;
                    int m, n;
                    int iResult = GS.bAscending ? 1 : -1;
                    // CompareFileTime：第一个文件时间早于第二个返回-1；第一个等于第二个返回0；第一个晚于第二个返回1
                    WIN32_FIND_DATAW wfd;
                    HANDLE hFind;
                    FILETIME* ft = new FILETIME[iCount];
                    if (iRet == IDMI_LM_SORT_CTIME)
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            hFind = FindFirstFileW(((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->pszFile, &wfd);// 这样比先CreateFile再GetFileTime快
                            memcpy(ft + i, &wfd.ftCreationTime, sizeof(FILETIME));
                            FindClose(hFind);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            hFind = FindFirstFileW(((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->pszFile, &wfd);// 这样比先CreateFile再GetFileTime快
                            memcpy(ft + i, &wfd.ftLastWriteTime, sizeof(FILETIME));
                            FindClose(hFind);
                        }
                    }

                    for (int i = 0; i < iCount - 1; ++i)
                    {
                        for (int j = 0; j < iCount - i - 1; ++j)
                        {
                            p1 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j);
                            p2 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, j + 1);
                            m = p1->iMappingIndexSort == -1 ? j : p1->iMappingIndexSort;
                            n = p2->iMappingIndexSort == -1 ? j + 1 : p2->iMappingIndexSort;
                            if (CompareFileTime(ft + m, ft + n) == iResult)
                            {
                                p1->iMappingIndexSort = n;
                                p2->iMappingIndexSort = m;
                            }
                        }
                    }
                    if (g_iCurrFileIndex != -1)
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            if (((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort == g_iCurrFileIndex)
                            {
                                g_iCurrFileIndex = i;
                                break;
                            }
                        }
                    }
                    List_SetRedraw(TRUE);
                    List_Redraw();
                    UI_RedrawBookMarkPos();
                }
                return 0;
                case IDMI_LM_SORT_ASCENDING:// 升序
                    GS.bAscending = TRUE;
                    return 0;
                case IDMI_LM_SORT_DESCENDING:// 降序
                    GS.bAscending = FALSE;
                    return 0;
                case IDMI_LM_FIXSORT:// 固定为默认排序
				{
					m_bSort = FALSE;
					PLAYERLISTUNIT** p;
					int iCount = g_ItemData->iCount;
					p = new PLAYERLISTUNIT * [iCount];
					for (int i = 0; i < iCount; ++i)
					{
                        p[i] = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort);
                    }

                    for (int i = 0; i < iCount; ++i)
                    {
                        ((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort = -1;
                        QKArray_Set(g_ItemData, i, p[i]);
                    }
                    delete[] p;
                    List_Redraw();
                }
                return 0;
                case IDMI_LM_DETAIL:// 查看列表文件详细信息
                {

                }
                return 0;
                case IDMI_LM_BOOKMARK:// 书签管理
                    DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_BOOKMARK), g_hMainWnd, DlgProc_BookMark, 0);
                    return 0;
                case IDMI_LM_SORT_REVERSE:// 倒置排序
                {
                    m_bSort = TRUE;
                    int m;
                    PLAYERLISTUNIT* p1, * p2;
                    int iCount = g_ItemData->iCount / 2;
                    int i;
                    for (i = 0; i < iCount; ++i)
                    {
                        p1 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
                        p2 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, g_ItemData->iCount - 1 - i);

                        m = p1->iMappingIndexSort == -1 ? i : p1->iMappingIndexSort;
                        p1->iMappingIndexSort = p2->iMappingIndexSort == -1 ? g_ItemData->iCount - 1 - i : p2->iMappingIndexSort;
                        p2->iMappingIndexSort = m;
                    }
                    p1 = (PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i);
                    if (p1->iMappingIndexSort == -1)
                        p1->iMappingIndexSort = i;

                    if (g_iCurrFileIndex != -1)
                    {
                        for (int i = 0; i < iCount; ++i)
                        {
                            if (((PLAYERLISTUNIT*)QKArray_Get(g_ItemData, i))->iMappingIndexSort == g_iCurrFileIndex)
                            {
                                g_iCurrFileIndex = i;
                                break;
                            }
                        }
                    }
                    List_Redraw();
                    UI_RedrawBookMarkPos();
                }
                return 0;
                case IDMI_LM_SETLVDEFWIDTH:// 置默认列表宽
                {
                    m_cxLV = DPIS_DEFCXLV;
                    UI_SetRitCtrlPos();
                    RECT rc;
                    GetClientRect(g_hMainWnd, &rc);
                    SendMessageW(g_hMainWnd, WM_SIZE, 0, MAKELONG(rc.right, rc.bottom));
                }
                return 0;
				case IDMI_LM_UPDATETIME:
					List_FillMusicTimeColumn(FALSE);
					return 0;
                case IDMI_LM_NOBOOKMARK:
                    if (GS.bNoBookMarkWhenSort)
                        GS.bNoBookMarkWhenSort = FALSE;
                    else
                        GS.bNoBookMarkWhenSort = TRUE;
                    UI_RedrawBookMarkPos();
                    return 0;
				}
			}
			}
        }
    }
    break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hDC = BeginPaint(hWnd, &ps);
        FillRect(hDC, &ps.rcPaint, (HBRUSH)GetStockObject(WHITE_BRUSH));
        EndPaint(hWnd, &ps);
    }
    return 0;
    case WM_CTLCOLORSTATIC:// 静态着色
        SetTextColor((HDC)wParam, QKCOLOR_CYANDEEPER);
        return (LRESULT)GetStockObject(WHITE_BRUSH);
    }
    return DefWindowProcW(hWnd, message, wParam, lParam);
}
int LrcShowHitTest(POINT pt)
{
    if (!g_Lrc->iCount || !g_hStream)
        return -1;

    RECT rc = { 0,0,m_rcLrcShow.right ,0 };
    int y, cy, cyCenter, yHalfLrc = (m_rcLrcShow.top + m_rcLrcShow.bottom) / 2;

    cyCenter = ((LRCDATA*)QKArray_Get(g_Lrc, m_iLrcCenter))->cy;

    rc.top = yHalfLrc - cyCenter / 2;
    rc.bottom = rc.top + cyCenter;
    if (PtInRect(&rc, pt))
    {
        if (cyCenter > 0)
            return m_iLrcCenter;
    }
    else if (pt.y < yHalfLrc)// 落在上半部分
    {
        y = yHalfLrc - cyCenter / 2 - DPIS_LRCSHOWGAP;
        for (int i = m_iLrcCenter - 1; i >= 0; --i)
        {
            cy = ((LRCDATA*)QKArray_Get(g_Lrc, i))->cy;
            if (cy < 0)
                break;
            else if (cy == 0)
                continue;

            rc.bottom = y;
            y -= cy;
            rc.top = y;
            y -= DPIS_LRCSHOWGAP;
            if (PtInRect(&rc, pt))
                return i;
        }
    }
    else// 落在下半部分
    {
        y = yHalfLrc + cyCenter / 2 + DPIS_LRCSHOWGAP;
        for (int i = m_iLrcCenter + 1; i < g_Lrc->iCount; ++i)
        {
            cy = ((LRCDATA*)QKArray_Get(g_Lrc, i))->cy;
            if (cy < 0)
                break;
            else if (cy == 0)
                continue;

            rc.top = y;
            y += cy;
            rc.bottom = y;
            y += DPIS_LRCSHOWGAP;
            if (PtInRect(&rc, pt))
                return i;
        }
    }
    return -1;
}
LRESULT CALLBACK WndProc_LeftBK(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int iDelayTime = 0;
    static int iLastIndex = -1;
    static RECT rcLrcSB = { 0 };
    static RECT rcLrcSBThumb = { 0 };
    static int iThumbSize=80, iSBMax = 0;
    static BOOL bSBLBtnDown = FALSE;
    static int iCursorOffest = 0;// 左键按下时，光标离滑块顶边的距离
    switch (message)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hDC = BeginPaint(hWnd, &ps);
        BitBlt(hDC, 0, 0, m_cxLeftBK, m_cyLeftBK, m_hcdcLeftBK2, 0, 0, SRCCOPY);// 简简单单贴个图
        EndPaint(hWnd, &ps);
    }
    return 0;
    case WM_SIZE:
    {
        m_cxLeftBK = LOWORD(lParam);
        m_cyLeftBK = HIWORD(lParam);

        if (m_bLrcShow)
        {
            SetRect(&m_rcLrcShow,
                DPIS_CXPIC + DPIS_EDGE * 2,
				DPIS_CYTOPBK + DPIS_EDGE,
				m_cxLeftBK - DPIS_EDGE,
				m_cyLeftBK - DPIS_BT - DPIS_CYPROGBAR);
			m_cxLrcShow = m_rcLrcShow.right - m_rcLrcShow.left;
			m_cyLrcShow = m_rcLrcShow.bottom - m_rcLrcShow.top;
			m_xSpe = DPIS_EDGE;
			m_ySpe = DPIS_CYTOPBK + DPIS_EDGE + DPIS_CXPIC + DPIS_EDGE;
			m_xWaves = DPIS_EDGE;
			m_yWaves = m_ySpe + DPIS_EDGE + DPIS_CYSPE;
            m_LrcHScrollInfo.iIndex = -1;
            m_LrcHScrollInfo.bWndSizeChangedFlag = TRUE;
		}
		else
		{
			int cxSpe = (m_cxLeftBK - DPIS_EDGE * 2) / (DPIS_CXSPEBAR + DPIS_CXSPEBARDIV) * (DPIS_CXSPEBAR + DPIS_CXSPEBARDIV);
			if (cxSpe > DPIS_CXSPE)
				cxSpe = DPIS_CXSPE;
			SetRect(&m_rcLrcShow, 0, 0, 0, 0);
			m_cxLrcShow = 0;
			m_cyLrcShow = 0;
			m_xSpe = (m_cxLeftBK - (cxSpe * 2 + DPIS_EDGE)) / 2;
            m_ySpe = m_cyLeftBK - DPIS_CYBTBK - DPIS_CYPROGBAR - DPIS_CYSPE;
            m_xWaves = m_xSpe + DPIS_EDGE + DPIS_CXSPE;
            m_yWaves = m_ySpe;
        }

        SetWindowPos(g_hTBProgess, 0,
            0,
            m_cyLeftBK - DPIS_BT - DPIS_CYPROGBAR,
            m_cxLeftBK,
            DPIS_CYPROGBAR,
            SWP_NOZORDER);//进度条
        m_xBtmBK = (m_cxLeftBK - DPIS_CXBTMBTBK) / 2;
        m_yBtmBK = m_cyLeftBK - DPIS_BT;
        SetWindowPos(g_hBKBtm, 0,
            m_xBtmBK,
            m_yBtmBK,
            0, 0, SWP_NOZORDER | SWP_NOSIZE);//底部按钮容器

        rcLrcSB =
        {
			m_cxLeftBK - DPIS_CXLRCTB * 3 / 4,
            m_rcLrcShow.top,
			m_cxLeftBK - DPIS_CXLRCTB / 4,
            m_rcLrcShow.bottom
        };// 制滚动条矩形

        if (iSBMax)
        {
            rcLrcSBThumb.left = rcLrcSB.left;
            rcLrcSBThumb.top = m_rcLrcShow.top + m_iLrcSBPos * (rcLrcSB.bottom - rcLrcSB.top - iThumbSize) / iSBMax;
            rcLrcSBThumb.right = rcLrcSB.right;
            rcLrcSBThumb.bottom = rcLrcSBThumb.top + iThumbSize;
        }

        GDIObj_LeftBK();
        m_IsDraw[0] = m_IsDraw[1] = m_IsDraw[2] = TRUE;
        UpdateLeftBK();
    }
    return 0;
    case WM_HSCROLL:// 进度滑块条
    {
        switch (LOWORD(wParam))
        {
        case TB_THUMBTRACK:
            KillTimer(g_hMainWnd, IDT_PGS);
            return 0;
        case TB_THUMBPOSITION:
            BASS_ChannelSetPosition(
                g_hStream,
                BASS_ChannelSeconds2Bytes(
                    g_hStream,
                    SendMessageW(g_hTBProgess, QKCTBM_GETPOS, 0, 0) / 100),
                BASS_POS_BYTE
            );// 设置位置
            SetTimer(g_hMainWnd, IDT_PGS, TIMERELAPSE_PGS, TimerProc);
            return 0;
        }
    }
    return 0;
    case WM_LBUTTONDOWN:// 左键按下得焦点
    {
        iDelayTime = 5;
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        if (PtInRect(&m_rcLrcShow, pt))
            SetFocus(hWnd);
        else if(PtInRect(&rcLrcSB, pt))
        {
            if (PtInRect(&rcLrcSBThumb, pt))
            {
                bSBLBtnDown = TRUE;
                iCursorOffest = pt.y - m_rcLrcShow.top - m_iLrcSBPos * (rcLrcSB.bottom - rcLrcSB.top - iThumbSize) / iSBMax;
                SetCapture(hWnd);
            }
        }
    }
	return 0;
    case WM_LBUTTONUP:
    {
        bSBLBtnDown = FALSE;
        ReleaseCapture();
    }
    return 0;
	case WM_MOUSEWHEEL:// 鼠标滚轮滚动
	{
		if (!g_Lrc->iCount)
			return 0;

		iDelayTime = 5;
		if (m_iLrcSBPos == -1)
			m_iLrcSBPos = g_iCurrLrcIndex;

		int iDistance = -GET_WHEEL_DELTA_WPARAM(wParam) / WHEEL_DELTA;
		if (m_iLrcSBPos + iDistance < 0)
			m_iLrcSBPos = 0;
		else if (m_iLrcSBPos + iDistance > iSBMax)
			m_iLrcSBPos = iSBMax;
		else
			m_iLrcSBPos = m_iLrcSBPos + iDistance;
		WndProc_LeftBK(hWnd, LEFTBKM_REDRAWSB, TRUE, 0);
		m_IsDraw[2] = TRUE;
		TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
        SetTimer(hWnd, IDT_LRCSCROLL, TIMERELAPSE_LRCSCROLL, NULL);
	}
	return 0;
	case WM_TIMER:// 延时隐藏滑块条
    {
		--iDelayTime;
		if (iDelayTime <= 0)
        {
            KillTimer(hWnd, IDT_LRCSCROLL);
            m_iLrcSBPos = -1;
            WndProc_LeftBK(hWnd, LEFTBKM_REDRAWSB, TRUE, 0);
        }
    }
    return 0;
	case WM_MOUSEMOVE:
	{
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        static int iLastPos = -1;
		if (m_iLrcFixedIndex != -1)
			return 0;
		if (bSBLBtnDown)
		{
            iDelayTime = 5;
			int i = (pt.y - m_rcLrcShow.top - iCursorOffest) * iSBMax / (rcLrcSB.bottom - rcLrcSB.top - iThumbSize);
            if (i < 0)
                i = 0;
            else if (i > iSBMax)
                i = iSBMax;
            if (iLastPos != i)
            {
                iLastPos = m_iLrcSBPos = i;
                WndProc_LeftBK(hWnd, LEFTBKM_REDRAWSB, TRUE, 0);
                m_IsDraw[2] = TRUE;
                TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
            }
		}
		else if (m_iLrcCenter >= 0 && m_iLrcFixedIndex == -1)
		{
			if (PtInRect(&m_rcLrcShow, pt))
			{
				int i = LrcShowHitTest(pt);
				if (i != iLastIndex)
				{
                    m_iLrcMouseHover = i;
					if (iLastIndex >= 0 && iLastIndex < g_Lrc->iCount)
						Lrc_DrawItem(iLastIndex, -1, 0, TRUE, TRUE);

					if (i != -1 && i < g_Lrc->iCount)
						Lrc_DrawItem(i, -1, 0, TRUE, TRUE);

					iLastIndex = i;
				}
				iDelayTime = 5;
				TRACKMOUSEEVENT tme;
				tme.cbSize = sizeof(TRACKMOUSEEVENT);
				tme.dwFlags = TME_LEAVE;
				tme.hwndTrack = hWnd;
				tme.dwHoverTime = 0;
				TrackMouseEvent(&tme);
			}
			else
			{
				if (iLastIndex != -1)
				{
					m_iLrcMouseHover = -1;
					if (iLastIndex < g_Lrc->iCount)
						Lrc_DrawItem(iLastIndex, -1, 0, TRUE, TRUE);

					iLastIndex = -1;
				}
			}
		}
	}
    return 0;
    case WM_MOUSELEAVE:
    {
        if (m_iLrcFixedIndex != -1)
            return 0;
        iLastIndex = m_iLrcMouseHover = -1;
        m_IsDraw[2] = TRUE;
        TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
    }
    return 0;
    case WM_RBUTTONUP:
    {
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        if (PtInRect(&m_rcLrcShow, pt))
        {
            int i = LrcShowHitTest(pt);
            if (i != iLastIndex)
            {
                iLastIndex = m_iLrcMouseHover = i;
                m_IsDraw[2] = TRUE;
                TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
            }
            UINT uFlags = (i == -1) ? MF_GRAYED : 0;
            HMENU hMenu = CreatePopupMenu();
            AppendMenuW(hMenu, uFlags, IDMI_LS_PLAY, L"从此处播放");
            AppendMenuW(hMenu, uFlags, IDMI_LS_COPY, L"复制歌词");
            //SetMenuItemBitmaps()

            ClientToScreen(hWnd, &pt);
            m_iLrcFixedIndex = m_iLrcCenter;
            int iRet = TrackPopupMenu(hMenu, TPM_RETURNCMD, pt.x, pt.y, 0, hWnd, NULL);
            DestroyMenu(hMenu);
            switch (iRet)
            {
            case IDMI_LS_PLAY:// 从此处播放
            {
                BASS_ChannelSetPosition(
                    g_hStream,
                    BASS_ChannelSeconds2Bytes(
                        g_hStream,
                        ((LRCDATA*)QKArray_Get(g_Lrc, i))->fTime),
                    BASS_POS_BYTE
                );
            }
            break;
            case IDMI_LS_COPY:// 复制歌词
            {
                PWSTR pszLrc = ((LRCDATA*)QKArray_Get(g_Lrc, i))->pszLrc;
                HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, (lstrlenW(pszLrc) + 1) * sizeof(WCHAR));
                void* pGlobal = GlobalLock(hGlobal);
                lstrcpyW((PWSTR)pGlobal, pszLrc);
                GlobalUnlock(hGlobal);
                if (OpenClipboard(hWnd))
                {
                    EmptyClipboard();
                    SetClipboardData(CF_UNICODETEXT, hGlobal);
                    CloseClipboard();
                }
                else
                {
                    GlobalFree(hGlobal);
                    break;
                }
            }
            break;
            }
            m_iLrcFixedIndex = -1;
            m_IsDraw[2] = TRUE;
            TimerProc(NULL, 0, IDT_DRAWING_LRC, 0);
        }
    }
	return 0;
	case LEFTBKM_REDRAWSB:
	{
		if (iSBMax)
		{
			rcLrcSBThumb.left = rcLrcSB.left;
			rcLrcSBThumb.top = m_rcLrcShow.top + m_iLrcSBPos * (rcLrcSB.bottom - rcLrcSB.top - iThumbSize) / iSBMax;
			rcLrcSBThumb.right = rcLrcSB.right;
			rcLrcSBThumb.bottom = rcLrcSBThumb.top + iThumbSize;
		}
		if (wParam)
			BitBlt(m_hcdcLeftBK2, rcLrcSB.left, rcLrcSB.top, rcLrcSB.right - rcLrcSB.left, rcLrcSB.bottom - rcLrcSB.top,
				m_hcdcLeftBK, rcLrcSB.left, rcLrcSB.top, SRCCOPY);

		if (m_iLrcSBPos != -1)
			FillRect(m_hcdcLeftBK2, &rcLrcSBThumb, GC.hbrMyBule);

		HDC hDC = GetDC(hWnd);
		BitBlt(hDC, rcLrcSB.left, rcLrcSB.top, rcLrcSB.right - rcLrcSB.left, rcLrcSB.bottom - rcLrcSB.top,
			m_hcdcLeftBK2, rcLrcSB.left, rcLrcSB.top, SRCCOPY);
		ReleaseDC(hWnd, hDC);
	}
    return 0;
    case LEFTBKM_SETMAX:
    {
        iSBMax = wParam;
        WndProc_LeftBK(hWnd, LEFTBKM_REDRAWSB, TRUE, 0);
    }
    return 0;
    case WM_KEYDOWN:
    {
        if (wParam == VK_ESCAPE)
        {
            KillTimer(hWnd, IDT_LRCSCROLL);
            m_iLrcSBPos = -1;
            WndProc_LeftBK(hWnd, LEFTBKM_REDRAWSB, TRUE, 0);
            return 0;
        }
    }
    break;
    }
    return DefWindowProcW(hWnd, message, wParam, lParam);
}
void GDIObj_LeftBK(DWORD dwOpe)
{
    if (m_hbmpLeftBK)
        DeleteObject(m_hbmpLeftBK);
    if (m_hbmpLeftBK2)
        DeleteObject(m_hbmpLeftBK2);
    if (dwOpe == GDIOBJOPE_REFRESH)
    {
        RECT rc;
        GetClientRect(g_hBKLeft, &rc);
        HDC hDC = GetDC(g_hBKLeft);
        m_hbmpLeftBK = CreateCompatibleBitmap(hDC, rc.right, rc.bottom);
        m_hbmpLeftBK2 = CreateCompatibleBitmap(hDC, rc.right, rc.bottom);
        SelectObject(m_hcdcLeftBK, m_hbmpLeftBK);
        SelectObject(m_hcdcLeftBK2, m_hbmpLeftBK2);
        ReleaseDC(g_hBKLeft, hDC);
    }
}