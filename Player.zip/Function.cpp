#include "windows.h"
#include "CommCtrl.h"
#include "shlobj_core.h"
#include "shlwapi.h"
#include "Function.h"
#include "math.h"
#include "GlobalVar.h"
#include "resource.h"

HFONT QKCreateFont(LPCWSTR szFontName, int nPoint, int nWeight, bool IsItalic, bool IsUnderline, bool IsStrikeOut)
{
    //for the MM_TEXT mapping mode, you can use the following formula to specify a height for a font with a specified point size:
    //MM_TEXTӳ��ģʽ�¿������¹�ʽ������ָ����ֵ����ĸ߶ȣ�
    //Height = -MulDiv(PointSize, GetDeviceCaps(hDC, LOGPIXELSY), 72);     ��ժ��MSDN��
    HDC hDC = GetDC(NULL);
    int nSize;
    nSize = -MulDiv(nPoint, GetDeviceCaps(hDC, LOGPIXELSY), 72);
    //MulDiv(a, b, c) ���Ǽ��� a * b / c �������� a * b > 2^32 ʱ�Ա�֤�����ȷ
    ReleaseDC(NULL, hDC);
    return CreateFontW(nSize, 0, 0, 0, nWeight, IsItalic, IsUnderline, IsStrikeOut, 0, 0, 0, 0, 0, szFontName);
}
QKARRAY QKArray_Create(int iCount)
{
    if (iCount < 0)
        return NULL;

    QKARRAY pArray = (QKARRAY)HeapAlloc(
        GetProcessHeap(),
        HEAP_ZERO_MEMORY,
        sizeof(QKARRAYHEADER) + sizeof(LPVOID) * iCount
    );
    if (!pArray)
        return NULL;

    pArray->iCount = iCount;
    return pArray;
}
void QKArray_Delete(QKARRAY pArray, DWORD dwDeleteFlag)
{
    if (!pArray)
        return;
    switch (dwDeleteFlag)
    {
    case QKADF_NO:
        break;
    case QKADF_DELETE:
        for (int i = 0; i < pArray->iCount; ++i)
            delete QKArray_Get(pArray, i);
        break;
    case QKADF_DELETEARRAY:
        for (int i = 0; i < pArray->iCount; ++i)
            delete[] QKArray_Get(pArray, i);
        break;
    case QKADF_HEAPFREE:
        for (int i = 0; i < pArray->iCount; ++i)
            HeapFree(GetProcessHeap(), 0, QKArray_Get(pArray, i));
        break;
    }
    HeapFree(GetProcessHeap(), 0, pArray);
}
void QKArray_Clear(QKARRAY pArray, DWORD dwDeleteFlag)
{
    if (!pArray)
        return;
    switch (dwDeleteFlag)
    {
    case QKADF_NO:
        break;
    case QKADF_DELETE:
        for (int i = 0; i < pArray->iCount; ++i)
            delete QKArray_Get(pArray, i);
        break;
    case QKADF_DELETEARRAY:
        for (int i = 0; i < pArray->iCount; ++i)
            delete[] QKArray_Get(pArray, i);
        break;
    case QKADF_HEAPFREE:
        for (int i = 0; i < pArray->iCount; ++i)
            HeapFree(GetProcessHeap(), 0, QKArray_Get(pArray, i));
        break;
    }
    pArray->iCount = 0;
}
int QKArray_Add(QKARRAY* ppArray, LPVOID pMember)
{
    QKARRAY pArray = *ppArray;
    if (!pArray)
        return -1;

    SIZE_T dwCurrSize = HeapSize(GetProcessHeap(), 0, pArray);
    QKARRAY pArrayNew = (QKARRAY)HeapReAlloc(
        GetProcessHeap(),
        0,
        pArray,
        dwCurrSize + sizeof(LPVOID));
    if (!pArrayNew)
        return -1;

    memcpy((CHAR*)pArrayNew + dwCurrSize, &pMember, sizeof(LPVOID));
    *ppArray = pArrayNew;
    return pArrayNew->iCount++;//������ǰֵ����Ϊ������������һ
}
int QKArray_AddValue(QKARRAY* ppArray, LPVOID pMember)
{
    if (*ppArray == NULL)
        return -1;
    DWORD dwCurrSize = HeapSize(GetProcessHeap(), 0, *ppArray);
    LPVOID pArrayNew = HeapReAlloc(
        GetProcessHeap(),
        0,
        *ppArray,
        dwCurrSize + sizeof(LPVOID));
    if (pArrayNew == NULL)
        return -1;

    memcpy((CHAR*)pArrayNew + dwCurrSize, pMember, sizeof(int));
    *ppArray = (QKARRAY)pArrayNew;
    return ((QKARRAYHEADER*)pArrayNew)->iCount++;//������ǰֵ����Ϊ������������һ
}
int QKArray_Insert(QKARRAY* ppArray, LPVOID pMember, int iIndex)//��iIndex������
{
    if (*ppArray == NULL)
        return -1;
    if (iIndex < 0 || iIndex > ((QKARRAYHEADER*)*ppArray)->iCount)
        return -1;
    DWORD dwCurrSize = HeapSize(GetProcessHeap(), 0, *ppArray);
    QKARRAY pArrayNew = (QKARRAY)HeapReAlloc(
        GetProcessHeap(),
        0,
        *ppArray,
        dwCurrSize + sizeof(LPVOID));
	if (!pArrayNew)
		return -1;
	BYTE* pChanging = (BYTE*)pArrayNew + sizeof(QKARRAYHEADER) + sizeof(LPVOID) * iIndex;

    if (iIndex != pArrayNew->iCount)
        memmove(pChanging + sizeof(LPVOID), pChanging, (pArrayNew->iCount - iIndex) * sizeof(LPVOID));
	memcpy(pChanging, &pMember, sizeof(LPVOID));
	pArrayNew->iCount++;
    *ppArray = pArrayNew;
    return iIndex;
}
LPVOID QKArray_Get(QKARRAY pArray, DWORD dwIndex)//��0��ʼ
{
    if (pArray == NULL)
        return NULL;
    return (LPVOID)(*(LPVOID*)((CHAR*)pArray + sizeof(QKARRAYHEADER) + sizeof(LPVOID) * dwIndex));
}
LPVOID QKArray_GetValue(QKARRAY pArray, DWORD dwIndex)
{
    if (pArray == NULL)
        return NULL;
    return (LPVOID)((CHAR*)pArray + sizeof(QKARRAYHEADER) + sizeof(LPVOID) * dwIndex);
}
void QKArray_Set(QKARRAY pArray, DWORD dwIndex, LPVOID pMember, DWORD dwDeleteFlag)//��0��ʼ
{
    if (pArray == NULL)
        return;
    if (dwIndex > ((QKARRAYHEADER*)pArray)->iCount - 1 || dwIndex < 0)
    {
        return;
    }
    LPVOID pMember1 = QKArray_Get(pArray, dwIndex);
    if (IsBadReadPtr(pMember, 1))
    {
        switch (dwDeleteFlag)
        {
        case QKADF_NO:
            break;
        case QKADF_DELETE:
            delete pMember1;
            break;
        case QKADF_DELETEARRAY:
            delete[] pMember1;
            break;
        case QKADF_HEAPFREE:
            HeapFree(GetProcessHeap(), 0, pMember1);
            break;
        }
    }
    memcpy((CHAR*)pArray + sizeof(QKARRAYHEADER) + sizeof(LPVOID) * dwIndex, &pMember, sizeof(LPVOID));
}
int QKArray_GetCount(QKARRAY pArray)
{
	if (pArray == NULL)
		return -1;
	return pArray->iCount;
}
void QKArray_DeleteMember(QKARRAY* ppArray, DWORD dwIndex, DWORD dwDeleteFlag)
{
    if (!*ppArray)
        return;
    DWORD dwCount = ((QKARRAYHEADER*)*ppArray)->iCount;
    if (dwIndex > dwCount - 1 || dwIndex < 0)
        return;

    LPVOID pMember = QKArray_Get(*ppArray, dwIndex);
    if (IsBadReadPtr(pMember, 1))
    {
        switch (dwDeleteFlag)
        {
        case QKADF_NO:
            break;
        case QKADF_DELETE:
            delete pMember;
            break;
        case QKADF_DELETEARRAY:
            delete[] pMember;
            break;
        case QKADF_HEAPFREE:
            HeapFree(GetProcessHeap(), 0, pMember);
            break;
        }
    }
    if (dwIndex != dwCount - 1)//��ɾ����Ŀ����ĩβ
    {
        CHAR* pBase = (CHAR*)*ppArray + sizeof(QKARRAYHEADER) + sizeof(LPVOID) * dwIndex;
        memmove(
            pBase, 
            pBase + sizeof(LPVOID), 
            (dwCount - dwIndex - 1) * sizeof(LPVOID));
    }
    DWORD dwCurrSize = dwCount * sizeof(LPVOID) + sizeof(QKARRAYHEADER);
    LPVOID pArrayNew = HeapReAlloc(
        GetProcessHeap(),
        HEAP_GENERATE_EXCEPTIONS,
        *ppArray,
        dwCurrSize - sizeof(LPVOID));
    *ppArray = (QKARRAY)pArrayNew;
    if (pArrayNew == NULL)
        return;

    ((QKARRAYHEADER*)pArrayNew)->iCount--;
}
LPVOID QKArray_GetDataPtr(QKARRAY pArray)
{
    return (BYTE*)pArray + sizeof(QKARRAYHEADER);
}
INT_PTR CALLBACK DlgProc_InputBox(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    QKINPUTBOXCOMTEXT* pContext;
    pContext = (QKINPUTBOXCOMTEXT*)GetPropW(hDlg, PROP_INPUTBOXCONTEXT);
    switch (message)
    {
    case WM_INITDIALOG:
    {
        pContext = (QKINPUTBOXCOMTEXT*)lParam;
        SetPropW(hDlg, PROP_INPUTBOXCONTEXT, pContext);
        SetWindowTextW(hDlg, pContext->pszTitle);
        SetDlgItemTextW(hDlg, IDC_ST_INPUT, pContext->pszTip);
        SetDlgItemTextW(hDlg, IDC_ED_INPUT, *(pContext->ppszBuffer));
        SetFocus(GetDlgItem(hDlg, IDC_ED_INPUT));
    }
    return FALSE;
    case WM_COMMAND:
    {
        if (LOWORD(wParam) == IDOK)
        {
			pContext->iButton = IDOK;
			int iBufferSize = GetWindowTextLengthW(GetDlgItem(hDlg, IDC_ED_INPUT)) + 1;
			*(pContext->ppszBuffer) = new WCHAR[iBufferSize];
			GetWindowTextW(GetDlgItem(hDlg, IDC_ED_INPUT), *(pContext->ppszBuffer), iBufferSize);
            EndDialog(hDlg, 0);
		}
        else if (LOWORD(wParam) == IDCANCEL)
        {
            pContext->iButton = IDCANCEL;
            EndDialog(hDlg, 0);
        }
	}
	return TRUE;
	case WM_CLOSE:
	{
		pContext->iButton = IDCANCEL;
		EndDialog(hDlg, 0);
	}
	return TRUE;
	}
	return FALSE;
}
BOOL QKInputBox(PCWSTR pszTitle, PCWSTR pszTip, PWSTR* ppszBuffer, HWND hParent)
{
	QKINPUTBOXCOMTEXT Context;
	Context.pszTitle = pszTitle;
	Context.pszTip = pszTip;
	Context.ppszBuffer = ppszBuffer;
	DialogBoxParamW(g_hInst, MAKEINTRESOURCEW(IDD_INPUT), hParent, DlgProc_InputBox, (LPARAM)&Context);
	return (Context.iButton == IDOK);
}
int QKStrInStr(PCWSTR pszOrg, PCWSTR pszSubStr, int iStartPos)
{
    int iSubStrCount = lstrlenW(pszSubStr);
    int iCount = lstrlenW(pszOrg) - iSubStrCount + 1 - (iStartPos - 1);
    if (iCount <= 0 || iStartPos <= 0)
        return 0;
	for (int i = 0; i < iCount; i++)
	{
		if (CompareStringW(
			LOCALE_USER_DEFAULT,
			LINGUISTIC_IGNORECASE,
			pszOrg + iStartPos - 1 + i,
			iSubStrCount,
			pszSubStr,
			iSubStrCount
		) == CSTR_EQUAL)
			return iStartPos + i;
	}
    return 0;
}
int QKStrInStrCS(PCWSTR pszOrg, PCWSTR pszSubStr, int iStartPos)
{
    int iSubStrCount = lstrlenW(pszSubStr);
    int iCount = lstrlenW(pszOrg) - iSubStrCount + 1 - (iStartPos - 1);
    if (iCount <= 0 || iStartPos <= 0)
        return 0;
    for (int i = 0; i < iCount; i++)
    {
        if (CompareStringW(
            LOCALE_USER_DEFAULT,
            0,
            pszOrg + iStartPos - 1 + i,
            iSubStrCount,
            pszSubStr,
            iSubStrCount
        ) == CSTR_EQUAL)
            return iStartPos + i;
    }
    return 0;
}
void QKStrTrim(PWSTR pszOrg)
{
    
	int i = 0, j = 0;
    while (pszOrg[i]==' '|| pszOrg[i] == '��'|| pszOrg[i] == '\t')
        ++i;
    j = lstrlenW(pszOrg) - 1;
    while (pszOrg[j] == ' ' || pszOrg[j] == '��' || pszOrg[j] == '\t')
    {
        if (j == 0)
            break;
        --j;
    }
    ++j;
    pszOrg[j] = '\0';
	PWSTR p = pszOrg + i;
	if (i)
		while (*pszOrg++ = *p++);
}
UINT QKMessageBox(
    LPCWSTR pszMainInstruction,
    LPCWSTR pszContent,
    HICON hIcon,
    LPCWSTR pszWndTitle,
    LPCWSTR pszChackBoxTitle,//��ΪNull����ʾ��ѡ��
    UINT iButtonCount,
    LPCWSTR pszButton1Title,
    LPCWSTR pszButton2Title,
    LPCWSTR pszButton3Title,
    HWND hParent,
    UINT iDefButton,
    BOOL IsCenterPos,
    _Out_ BOOL* IsCheck
    )
{
    if (iButtonCount < 1 && iButtonCount >3)
    {
        return 0;
    }
    TASKDIALOGCONFIG tdc = { 0 };
    tdc.cbSize = sizeof(TASKDIALOGCONFIG);
    TASKDIALOG_BUTTON tdb[3];
    tdc.cButtons = iButtonCount;
    tdc.pButtons = tdb;
    tdc.dwFlags = TDF_ALLOW_DIALOG_CANCELLATION | (IsCenterPos ? TDF_POSITION_RELATIVE_TO_WINDOW : 0);
    tdc.pszMainInstruction = pszMainInstruction;
    tdc.pszContent = pszContent;
    tdc.pszWindowTitle = pszWndTitle;
    tdc.pszVerificationText = pszChackBoxTitle;
    tdc.hMainIcon = hIcon;
    tdc.hwndParent = hParent;
    tdc.nDefaultButton = iDefButton;
    switch (iButtonCount)
    {
    case 1:
        tdb[0].nButtonID = QKMSGBOX_BTID_1;
        tdb[0].pszButtonText = !pszButton1Title ? L"ȷ��(&O)" : pszButton1Title;
    case 2:
        tdb[0].nButtonID = QKMSGBOX_BTID_1;
        tdb[0].pszButtonText = !pszButton1Title ? L"��(&Y)" : pszButton1Title;
        tdb[1].nButtonID = QKMSGBOX_BTID_2;
        tdb[1].pszButtonText = !pszButton2Title ? L"��(&N)" : pszButton2Title;
    case 3:
        tdb[0].nButtonID = QKMSGBOX_BTID_1;
        tdb[0].pszButtonText = !pszButton1Title ? L"��(&Y)" : pszButton1Title;
        tdb[1].nButtonID = QKMSGBOX_BTID_2;
        tdb[1].pszButtonText = !pszButton2Title ? L"��(&N)" : pszButton2Title;
        tdb[2].nButtonID = QKMSGBOX_BTID_3;
        tdb[2].pszButtonText = !pszButton3Title ? L"ȡ��(&C)" : pszButton3Title;
    }
    int iButton, iRadio;
    BOOL bCheckBox;
    TaskDialogIndirect(&tdc, &iButton, &iRadio, &bCheckBox);
    if (IsCheck)
        *IsCheck = bCheckBox;
    return iButton;
}
BOOL QKGradientFill(HDC hDC, RECT* Rect, COLORREF Color1, COLORREF Color2, ULONG Mode)
{
    TRIVERTEX tv[2] = { 0 };
    tv[0].x = Rect->left;
    tv[0].y = Rect->top;
    tv[0].Red = GetRValue(Color1) << 8;
    tv[0].Green = GetGValue(Color1) << 8;
    tv[0].Blue = GetBValue(Color1) << 8;

    tv[1].x = Rect->right;
    tv[1].y = Rect->bottom;
    tv[1].Red = GetRValue(Color2) << 8;
    tv[1].Green = GetGValue(Color2) << 8;
    tv[1].Blue = GetBValue(Color2) << 8;

    GRADIENT_RECT gr[1] = { 0 };
    gr[0].UpperLeft = 0;//���Ͻ�����Ϊ��һ����Ա
    gr[0].LowerRight = 1;//���½�����Ϊ�ڶ�����Ա

    return GradientFill(hDC, tv, 2, gr, 1, Mode);
}
void QKOutputLastErrorCode()
{
    WCHAR buf[32];
    wsprintfW(buf, L"%d\n", GetLastError());
    OutputDebugStringW(buf);
}
void QKOutputDebugInt(int i)
{
    WCHAR buf[32];
    wsprintfW(buf, L"%d\n", i);
    OutputDebugStringW(buf);
}
UINT QKGDIClrToCommonClr(COLORREF cr)
{
    BYTE by[4];
    UINT u;
    memcpy(by, &cr, 4);
    by[3] = by[0];
    by[0] = by[2];
    by[2] = by[3];
    by[3] = 0;
    memcpy(&u, by, 4);
    return u;
}
COLORREF QKCommonClrToGDIClr(UINT u)
{
    BYTE by[4];
    COLORREF cr;
    memcpy(by, &u, 4);
    by[3] = by[0];
    by[0] = by[2];
    by[2] = by[3];
    by[3] = 0;
    memcpy(&cr, by, 4);
    return cr;
}
UINT QKGetDPIForWindow(HWND hWnd)
{
#if _WIN32_WINNT >= _WIN32_WINNT_WIN10
	return GetDpiForWindow(hWnd);
#else
	HDC hDC = GetDC(hWnd);
	int i = GetDeviceCaps(hDC, LOGPIXELSX);
	ReleaseDC(hWnd, hDC);
	return i;
#endif
}
BOOL QKStrToBool(PCWSTR psz)
{
    if (lstrcmpiW(L"true", psz) == 0)
        return TRUE;
    else
        return FALSE;
}
UINT32 QKByteStreamToBEUINT32(BYTE* p)
{
	return (UINT32)(*(p) << 24 | *(p + 1) << 16 | *(p + 2) << 8 | *(p + 3));
}